// Portable type declarations for `@riftlabs/plugin-sdk`. Unpublished RIFT
// workspace contracts are flattened; public subpaths may reuse the
// package root without requiring any other @riftlabs/* package.
//
// Confused by the API, or need a symbol that isn't here? Clone the RIFT repo
// and read the real source: https://github.com/euforicio/rift-app

declare function isComposerDraftEmpty(text: string, attachmentCount: number): boolean;

export { isComposerDraftEmpty };
