// Portable type declarations for `@riftlabs/plugin-sdk`. Unpublished RIFT
// workspace contracts are flattened; public subpaths may reuse the
// package root without requiring any other @riftlabs/* package.
//
// Confused by the API, or need a symbol that isn't here? Clone the RIFT repo
// and read the real source: https://github.com/euforicio/rift-app

import { ComposerCustomization, PluginComposerThreadRowStatus } from '@riftlabs/plugin-sdk';

declare const PLUGIN_SLOT_ID_PATTERN: RegExp;
type RejectionReporter = (reason: string) => void;
/**
 * Parse the runtime value handed to
 * `PluginContentScriptContext.experimental_setThreadRowStatus`. `undefined`
 * means the value was rejected; `null` remains the explicit clear operation.
 */
declare function normalizePluginThreadRowStatus(value: unknown, onRejected: RejectionReporter): PluginComposerThreadRowStatus | null | undefined;
declare function requireSlotId(kind: string, value: unknown): string;
/**
 * Provider ids follow the same character rules as slot ids, but they name a
 * provider the host knows (`codex`, `acp-cursor`), not a per-plugin slot.
 */
declare function requireProviderId(kind: string, value: unknown): string;
/**
 * A timeline renderer kind: `"tool"` (the plugin's providers' generic tool
 * items) or a namespaced extension kind `"<pluginId>/<name>"` (lowercase
 * letters, digits and `-` on both sides, the grammar of
 * `extensionKindSchema`). Ownership of the namespace is enforced by the host
 * against the loading plugin's id, which the collector does not know.
 */
declare const PLUGIN_TIMELINE_RENDERER_KIND_PATTERN: RegExp;
declare function requireTimelineRendererKind(kind: string, value: unknown): string;
declare function requireMessageDirectiveId(kind: string, value: unknown): string;
declare function requireNonEmptyString(kind: string, field: string, value: unknown): string;
declare function requireOptionalString(kind: string, field: string, value: unknown): string | undefined;
declare function requireComponent<T>(kind: string, value: unknown): T;
declare function requireUniqueId(kind: string, seen: Set<string>, id: string): void;
/**
 * Validate one registration while isolating composer customization failures.
 * The host and test harness inject their own rejection reporters.
 */
declare function collectComposerCustomization(registration: unknown, seenIds: Set<string>, onRejected: RejectionReporter): ComposerCustomization | null;

export { PLUGIN_SLOT_ID_PATTERN, PLUGIN_TIMELINE_RENDERER_KIND_PATTERN, collectComposerCustomization, normalizePluginThreadRowStatus, requireComponent, requireMessageDirectiveId, requireNonEmptyString, requireOptionalString, requireProviderId, requireSlotId, requireTimelineRendererKind, requireUniqueId };
