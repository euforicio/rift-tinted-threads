// Portable type declarations for `@get-bb/plugin-sdk`. Unpublished BB
// workspace contracts are flattened; public subpaths may reuse the
// package root without requiring any other @bb/* package.
//
// Confused by the API, or need a symbol that isn't here? Clone the BB repo
// and read the real source: https://github.com/get-bb/bb

import { ExperimentalSidebarFooterActionContext, ExperimentalSidebarFooterItemRegistration, PluginHomepageSectionRegistration, PluginSettingsSectionRegistration, ExperimentalAppOverlayRegistration, PluginNavPanelRegistration, PluginThreadPanelActionRegistration, PluginNewThreadPanelActionRegistration, ComposerCustomization, PluginPendingInteractionRegistration, PluginSidebarFooterActionRegistration, ExperimentalSidebarNavigationRegistration, PluginThreadListRegistration, PluginThreadHeaderActionRegistration, PluginFileOpenerRegistration, PluginSourceCodeRendererRegistration, PluginDiffRendererRegistration, PluginMessageDirectiveRegistration, PluginMessageActionRegistration, PluginCommandPaletteActionRegistration, PluginProviderIconRegistration, PluginTimelineRendererRegistration, PluginContentScriptRegistration, PluginAppDefinition } from '@get-bb/plugin-sdk';

type ExperimentalSidebarFooterCommandKind = "close" | "open" | "toggle";
interface ExperimentalSidebarFooterRuntimeSnapshot {
    command: {
        sequence: number;
        kind: ExperimentalSidebarFooterCommandKind;
    } | null;
}
interface ExperimentalSidebarFooterItemRuntime {
    subscribe(listener: () => void): () => void;
    getSnapshot(): ExperimentalSidebarFooterRuntimeSnapshot;
    acknowledgeCommand(sequence: number): void;
}
type CollectedExperimentalSidebarFooterItem = ExperimentalSidebarFooterItemRegistration & {
    runtime: ExperimentalSidebarFooterItemRuntime;
};
type CollectedManagedSidebarFooterItem = CollectedExperimentalSidebarFooterItem & {
    source: "experimental_sidebarFooter";
};
interface CollectedCompatibilitySidebarFooterItem {
    source: "sidebarFooterAction";
    id: string;
    label: string;
    icon: string;
    kind: "action";
    onActivate(context: ExperimentalSidebarFooterActionContext): void | Promise<void>;
    runtime: ExperimentalSidebarFooterItemRuntime;
}
type CollectedSidebarFooterItem = CollectedCompatibilitySidebarFooterItem | CollectedManagedSidebarFooterItem;
declare function adaptSidebarFooterAction(registration: PluginSidebarFooterActionRegistration): CollectedCompatibilitySidebarFooterItem;
/** Validated registrations produced by one plugin app setup execution. */
interface CollectedPluginAppRegistrations {
    homepageSections: PluginHomepageSectionRegistration[];
    settingsSections: PluginSettingsSectionRegistration[];
    appOverlays: ExperimentalAppOverlayRegistration[];
    navPanels: PluginNavPanelRegistration[];
    threadPanelActions: PluginThreadPanelActionRegistration[];
    newThreadPanelActions: PluginNewThreadPanelActionRegistration[];
    composerCustomizations: ComposerCustomization[];
    pendingInteractions: PluginPendingInteractionRegistration[];
    sidebarFooterActions: PluginSidebarFooterActionRegistration[];
    experimentalSidebarFooterItems: CollectedExperimentalSidebarFooterItem[];
    experimentalSidebarNavigations: ExperimentalSidebarNavigationRegistration[];
    threadLists: PluginThreadListRegistration[];
    threadHeaderActions: PluginThreadHeaderActionRegistration[];
    fileOpeners: PluginFileOpenerRegistration[];
    sourceCodeRenderers: PluginSourceCodeRendererRegistration[];
    diffRenderers: PluginDiffRendererRegistration[];
    messageDirectives: PluginMessageDirectiveRegistration[];
    messageActions: PluginMessageActionRegistration[];
    commandPaletteActions: PluginCommandPaletteActionRegistration[];
    providerIcons: PluginProviderIconRegistration[];
    timelineRenderers: PluginTimelineRendererRegistration[];
    contentScripts: PluginContentScriptRegistration[];
}
declare function getCollectedSidebarFooterItems(registrations: object): readonly CollectedSidebarFooterItem[] | null;
/**
 * Run a plugin app definition against the canonical validating collector.
 * Both the BB app and the public test harness use this implementation so a
 * registration accepted by one cannot be rejected or normalized differently
 * by the other.
 */
declare function collectPluginAppRegistrations(definition: PluginAppDefinition, onComposerCustomizationRejected?: (reason: string) => void): CollectedPluginAppRegistrations;

export { adaptSidebarFooterAction, collectPluginAppRegistrations, getCollectedSidebarFooterItems };
export type { CollectedCompatibilitySidebarFooterItem, CollectedExperimentalSidebarFooterItem, CollectedManagedSidebarFooterItem, CollectedPluginAppRegistrations, CollectedSidebarFooterItem, ExperimentalSidebarFooterCommandKind, ExperimentalSidebarFooterItemRuntime, ExperimentalSidebarFooterRuntimeSnapshot };
