// Portable type declarations for `@get-bb/plugin-sdk`. Unpublished BB
// workspace contracts are flattened; public subpaths may reuse the
// package root without requiring any other @bb/* package.
//
// Confused by the API, or need a symbol that isn't here? Clone the BB repo
// and read the real source: https://github.com/get-bb/bb

import { z } from 'zod';
import { Writable, Readable } from 'node:stream';

declare const acpReasoningCliSchema: z.ZodObject<{
    defaultLevel: z.ZodOptional<z.ZodEnum<{
        high: "high";
        low: "low";
        max: "max";
        medium: "medium";
        none: "none";
        ultra: "ultra";
        ultracode: "ultracode";
        xhigh: "xhigh";
    }>>;
    flag: z.ZodString;
    levelValues: z.ZodOptional<z.ZodRecord<z.ZodEnum<{
        high: "high";
        low: "low";
        max: "max";
        medium: "medium";
        none: "none";
        ultra: "ultra";
        ultracode: "ultracode";
        xhigh: "xhigh";
    }> & z.core.$partial, z.ZodString>>;
    supportedLevels: z.ZodArray<z.ZodEnum<{
        high: "high";
        low: "low";
        max: "max";
        medium: "medium";
        none: "none";
        ultra: "ultra";
        ultracode: "ultracode";
        xhigh: "xhigh";
    }>>;
}, z.core.$strict>;
declare const acpNativeReasoningSchema: z.ZodObject<{
    configId: z.ZodString;
    defaultLevel: z.ZodOptional<z.ZodEnum<{
        high: "high";
        low: "low";
        max: "max";
        medium: "medium";
        none: "none";
        ultra: "ultra";
        ultracode: "ultracode";
        xhigh: "xhigh";
    }>>;
    levelValues: z.ZodOptional<z.ZodRecord<z.ZodEnum<{
        high: "high";
        low: "low";
        max: "max";
        medium: "medium";
        none: "none";
        ultra: "ultra";
        ultracode: "ultracode";
        xhigh: "xhigh";
    }> & z.core.$partial, z.ZodString>>;
    supportedLevels: z.ZodArray<z.ZodEnum<{
        high: "high";
        low: "low";
        max: "max";
        medium: "medium";
        none: "none";
        ultra: "ultra";
        ultracode: "ultracode";
        xhigh: "xhigh";
    }>>;
}, z.core.$strict>;
declare const acpPermissionCliSchema: z.ZodObject<{
    full: z.ZodOptional<z.ZodArray<z.ZodString>>;
    insertAfterArgs: z.ZodOptional<z.ZodNumber>;
    readonly: z.ZodOptional<z.ZodArray<z.ZodString>>;
    workspaceWrite: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strict>;

interface JsonObject {
    [key: string]: JsonValue;
}
type JsonValue = string | number | boolean | null | JsonValue[] | JsonObject;
declare const jsonValueSchema: z.ZodType<JsonValue>;

declare const LOCAL_WORKFLOW_TASK_TYPE = "local_workflow";
declare const LOCAL_BASH_TASK_TYPE = "local_bash";
declare function isBackgroundAgentTaskType(taskType: string): boolean;
declare const backgroundTaskStatusSchema: z.ZodEnum<{
    completed: "completed";
    failed: "failed";
    killed: "killed";
    paused: "paused";
    pending: "pending";
    running: "running";
    stopped: "stopped";
}>;
type BackgroundTaskStatus = z.infer<typeof backgroundTaskStatusSchema>;
declare const workflowAgentStateSchema: z.ZodEnum<{
    done: "done";
    failed: "failed";
    queued: "queued";
    running: "running";
    skipped: "skipped";
}>;
type WorkflowAgentState = z.infer<typeof workflowAgentStateSchema>;
declare const workflowAgentSnapshotSchema: z.ZodObject<{
    agentType: z.ZodOptional<z.ZodString>;
    attempt: z.ZodNumber;
    cached: z.ZodBoolean;
    durationMs: z.ZodOptional<z.ZodNumber>;
    error: z.ZodOptional<z.ZodString>;
    index: z.ZodNumber;
    isolation: z.ZodOptional<z.ZodString>;
    label: z.ZodString;
    lastProgressAt: z.ZodNumber;
    lastToolName: z.ZodOptional<z.ZodString>;
    lastToolSummary: z.ZodOptional<z.ZodString>;
    model: z.ZodString;
    phaseIndex: z.ZodOptional<z.ZodNumber>;
    phaseTitle: z.ZodOptional<z.ZodString>;
    promptPreview: z.ZodOptional<z.ZodString>;
    queuedAt: z.ZodOptional<z.ZodNumber>;
    resultPreview: z.ZodOptional<z.ZodString>;
    startedAt: z.ZodOptional<z.ZodNumber>;
    state: z.ZodEnum<{
        done: "done";
        failed: "failed";
        queued: "queued";
        running: "running";
        skipped: "skipped";
    }>;
    tokens: z.ZodOptional<z.ZodNumber>;
    toolCalls: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
type WorkflowAgentSnapshot = z.infer<typeof workflowAgentSnapshotSchema>;
declare const workflowPhaseSnapshotSchema: z.ZodObject<{
    index: z.ZodNumber;
    kind: z.ZodOptional<z.ZodString>;
    title: z.ZodString;
}, z.core.$strip>;
type WorkflowPhaseSnapshot = z.infer<typeof workflowPhaseSnapshotSchema>;
declare const workflowProgressSnapshotSchema: z.ZodObject<{
    agents: z.ZodArray<z.ZodObject<{
        agentType: z.ZodOptional<z.ZodString>;
        attempt: z.ZodNumber;
        cached: z.ZodBoolean;
        durationMs: z.ZodOptional<z.ZodNumber>;
        error: z.ZodOptional<z.ZodString>;
        index: z.ZodNumber;
        isolation: z.ZodOptional<z.ZodString>;
        label: z.ZodString;
        lastProgressAt: z.ZodNumber;
        lastToolName: z.ZodOptional<z.ZodString>;
        lastToolSummary: z.ZodOptional<z.ZodString>;
        model: z.ZodString;
        phaseIndex: z.ZodOptional<z.ZodNumber>;
        phaseTitle: z.ZodOptional<z.ZodString>;
        promptPreview: z.ZodOptional<z.ZodString>;
        queuedAt: z.ZodOptional<z.ZodNumber>;
        resultPreview: z.ZodOptional<z.ZodString>;
        startedAt: z.ZodOptional<z.ZodNumber>;
        state: z.ZodEnum<{
            done: "done";
            failed: "failed";
            queued: "queued";
            running: "running";
            skipped: "skipped";
        }>;
        tokens: z.ZodOptional<z.ZodNumber>;
        toolCalls: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
    phases: z.ZodArray<z.ZodObject<{
        index: z.ZodNumber;
        kind: z.ZodOptional<z.ZodString>;
        title: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
type WorkflowProgressSnapshot = z.infer<typeof workflowProgressSnapshotSchema>;
declare const backgroundTaskUsageSchema: z.ZodObject<{
    durationMs: z.ZodNumber;
    toolUses: z.ZodNumber;
    totalTokens: z.ZodNumber;
}, z.core.$strip>;
type BackgroundTaskUsage = z.infer<typeof backgroundTaskUsageSchema>;
declare function backgroundTaskItemStatus(taskStatus: BackgroundTaskStatus): "completed" | "failed" | "interrupted" | "pending";
declare function isSettledBackgroundTaskStatus(taskStatus: BackgroundTaskStatus): boolean;

declare const threadEventItemPresentationSchema: z.ZodObject<{
    badge: z.ZodOptional<z.ZodObject<{
        glyph: z.ZodString;
        hint: z.ZodString;
        label: z.ZodString;
        tone: z.ZodEnum<{
            destructive: "destructive";
            neutral: "neutral";
        }>;
    }, z.core.$strip>>;
    detail: z.ZodOptional<z.ZodString>;
    icon: z.ZodObject<{
        glyph: z.ZodString;
    }, z.core.$strip>;
    label: z.ZodObject<{
        completed: z.ZodString;
        pending: z.ZodString;
    }, z.core.$strip>;
    suppress: z.ZodOptional<z.ZodBoolean>;
    tint: z.ZodOptional<z.ZodObject<{
        dark: z.ZodString;
        light: z.ZodString;
    }, z.core.$strip>>;
    title: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
type ThreadEventItemPresentation = z.infer<typeof threadEventItemPresentationSchema>;

declare function toPositiveNumber(value: unknown): number | undefined;

declare const pendingInteractionCommandActionSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    command: z.ZodString;
    name: z.ZodString;
    path: z.ZodString;
    type: z.ZodLiteral<"read">;
}, z.core.$strip>, z.ZodObject<{
    command: z.ZodString;
    path: z.ZodNullable<z.ZodString>;
    type: z.ZodLiteral<"listFiles">;
}, z.core.$strip>, z.ZodObject<{
    command: z.ZodString;
    path: z.ZodNullable<z.ZodString>;
    query: z.ZodNullable<z.ZodString>;
    type: z.ZodLiteral<"search">;
}, z.core.$strip>, z.ZodObject<{
    command: z.ZodString;
    type: z.ZodLiteral<"unknown">;
}, z.core.$strip>], "type">;
type PendingInteractionCommandAction = z.infer<typeof pendingInteractionCommandActionSchema>;
declare const pendingInteractionNetworkPermissionsSchema: z.ZodObject<{
    enabled: z.ZodNullable<z.ZodBoolean>;
}, z.core.$strip>;
declare const pendingInteractionFileSystemPermissionsSchema: z.ZodObject<{
    read: z.ZodArray<z.ZodString>;
    write: z.ZodArray<z.ZodString>;
}, z.core.$strip>;
declare const pendingInteractionMacOsPermissionsSchema: z.ZodObject<{
    accessibility: z.ZodBoolean;
    automations: z.ZodUnion<readonly [z.ZodLiteral<"none">, z.ZodLiteral<"all">, z.ZodObject<{
        bundleIds: z.ZodArray<z.ZodString>;
        kind: z.ZodLiteral<"bundle_ids">;
    }, z.core.$strip>]>;
    calendar: z.ZodBoolean;
    contacts: z.ZodEnum<{
        none: "none";
        read_only: "read_only";
        read_write: "read_write";
    }>;
    launchServices: z.ZodBoolean;
    preferences: z.ZodEnum<{
        none: "none";
        read_only: "read_only";
        read_write: "read_write";
    }>;
    reminders: z.ZodBoolean;
}, z.core.$strip>;
declare const pendingInteractionRequestedPermissionProfileSchema: z.ZodObject<{
    fileSystem: z.ZodNullable<z.ZodObject<{
        read: z.ZodArray<z.ZodString>;
        write: z.ZodArray<z.ZodString>;
    }, z.core.$strip>>;
    macos: z.ZodNullable<z.ZodObject<{
        accessibility: z.ZodBoolean;
        automations: z.ZodUnion<readonly [z.ZodLiteral<"none">, z.ZodLiteral<"all">, z.ZodObject<{
            bundleIds: z.ZodArray<z.ZodString>;
            kind: z.ZodLiteral<"bundle_ids">;
        }, z.core.$strip>]>;
        calendar: z.ZodBoolean;
        contacts: z.ZodEnum<{
            none: "none";
            read_only: "read_only";
            read_write: "read_write";
        }>;
        launchServices: z.ZodBoolean;
        preferences: z.ZodEnum<{
            none: "none";
            read_only: "read_only";
            read_write: "read_write";
        }>;
        reminders: z.ZodBoolean;
    }, z.core.$strip>>;
    network: z.ZodNullable<z.ZodObject<{
        enabled: z.ZodNullable<z.ZodBoolean>;
    }, z.core.$strip>>;
}, z.core.$strip>;
type PendingInteractionRequestedPermissionProfile = z.infer<typeof pendingInteractionRequestedPermissionProfileSchema>;
declare const pendingInteractionGrantablePermissionProfileSchema: z.ZodObject<{
    fileSystem: z.ZodNullable<z.ZodObject<{
        read: z.ZodArray<z.ZodString>;
        write: z.ZodArray<z.ZodString>;
    }, z.core.$strip>>;
    network: z.ZodNullable<z.ZodObject<{
        enabled: z.ZodNullable<z.ZodBoolean>;
    }, z.core.$strip>>;
}, z.core.$strict>;
type PendingInteractionGrantablePermissionProfile = z.infer<typeof pendingInteractionGrantablePermissionProfileSchema>;
declare const pendingInteractionGrantedPermissionProfileSchema: z.ZodObject<{
    fileSystem: z.ZodNullable<z.ZodObject<{
        read: z.ZodArray<z.ZodString>;
        write: z.ZodArray<z.ZodString>;
    }, z.core.$strip>>;
    network: z.ZodNullable<z.ZodObject<{
        enabled: z.ZodNullable<z.ZodBoolean>;
    }, z.core.$strip>>;
}, z.core.$strict>;
type PendingInteractionGrantedPermissionProfile = z.infer<typeof pendingInteractionGrantedPermissionProfileSchema>;
declare const pendingInteractionApprovalDecisionSchema: z.ZodEnum<{
    allow_for_session: "allow_for_session";
    allow_once: "allow_once";
    deny: "deny";
}>;
type PendingInteractionApprovalDecision = z.infer<typeof pendingInteractionApprovalDecisionSchema>;
declare const pendingInteractionApprovalSubjectSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    actions: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        command: z.ZodString;
        name: z.ZodString;
        path: z.ZodString;
        type: z.ZodLiteral<"read">;
    }, z.core.$strip>, z.ZodObject<{
        command: z.ZodString;
        path: z.ZodNullable<z.ZodString>;
        type: z.ZodLiteral<"listFiles">;
    }, z.core.$strip>, z.ZodObject<{
        command: z.ZodString;
        path: z.ZodNullable<z.ZodString>;
        query: z.ZodNullable<z.ZodString>;
        type: z.ZodLiteral<"search">;
    }, z.core.$strip>, z.ZodObject<{
        command: z.ZodString;
        type: z.ZodLiteral<"unknown">;
    }, z.core.$strip>], "type">>;
    command: z.ZodString;
    cwd: z.ZodNullable<z.ZodString>;
    itemId: z.ZodString;
    kind: z.ZodLiteral<"command">;
    sessionGrant: z.ZodNullable<z.ZodObject<{
        fileSystem: z.ZodNullable<z.ZodObject<{
            read: z.ZodArray<z.ZodString>;
            write: z.ZodArray<z.ZodString>;
        }, z.core.$strip>>;
        network: z.ZodNullable<z.ZodObject<{
            enabled: z.ZodNullable<z.ZodBoolean>;
        }, z.core.$strip>>;
    }, z.core.$strict>>;
}, z.core.$strip>, z.ZodObject<{
    itemId: z.ZodString;
    kind: z.ZodLiteral<"file_change">;
    sessionGrant: z.ZodNullable<z.ZodObject<{
        fileSystem: z.ZodNullable<z.ZodObject<{
            read: z.ZodArray<z.ZodString>;
            write: z.ZodArray<z.ZodString>;
        }, z.core.$strip>>;
        network: z.ZodNullable<z.ZodObject<{
            enabled: z.ZodNullable<z.ZodBoolean>;
        }, z.core.$strip>>;
    }, z.core.$strict>>;
    writeScope: z.ZodNullable<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    itemId: z.ZodString;
    kind: z.ZodLiteral<"permission_grant">;
    permissions: z.ZodObject<{
        fileSystem: z.ZodNullable<z.ZodObject<{
            read: z.ZodArray<z.ZodString>;
            write: z.ZodArray<z.ZodString>;
        }, z.core.$strip>>;
        network: z.ZodNullable<z.ZodObject<{
            enabled: z.ZodNullable<z.ZodBoolean>;
        }, z.core.$strip>>;
    }, z.core.$strict>;
    toolName: z.ZodNullable<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    itemId: z.ZodString;
    kind: z.ZodLiteral<"plan">;
    plan: z.ZodString;
    planFilePath: z.ZodNullable<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    itemId: z.ZodString;
    kind: z.ZodLiteral<"tool_use">;
    presentation: z.ZodObject<{
        badge: z.ZodOptional<z.ZodObject<{
            glyph: z.ZodString;
            hint: z.ZodString;
            label: z.ZodString;
            tone: z.ZodEnum<{
                destructive: "destructive";
                neutral: "neutral";
            }>;
        }, z.core.$strip>>;
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    tool: z.ZodString;
}, z.core.$strip>], "kind">;
type PendingInteractionApprovalSubject = z.infer<typeof pendingInteractionApprovalSubjectSchema>;
declare const approvalPendingInteractionPayloadSchema: z.ZodObject<{
    availableDecisions: z.ZodArray<z.ZodEnum<{
        allow_for_session: "allow_for_session";
        allow_once: "allow_once";
        deny: "deny";
    }>>;
    kind: z.ZodLiteral<"approval">;
    reason: z.ZodNullable<z.ZodString>;
    subject: z.ZodDiscriminatedUnion<[z.ZodObject<{
        actions: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            command: z.ZodString;
            name: z.ZodString;
            path: z.ZodString;
            type: z.ZodLiteral<"read">;
        }, z.core.$strip>, z.ZodObject<{
            command: z.ZodString;
            path: z.ZodNullable<z.ZodString>;
            type: z.ZodLiteral<"listFiles">;
        }, z.core.$strip>, z.ZodObject<{
            command: z.ZodString;
            path: z.ZodNullable<z.ZodString>;
            query: z.ZodNullable<z.ZodString>;
            type: z.ZodLiteral<"search">;
        }, z.core.$strip>, z.ZodObject<{
            command: z.ZodString;
            type: z.ZodLiteral<"unknown">;
        }, z.core.$strip>], "type">>;
        command: z.ZodString;
        cwd: z.ZodNullable<z.ZodString>;
        itemId: z.ZodString;
        kind: z.ZodLiteral<"command">;
        sessionGrant: z.ZodNullable<z.ZodObject<{
            fileSystem: z.ZodNullable<z.ZodObject<{
                read: z.ZodArray<z.ZodString>;
                write: z.ZodArray<z.ZodString>;
            }, z.core.$strip>>;
            network: z.ZodNullable<z.ZodObject<{
                enabled: z.ZodNullable<z.ZodBoolean>;
            }, z.core.$strip>>;
        }, z.core.$strict>>;
    }, z.core.$strip>, z.ZodObject<{
        itemId: z.ZodString;
        kind: z.ZodLiteral<"file_change">;
        sessionGrant: z.ZodNullable<z.ZodObject<{
            fileSystem: z.ZodNullable<z.ZodObject<{
                read: z.ZodArray<z.ZodString>;
                write: z.ZodArray<z.ZodString>;
            }, z.core.$strip>>;
            network: z.ZodNullable<z.ZodObject<{
                enabled: z.ZodNullable<z.ZodBoolean>;
            }, z.core.$strip>>;
        }, z.core.$strict>>;
        writeScope: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        itemId: z.ZodString;
        kind: z.ZodLiteral<"permission_grant">;
        permissions: z.ZodObject<{
            fileSystem: z.ZodNullable<z.ZodObject<{
                read: z.ZodArray<z.ZodString>;
                write: z.ZodArray<z.ZodString>;
            }, z.core.$strip>>;
            network: z.ZodNullable<z.ZodObject<{
                enabled: z.ZodNullable<z.ZodBoolean>;
            }, z.core.$strip>>;
        }, z.core.$strict>;
        toolName: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        itemId: z.ZodString;
        kind: z.ZodLiteral<"plan">;
        plan: z.ZodString;
        planFilePath: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        itemId: z.ZodString;
        kind: z.ZodLiteral<"tool_use">;
        presentation: z.ZodObject<{
            badge: z.ZodOptional<z.ZodObject<{
                glyph: z.ZodString;
                hint: z.ZodString;
                label: z.ZodString;
                tone: z.ZodEnum<{
                    destructive: "destructive";
                    neutral: "neutral";
                }>;
            }, z.core.$strip>>;
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        tool: z.ZodString;
    }, z.core.$strip>], "kind">;
}, z.core.$strip>;
type ApprovalPendingInteractionPayload = z.infer<typeof approvalPendingInteractionPayloadSchema>;
declare const USER_QUESTION_MAX_QUESTIONS = 4;
declare const USER_QUESTION_MAX_OPTIONS = 4;
declare const pendingInteractionUserQuestionQuestionSchema: z.ZodObject<{
    allowFreeText: z.ZodBoolean;
    id: z.ZodString;
    multiSelect: z.ZodBoolean;
    options: z.ZodOptional<z.ZodArray<z.ZodObject<{
        description: z.ZodOptional<z.ZodString>;
        label: z.ZodString;
        value: z.ZodString;
    }, z.core.$strip>>>;
    prompt: z.ZodString;
    shortLabel: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
type PendingInteractionUserQuestionQuestion = z.infer<typeof pendingInteractionUserQuestionQuestionSchema>;
declare const userQuestionPendingInteractionPayloadSchema: z.ZodObject<{
    kind: z.ZodLiteral<"user_question">;
    questions: z.ZodArray<z.ZodObject<{
        allowFreeText: z.ZodBoolean;
        id: z.ZodString;
        multiSelect: z.ZodBoolean;
        options: z.ZodOptional<z.ZodArray<z.ZodObject<{
            description: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            value: z.ZodString;
        }, z.core.$strip>>>;
        prompt: z.ZodString;
        shortLabel: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
}, z.core.$strip>;
type UserQuestionPendingInteractionPayload = z.infer<typeof userQuestionPendingInteractionPayloadSchema>;
declare const pluginPendingInteractionPayloadSchema: z.ZodObject<{
    data: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
    kind: z.ZodLiteral<"plugin">;
    title: z.ZodString;
}, z.core.$strip>;
type PluginPendingInteractionPayload = z.infer<typeof pluginPendingInteractionPayloadSchema>;
declare const interactionRequestPayloadSchema: z.ZodUnion<readonly [z.ZodObject<{
    kind: z.ZodLiteral<"user_question">;
    questions: z.ZodArray<z.ZodObject<{
        allowFreeText: z.ZodBoolean;
        id: z.ZodString;
        multiSelect: z.ZodBoolean;
        options: z.ZodOptional<z.ZodArray<z.ZodObject<{
            description: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            value: z.ZodString;
        }, z.core.$strip>>>;
        prompt: z.ZodString;
        shortLabel: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
}, z.core.$strip>, z.ZodObject<{
    data: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
    kind: z.ZodString & z.ZodType<`${string}/${string}`, string, z.core.$ZodTypeInternals<`${string}/${string}`, string>>;
    title: z.ZodString;
}, z.core.$strip>]>;
type InteractionRequestPayload = z.infer<typeof interactionRequestPayloadSchema>;
declare const pendingInteractionPayloadSchema: z.ZodUnion<readonly [z.ZodObject<{
    availableDecisions: z.ZodArray<z.ZodEnum<{
        allow_for_session: "allow_for_session";
        allow_once: "allow_once";
        deny: "deny";
    }>>;
    kind: z.ZodLiteral<"approval">;
    reason: z.ZodNullable<z.ZodString>;
    subject: z.ZodDiscriminatedUnion<[z.ZodObject<{
        actions: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            command: z.ZodString;
            name: z.ZodString;
            path: z.ZodString;
            type: z.ZodLiteral<"read">;
        }, z.core.$strip>, z.ZodObject<{
            command: z.ZodString;
            path: z.ZodNullable<z.ZodString>;
            type: z.ZodLiteral<"listFiles">;
        }, z.core.$strip>, z.ZodObject<{
            command: z.ZodString;
            path: z.ZodNullable<z.ZodString>;
            query: z.ZodNullable<z.ZodString>;
            type: z.ZodLiteral<"search">;
        }, z.core.$strip>, z.ZodObject<{
            command: z.ZodString;
            type: z.ZodLiteral<"unknown">;
        }, z.core.$strip>], "type">>;
        command: z.ZodString;
        cwd: z.ZodNullable<z.ZodString>;
        itemId: z.ZodString;
        kind: z.ZodLiteral<"command">;
        sessionGrant: z.ZodNullable<z.ZodObject<{
            fileSystem: z.ZodNullable<z.ZodObject<{
                read: z.ZodArray<z.ZodString>;
                write: z.ZodArray<z.ZodString>;
            }, z.core.$strip>>;
            network: z.ZodNullable<z.ZodObject<{
                enabled: z.ZodNullable<z.ZodBoolean>;
            }, z.core.$strip>>;
        }, z.core.$strict>>;
    }, z.core.$strip>, z.ZodObject<{
        itemId: z.ZodString;
        kind: z.ZodLiteral<"file_change">;
        sessionGrant: z.ZodNullable<z.ZodObject<{
            fileSystem: z.ZodNullable<z.ZodObject<{
                read: z.ZodArray<z.ZodString>;
                write: z.ZodArray<z.ZodString>;
            }, z.core.$strip>>;
            network: z.ZodNullable<z.ZodObject<{
                enabled: z.ZodNullable<z.ZodBoolean>;
            }, z.core.$strip>>;
        }, z.core.$strict>>;
        writeScope: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        itemId: z.ZodString;
        kind: z.ZodLiteral<"permission_grant">;
        permissions: z.ZodObject<{
            fileSystem: z.ZodNullable<z.ZodObject<{
                read: z.ZodArray<z.ZodString>;
                write: z.ZodArray<z.ZodString>;
            }, z.core.$strip>>;
            network: z.ZodNullable<z.ZodObject<{
                enabled: z.ZodNullable<z.ZodBoolean>;
            }, z.core.$strip>>;
        }, z.core.$strict>;
        toolName: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        itemId: z.ZodString;
        kind: z.ZodLiteral<"plan">;
        plan: z.ZodString;
        planFilePath: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        itemId: z.ZodString;
        kind: z.ZodLiteral<"tool_use">;
        presentation: z.ZodObject<{
            badge: z.ZodOptional<z.ZodObject<{
                glyph: z.ZodString;
                hint: z.ZodString;
                label: z.ZodString;
                tone: z.ZodEnum<{
                    destructive: "destructive";
                    neutral: "neutral";
                }>;
            }, z.core.$strip>>;
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        tool: z.ZodString;
    }, z.core.$strip>], "kind">;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"user_question">;
    questions: z.ZodArray<z.ZodObject<{
        allowFreeText: z.ZodBoolean;
        id: z.ZodString;
        multiSelect: z.ZodBoolean;
        options: z.ZodOptional<z.ZodArray<z.ZodObject<{
            description: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            value: z.ZodString;
        }, z.core.$strip>>>;
        prompt: z.ZodString;
        shortLabel: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
}, z.core.$strip>, z.ZodObject<{
    data: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
    kind: z.ZodString & z.ZodType<`${string}/${string}`, string, z.core.$ZodTypeInternals<`${string}/${string}`, string>>;
    title: z.ZodString;
}, z.core.$strip>]>;
type PendingInteractionPayload = z.infer<typeof pendingInteractionPayloadSchema>;
type AnyPendingInteractionPayload = PendingInteractionPayload | PluginPendingInteractionPayload;
declare function isApprovalPendingInteractionPayload(payload: AnyPendingInteractionPayload): payload is ApprovalPendingInteractionPayload;
declare function isUserQuestionPendingInteractionPayload(payload: AnyPendingInteractionPayload): payload is UserQuestionPendingInteractionPayload;
declare const approvalPendingInteractionResolutionSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    decision: z.ZodLiteral<"allow_once">;
    grantedPermissions: z.ZodNullable<z.ZodObject<{
        fileSystem: z.ZodNullable<z.ZodObject<{
            read: z.ZodArray<z.ZodString>;
            write: z.ZodArray<z.ZodString>;
        }, z.core.$strip>>;
        network: z.ZodNullable<z.ZodObject<{
            enabled: z.ZodNullable<z.ZodBoolean>;
        }, z.core.$strip>>;
    }, z.core.$strict>>;
}, z.core.$strip>, z.ZodObject<{
    decision: z.ZodLiteral<"allow_for_session">;
    grantedPermissions: z.ZodNullable<z.ZodObject<{
        fileSystem: z.ZodNullable<z.ZodObject<{
            read: z.ZodArray<z.ZodString>;
            write: z.ZodArray<z.ZodString>;
        }, z.core.$strip>>;
        network: z.ZodNullable<z.ZodObject<{
            enabled: z.ZodNullable<z.ZodBoolean>;
        }, z.core.$strip>>;
    }, z.core.$strict>>;
}, z.core.$strip>, z.ZodObject<{
    decision: z.ZodLiteral<"deny">;
}, z.core.$strip>], "decision">;
type ApprovalPendingInteractionResolution = z.infer<typeof approvalPendingInteractionResolutionSchema>;
declare const userQuestionPendingInteractionResolutionSchema: z.ZodObject<{
    answers: z.ZodRecord<z.ZodString, z.ZodObject<{
        freeText: z.ZodOptional<z.ZodString>;
        selected: z.ZodArray<z.ZodString>;
    }, z.core.$strip>>;
    kind: z.ZodLiteral<"user_answer">;
}, z.core.$strip>;
type UserQuestionPendingInteractionResolution = z.infer<typeof userQuestionPendingInteractionResolutionSchema>;
declare const pendingInteractionResolutionSchema: z.ZodUnion<readonly [z.ZodDiscriminatedUnion<[z.ZodObject<{
    decision: z.ZodLiteral<"allow_once">;
    grantedPermissions: z.ZodNullable<z.ZodObject<{
        fileSystem: z.ZodNullable<z.ZodObject<{
            read: z.ZodArray<z.ZodString>;
            write: z.ZodArray<z.ZodString>;
        }, z.core.$strip>>;
        network: z.ZodNullable<z.ZodObject<{
            enabled: z.ZodNullable<z.ZodBoolean>;
        }, z.core.$strip>>;
    }, z.core.$strict>>;
}, z.core.$strip>, z.ZodObject<{
    decision: z.ZodLiteral<"allow_for_session">;
    grantedPermissions: z.ZodNullable<z.ZodObject<{
        fileSystem: z.ZodNullable<z.ZodObject<{
            read: z.ZodArray<z.ZodString>;
            write: z.ZodArray<z.ZodString>;
        }, z.core.$strip>>;
        network: z.ZodNullable<z.ZodObject<{
            enabled: z.ZodNullable<z.ZodBoolean>;
        }, z.core.$strip>>;
    }, z.core.$strict>>;
}, z.core.$strip>, z.ZodObject<{
    decision: z.ZodLiteral<"deny">;
}, z.core.$strip>], "decision">, z.ZodObject<{
    answers: z.ZodRecord<z.ZodString, z.ZodObject<{
        freeText: z.ZodOptional<z.ZodString>;
        selected: z.ZodArray<z.ZodString>;
    }, z.core.$strip>>;
    kind: z.ZodLiteral<"user_answer">;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"plugin_submitted">;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"request_answer">;
    value: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
}, z.core.$strip>]>;
type PendingInteractionResolution = z.infer<typeof pendingInteractionResolutionSchema>;
declare function isApprovalPendingInteractionResolution(resolution: PendingInteractionResolution): resolution is ApprovalPendingInteractionResolution;
declare function isUserQuestionPendingInteractionResolution(resolution: PendingInteractionResolution): resolution is UserQuestionPendingInteractionResolution;
declare const approvalInteractionOutcomeSchema: z.ZodObject<{
    payload: z.ZodObject<{
        availableDecisions: z.ZodArray<z.ZodEnum<{
            allow_for_session: "allow_for_session";
            allow_once: "allow_once";
            deny: "deny";
        }>>;
        kind: z.ZodLiteral<"approval">;
        reason: z.ZodNullable<z.ZodString>;
        subject: z.ZodDiscriminatedUnion<[z.ZodObject<{
            actions: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                command: z.ZodString;
                name: z.ZodString;
                path: z.ZodString;
                type: z.ZodLiteral<"read">;
            }, z.core.$strip>, z.ZodObject<{
                command: z.ZodString;
                path: z.ZodNullable<z.ZodString>;
                type: z.ZodLiteral<"listFiles">;
            }, z.core.$strip>, z.ZodObject<{
                command: z.ZodString;
                path: z.ZodNullable<z.ZodString>;
                query: z.ZodNullable<z.ZodString>;
                type: z.ZodLiteral<"search">;
            }, z.core.$strip>, z.ZodObject<{
                command: z.ZodString;
                type: z.ZodLiteral<"unknown">;
            }, z.core.$strip>], "type">>;
            command: z.ZodString;
            cwd: z.ZodNullable<z.ZodString>;
            itemId: z.ZodString;
            kind: z.ZodLiteral<"command">;
            sessionGrant: z.ZodNullable<z.ZodObject<{
                fileSystem: z.ZodNullable<z.ZodObject<{
                    read: z.ZodArray<z.ZodString>;
                    write: z.ZodArray<z.ZodString>;
                }, z.core.$strip>>;
                network: z.ZodNullable<z.ZodObject<{
                    enabled: z.ZodNullable<z.ZodBoolean>;
                }, z.core.$strip>>;
            }, z.core.$strict>>;
        }, z.core.$strip>, z.ZodObject<{
            itemId: z.ZodString;
            kind: z.ZodLiteral<"file_change">;
            sessionGrant: z.ZodNullable<z.ZodObject<{
                fileSystem: z.ZodNullable<z.ZodObject<{
                    read: z.ZodArray<z.ZodString>;
                    write: z.ZodArray<z.ZodString>;
                }, z.core.$strip>>;
                network: z.ZodNullable<z.ZodObject<{
                    enabled: z.ZodNullable<z.ZodBoolean>;
                }, z.core.$strip>>;
            }, z.core.$strict>>;
            writeScope: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            itemId: z.ZodString;
            kind: z.ZodLiteral<"permission_grant">;
            permissions: z.ZodObject<{
                fileSystem: z.ZodNullable<z.ZodObject<{
                    read: z.ZodArray<z.ZodString>;
                    write: z.ZodArray<z.ZodString>;
                }, z.core.$strip>>;
                network: z.ZodNullable<z.ZodObject<{
                    enabled: z.ZodNullable<z.ZodBoolean>;
                }, z.core.$strip>>;
            }, z.core.$strict>;
            toolName: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            itemId: z.ZodString;
            kind: z.ZodLiteral<"plan">;
            plan: z.ZodString;
            planFilePath: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            itemId: z.ZodString;
            kind: z.ZodLiteral<"tool_use">;
            presentation: z.ZodObject<{
                badge: z.ZodOptional<z.ZodObject<{
                    glyph: z.ZodString;
                    hint: z.ZodString;
                    label: z.ZodString;
                    tone: z.ZodEnum<{
                        destructive: "destructive";
                        neutral: "neutral";
                    }>;
                }, z.core.$strip>>;
                detail: z.ZodOptional<z.ZodString>;
                icon: z.ZodObject<{
                    glyph: z.ZodString;
                }, z.core.$strip>;
                label: z.ZodObject<{
                    completed: z.ZodString;
                    pending: z.ZodString;
                }, z.core.$strip>;
                suppress: z.ZodOptional<z.ZodBoolean>;
                tint: z.ZodOptional<z.ZodObject<{
                    dark: z.ZodString;
                    light: z.ZodString;
                }, z.core.$strip>>;
                title: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>;
            tool: z.ZodString;
        }, z.core.$strip>], "kind">;
    }, z.core.$strip>;
    resolution: z.ZodDiscriminatedUnion<[z.ZodObject<{
        decision: z.ZodLiteral<"allow_once">;
        grantedPermissions: z.ZodNullable<z.ZodObject<{
            fileSystem: z.ZodNullable<z.ZodObject<{
                read: z.ZodArray<z.ZodString>;
                write: z.ZodArray<z.ZodString>;
            }, z.core.$strip>>;
            network: z.ZodNullable<z.ZodObject<{
                enabled: z.ZodNullable<z.ZodBoolean>;
            }, z.core.$strip>>;
        }, z.core.$strict>>;
    }, z.core.$strip>, z.ZodObject<{
        decision: z.ZodLiteral<"allow_for_session">;
        grantedPermissions: z.ZodNullable<z.ZodObject<{
            fileSystem: z.ZodNullable<z.ZodObject<{
                read: z.ZodArray<z.ZodString>;
                write: z.ZodArray<z.ZodString>;
            }, z.core.$strip>>;
            network: z.ZodNullable<z.ZodObject<{
                enabled: z.ZodNullable<z.ZodBoolean>;
            }, z.core.$strip>>;
        }, z.core.$strict>>;
    }, z.core.$strip>, z.ZodObject<{
        decision: z.ZodLiteral<"deny">;
    }, z.core.$strip>], "decision">;
}, z.core.$strip>;
type ApprovalInteractionOutcome = z.infer<typeof approvalInteractionOutcomeSchema>;
declare const userQuestionInteractionOutcomeSchema: z.ZodObject<{
    payload: z.ZodObject<{
        kind: z.ZodLiteral<"user_question">;
        questions: z.ZodArray<z.ZodObject<{
            allowFreeText: z.ZodBoolean;
            id: z.ZodString;
            multiSelect: z.ZodBoolean;
            options: z.ZodOptional<z.ZodArray<z.ZodObject<{
                description: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                value: z.ZodString;
            }, z.core.$strip>>>;
            prompt: z.ZodString;
            shortLabel: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
    }, z.core.$strip>;
    resolution: z.ZodObject<{
        answers: z.ZodRecord<z.ZodString, z.ZodObject<{
            freeText: z.ZodOptional<z.ZodString>;
            selected: z.ZodArray<z.ZodString>;
        }, z.core.$strip>>;
        kind: z.ZodLiteral<"user_answer">;
    }, z.core.$strip>;
}, z.core.$strip>;
type UserQuestionInteractionOutcome = z.infer<typeof userQuestionInteractionOutcomeSchema>;
declare const providerInteractionOutcomeSchema: z.ZodUnion<readonly [z.ZodObject<{
    payload: z.ZodObject<{
        availableDecisions: z.ZodArray<z.ZodEnum<{
            allow_for_session: "allow_for_session";
            allow_once: "allow_once";
            deny: "deny";
        }>>;
        kind: z.ZodLiteral<"approval">;
        reason: z.ZodNullable<z.ZodString>;
        subject: z.ZodDiscriminatedUnion<[z.ZodObject<{
            actions: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                command: z.ZodString;
                name: z.ZodString;
                path: z.ZodString;
                type: z.ZodLiteral<"read">;
            }, z.core.$strip>, z.ZodObject<{
                command: z.ZodString;
                path: z.ZodNullable<z.ZodString>;
                type: z.ZodLiteral<"listFiles">;
            }, z.core.$strip>, z.ZodObject<{
                command: z.ZodString;
                path: z.ZodNullable<z.ZodString>;
                query: z.ZodNullable<z.ZodString>;
                type: z.ZodLiteral<"search">;
            }, z.core.$strip>, z.ZodObject<{
                command: z.ZodString;
                type: z.ZodLiteral<"unknown">;
            }, z.core.$strip>], "type">>;
            command: z.ZodString;
            cwd: z.ZodNullable<z.ZodString>;
            itemId: z.ZodString;
            kind: z.ZodLiteral<"command">;
            sessionGrant: z.ZodNullable<z.ZodObject<{
                fileSystem: z.ZodNullable<z.ZodObject<{
                    read: z.ZodArray<z.ZodString>;
                    write: z.ZodArray<z.ZodString>;
                }, z.core.$strip>>;
                network: z.ZodNullable<z.ZodObject<{
                    enabled: z.ZodNullable<z.ZodBoolean>;
                }, z.core.$strip>>;
            }, z.core.$strict>>;
        }, z.core.$strip>, z.ZodObject<{
            itemId: z.ZodString;
            kind: z.ZodLiteral<"file_change">;
            sessionGrant: z.ZodNullable<z.ZodObject<{
                fileSystem: z.ZodNullable<z.ZodObject<{
                    read: z.ZodArray<z.ZodString>;
                    write: z.ZodArray<z.ZodString>;
                }, z.core.$strip>>;
                network: z.ZodNullable<z.ZodObject<{
                    enabled: z.ZodNullable<z.ZodBoolean>;
                }, z.core.$strip>>;
            }, z.core.$strict>>;
            writeScope: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            itemId: z.ZodString;
            kind: z.ZodLiteral<"permission_grant">;
            permissions: z.ZodObject<{
                fileSystem: z.ZodNullable<z.ZodObject<{
                    read: z.ZodArray<z.ZodString>;
                    write: z.ZodArray<z.ZodString>;
                }, z.core.$strip>>;
                network: z.ZodNullable<z.ZodObject<{
                    enabled: z.ZodNullable<z.ZodBoolean>;
                }, z.core.$strip>>;
            }, z.core.$strict>;
            toolName: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            itemId: z.ZodString;
            kind: z.ZodLiteral<"plan">;
            plan: z.ZodString;
            planFilePath: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            itemId: z.ZodString;
            kind: z.ZodLiteral<"tool_use">;
            presentation: z.ZodObject<{
                badge: z.ZodOptional<z.ZodObject<{
                    glyph: z.ZodString;
                    hint: z.ZodString;
                    label: z.ZodString;
                    tone: z.ZodEnum<{
                        destructive: "destructive";
                        neutral: "neutral";
                    }>;
                }, z.core.$strip>>;
                detail: z.ZodOptional<z.ZodString>;
                icon: z.ZodObject<{
                    glyph: z.ZodString;
                }, z.core.$strip>;
                label: z.ZodObject<{
                    completed: z.ZodString;
                    pending: z.ZodString;
                }, z.core.$strip>;
                suppress: z.ZodOptional<z.ZodBoolean>;
                tint: z.ZodOptional<z.ZodObject<{
                    dark: z.ZodString;
                    light: z.ZodString;
                }, z.core.$strip>>;
                title: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>;
            tool: z.ZodString;
        }, z.core.$strip>], "kind">;
    }, z.core.$strip>;
    resolution: z.ZodDiscriminatedUnion<[z.ZodObject<{
        decision: z.ZodLiteral<"allow_once">;
        grantedPermissions: z.ZodNullable<z.ZodObject<{
            fileSystem: z.ZodNullable<z.ZodObject<{
                read: z.ZodArray<z.ZodString>;
                write: z.ZodArray<z.ZodString>;
            }, z.core.$strip>>;
            network: z.ZodNullable<z.ZodObject<{
                enabled: z.ZodNullable<z.ZodBoolean>;
            }, z.core.$strip>>;
        }, z.core.$strict>>;
    }, z.core.$strip>, z.ZodObject<{
        decision: z.ZodLiteral<"allow_for_session">;
        grantedPermissions: z.ZodNullable<z.ZodObject<{
            fileSystem: z.ZodNullable<z.ZodObject<{
                read: z.ZodArray<z.ZodString>;
                write: z.ZodArray<z.ZodString>;
            }, z.core.$strip>>;
            network: z.ZodNullable<z.ZodObject<{
                enabled: z.ZodNullable<z.ZodBoolean>;
            }, z.core.$strip>>;
        }, z.core.$strict>>;
    }, z.core.$strip>, z.ZodObject<{
        decision: z.ZodLiteral<"deny">;
    }, z.core.$strip>], "decision">;
}, z.core.$strip>, z.ZodObject<{
    payload: z.ZodObject<{
        kind: z.ZodLiteral<"user_question">;
        questions: z.ZodArray<z.ZodObject<{
            allowFreeText: z.ZodBoolean;
            id: z.ZodString;
            multiSelect: z.ZodBoolean;
            options: z.ZodOptional<z.ZodArray<z.ZodObject<{
                description: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                value: z.ZodString;
            }, z.core.$strip>>>;
            prompt: z.ZodString;
            shortLabel: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
    }, z.core.$strip>;
    resolution: z.ZodObject<{
        answers: z.ZodRecord<z.ZodString, z.ZodObject<{
            freeText: z.ZodOptional<z.ZodString>;
            selected: z.ZodArray<z.ZodString>;
        }, z.core.$strip>>;
        kind: z.ZodLiteral<"user_answer">;
    }, z.core.$strip>;
}, z.core.$strip>, z.ZodObject<{
    payload: z.ZodObject<{
        data: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
        kind: z.ZodString & z.ZodType<`${string}/${string}`, string, z.core.$ZodTypeInternals<`${string}/${string}`, string>>;
        title: z.ZodString;
    }, z.core.$strip>;
    resolution: z.ZodObject<{
        kind: z.ZodLiteral<"request_answer">;
        value: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
    }, z.core.$strip>;
}, z.core.$strip>]>;
type ProviderInteractionOutcome = z.infer<typeof providerInteractionOutcomeSchema>;
declare function isApprovalInteractionOutcome(outcome: ProviderInteractionOutcome): outcome is ApprovalInteractionOutcome;

declare const threadEventItemStatusSchema: z.ZodEnum<{
    completed: "completed";
    failed: "failed";
    interrupted: "interrupted";
    pending: "pending";
}>;
type ThreadEventItemStatus = z.infer<typeof threadEventItemStatusSchema>;
declare const threadEventTurnStatusSchema: z.ZodEnum<{
    completed: "completed";
    failed: "failed";
    interrupted: "interrupted";
}>;
type ThreadEventTurnStatus = z.infer<typeof threadEventTurnStatusSchema>;
declare const providerErrorCategorySchema: z.ZodEnum<{
    "active-turn-not-steerable": "active-turn-not-steerable";
    "bad-request": "bad-request";
    "budget-exceeded": "budget-exceeded";
    "connection-failed": "connection-failed";
    "context-window-exceeded": "context-window-exceeded";
    "max-output-tokens": "max-output-tokens";
    "max-turns": "max-turns";
    "rate-limit": "rate-limit";
    "stream-disconnected": "stream-disconnected";
    "structured-output-retries": "structured-output-retries";
    "thread-rollback-failed": "thread-rollback-failed";
    "too-many-failed-attempts": "too-many-failed-attempts";
    billing: "billing";
    internal: "internal";
    overloaded: "overloaded";
    policy: "policy";
    sandbox: "sandbox";
    unauthorized: "unauthorized";
    unknown: "unknown";
}>;
type ProviderErrorCategory = z.infer<typeof providerErrorCategorySchema>;
declare const providerErrorInfoSchema: z.ZodObject<{
    category: z.ZodEnum<{
        "active-turn-not-steerable": "active-turn-not-steerable";
        "bad-request": "bad-request";
        "budget-exceeded": "budget-exceeded";
        "connection-failed": "connection-failed";
        "context-window-exceeded": "context-window-exceeded";
        "max-output-tokens": "max-output-tokens";
        "max-turns": "max-turns";
        "rate-limit": "rate-limit";
        "stream-disconnected": "stream-disconnected";
        "structured-output-retries": "structured-output-retries";
        "thread-rollback-failed": "thread-rollback-failed";
        "too-many-failed-attempts": "too-many-failed-attempts";
        billing: "billing";
        internal: "internal";
        overloaded: "overloaded";
        policy: "policy";
        sandbox: "sandbox";
        unauthorized: "unauthorized";
        unknown: "unknown";
    }>;
    httpStatusCode: z.ZodNullable<z.ZodNumber>;
    providerCode: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
type ProviderErrorInfo = z.infer<typeof providerErrorInfoSchema>;
declare const providerRateLimitStatusSchema: z.ZodEnum<{
    allowed: "allowed";
    blocked: "blocked";
    unknown: "unknown";
    warning: "warning";
}>;
type ProviderRateLimitStatus = z.infer<typeof providerRateLimitStatusSchema>;
declare const providerRateLimitWindowSchema: z.ZodObject<{
    label: z.ZodNullable<z.ZodString>;
    providerKey: z.ZodNullable<z.ZodString>;
    resetsAtMs: z.ZodNullable<z.ZodNumber>;
    status: z.ZodEnum<{
        allowed: "allowed";
        blocked: "blocked";
        unknown: "unknown";
        warning: "warning";
    }>;
}, z.core.$strip>;
type ProviderRateLimitWindow = z.infer<typeof providerRateLimitWindowSchema>;
declare const providerRateLimitStateSchema: z.ZodObject<{
    kind: z.ZodEnum<{
        "spend-control": "spend-control";
        "subscription-window": "subscription-window";
        credits: "credits";
        unknown: "unknown";
    }>;
    overageReason: z.ZodNullable<z.ZodString>;
    overageStatus: z.ZodNullable<z.ZodEnum<{
        allowed: "allowed";
        rejected: "rejected";
        unavailable: "unavailable";
        warning: "warning";
    }>>;
    providerId: z.ZodString;
    reachedReason: z.ZodNullable<z.ZodString>;
    status: z.ZodEnum<{
        allowed: "allowed";
        blocked: "blocked";
        unknown: "unknown";
        warning: "warning";
    }>;
    windows: z.ZodArray<z.ZodObject<{
        label: z.ZodNullable<z.ZodString>;
        providerKey: z.ZodNullable<z.ZodString>;
        resetsAtMs: z.ZodNullable<z.ZodNumber>;
        status: z.ZodEnum<{
            allowed: "allowed";
            blocked: "blocked";
            unknown: "unknown";
            warning: "warning";
        }>;
    }, z.core.$strip>>;
}, z.core.$strip>;
type ProviderRateLimitState = z.infer<typeof providerRateLimitStateSchema>;
declare const threadEventPlanStepSchema: z.ZodObject<{
    status: z.ZodOptional<z.ZodEnum<{
        active: "active";
        completed: "completed";
        failed: "failed";
        pending: "pending";
    }>>;
    step: z.ZodString;
}, z.core.$strip>;
type ThreadEventPlanStep = z.infer<typeof threadEventPlanStepSchema>;
declare const threadEventSearchModeSchema: z.ZodEnum<{
    content: "content";
    list: "list";
    path: "path";
}>;
type ThreadEventSearchMode = z.infer<typeof threadEventSearchModeSchema>;
declare const threadEventUserContentSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    text: z.ZodString;
    type: z.ZodLiteral<"text">;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"image">;
    url: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    path: z.ZodString;
    type: z.ZodLiteral<"localImage">;
}, z.core.$strip>, z.ZodObject<{
    path: z.ZodString;
    type: z.ZodLiteral<"localFile">;
}, z.core.$strip>], "type">;
type ThreadEventUserContent = z.infer<typeof threadEventUserContentSchema>;
declare const threadEventTokenUsageBreakdownSchema: z.ZodObject<{
    cachedInputTokens: z.ZodNumber;
    inputTokens: z.ZodNumber;
    outputTokens: z.ZodNumber;
    reasoningOutputTokens: z.ZodNumber;
    totalTokens: z.ZodNumber;
}, z.core.$strip>;
type ThreadEventTokenUsageBreakdown = z.infer<typeof threadEventTokenUsageBreakdownSchema>;
declare const threadEventContextWindowUsageSchema: z.ZodObject<{
    estimated: z.ZodBoolean;
    modelContextWindow: z.ZodNullable<z.ZodNumber>;
    usedTokens: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
type ThreadEventContextWindowUsage = z.infer<typeof threadEventContextWindowUsageSchema>;
declare const providerRawEventSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
    jsonrpc: z.ZodLiteral<"2.0">;
    method: z.ZodString;
    params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
}, z.core.$strip>;
type ProviderRawEvent = z.infer<typeof providerRawEventSchema>;

declare const reasoningLevelValues: readonly ["none", "low", "medium", "high", "xhigh", "ultracode", "max", "ultra"];
declare const reasoningLevelSchema: z.ZodEnum<{
    high: "high";
    low: "low";
    max: "max";
    medium: "medium";
    none: "none";
    ultra: "ultra";
    ultracode: "ultracode";
    xhigh: "xhigh";
}>;
type ReasoningLevel = z.infer<typeof reasoningLevelSchema>;
declare const serviceTierSchema: z.ZodEnum<{
    default: "default";
    fast: "fast";
}>;
type ServiceTier = z.infer<typeof serviceTierSchema>;
declare const instructionModeValues: readonly ["append", "replace"];
declare const instructionModeSchema: z.ZodEnum<{
    append: "append";
    replace: "replace";
}>;
type InstructionMode = z.infer<typeof instructionModeSchema>;
declare const permissionModeSchema: z.ZodEnum<{
    "accept-edits": "accept-edits";
    auto: "auto";
    full: "full";
}>;
type PermissionMode = z.infer<typeof permissionModeSchema>;
declare const permissionEscalationValues: readonly ["ask", "deny"];
declare const permissionEscalationSchema: z.ZodEnum<{
    ask: "ask";
    deny: "deny";
}>;
type PermissionEscalation = z.infer<typeof permissionEscalationSchema>;
declare const promptMentionCommandTriggerSchema: z.ZodEnum<{
    "/": "/";
}>;
type PromptMentionCommandTrigger = z.infer<typeof promptMentionCommandTriggerSchema>;
declare const promptInputSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    mentions: z.ZodDefault<z.ZodArray<z.ZodObject<{
        end: z.ZodNumber;
        resource: z.ZodPipe<z.ZodTransform<unknown, unknown>, z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"thread">;
            label: z.ZodString;
            projectId: z.ZodOptional<z.ZodString>;
            threadId: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            kind: z.ZodLiteral<"project">;
            label: z.ZodString;
            projectId: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            kind: z.ZodLiteral<"section">;
            label: z.ZodString;
            sectionId: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            entryKind: z.ZodEnum<{
                directory: "directory";
                file: "file";
            }>;
            kind: z.ZodLiteral<"path">;
            label: z.ZodString;
            path: z.ZodString;
            source: z.ZodEnum<{
                "thread-storage": "thread-storage";
                workspace: "workspace";
            }>;
        }, z.core.$strip>, z.ZodObject<{
            argumentHint: z.ZodNullable<z.ZodString>;
            kind: z.ZodLiteral<"command">;
            label: z.ZodString;
            name: z.ZodString;
            origin: z.ZodEnum<{
                builtin: "builtin";
                project: "project";
                user: "user";
            }>;
            source: z.ZodEnum<{
                command: "command";
                skill: "skill";
            }>;
            trigger: z.ZodEnum<{
                "/": "/";
            }>;
        }, z.core.$strip>, z.ZodObject<{
            icon: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            itemId: z.ZodString;
            kind: z.ZodLiteral<"plugin">;
            label: z.ZodString;
            pluginId: z.ZodString;
        }, z.core.$strip>], "kind">>;
        start: z.ZodNumber;
    }, z.core.$strip>>>;
    text: z.ZodString;
    type: z.ZodLiteral<"text">;
    visibility: z.ZodOptional<z.ZodEnum<{
        "agent-only": "agent-only";
    }>>;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"image">;
    url: z.ZodString;
    visibility: z.ZodOptional<z.ZodEnum<{
        "agent-only": "agent-only";
    }>>;
}, z.core.$strip>, z.ZodObject<{
    path: z.ZodString;
    type: z.ZodLiteral<"localImage">;
    visibility: z.ZodOptional<z.ZodEnum<{
        "agent-only": "agent-only";
    }>>;
}, z.core.$strip>, z.ZodObject<{
    mimeType: z.ZodOptional<z.ZodString>;
    name: z.ZodOptional<z.ZodString>;
    path: z.ZodString;
    sizeBytes: z.ZodOptional<z.ZodNumber>;
    type: z.ZodLiteral<"localFile">;
    visibility: z.ZodOptional<z.ZodEnum<{
        "agent-only": "agent-only";
    }>>;
}, z.core.$strip>], "type">;
type PromptInput = z.infer<typeof promptInputSchema>;
interface PromptCommandSelector {
    trigger: PromptMentionCommandTrigger;
    name: string;
}
declare function isStandaloneBuiltinCompactCommand(input: readonly PromptInput[]): boolean;
declare function removeCommandMentionsFromPromptInput(input: readonly PromptInput[], selector: PromptCommandSelector): PromptInput[];
declare const runtimePermissionScopeValues: readonly ["workspace", "full"];
declare const runtimePermissionScopeSchema: z.ZodEnum<{
    full: "full";
    workspace: "workspace";
}>;
type RuntimePermissionScope = z.infer<typeof runtimePermissionScopeSchema>;
declare const runtimePermissionPolicySchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    approvalReviewer: z.ZodLiteral<"user">;
    permissionEscalation: z.ZodEnum<{
        ask: "ask";
        deny: "deny";
    }>;
    permissionMode: z.ZodLiteral<"accept-edits">;
    permissionScope: z.ZodLiteral<"workspace">;
}, z.core.$strip>, z.ZodObject<{
    approvalReviewer: z.ZodLiteral<"automatic">;
    permissionEscalation: z.ZodEnum<{
        ask: "ask";
        deny: "deny";
    }>;
    permissionMode: z.ZodLiteral<"auto">;
    permissionScope: z.ZodLiteral<"workspace">;
}, z.core.$strip>, z.ZodObject<{
    approvalReviewer: z.ZodNull;
    permissionEscalation: z.ZodNull;
    permissionMode: z.ZodLiteral<"full">;
    permissionScope: z.ZodLiteral<"full">;
}, z.core.$strip>], "permissionMode">;
type RuntimePermissionPolicy = z.infer<typeof runtimePermissionPolicySchema>;

declare const clientTurnRequestIdSchema: z.ZodString;
type ClientTurnRequestId = z.infer<typeof clientTurnRequestIdSchema>;

type ExtensionKind = `${string}/${string}`;
declare function isExtensionKind(value: string): value is ExtensionKind;
declare const extensionKindSchema: z.ZodString & z.ZodType<`${string}/${string}`, string, z.core.$ZodTypeInternals<`${string}/${string}`, string>>;

declare const modelReasoningEffortSchema: z.ZodObject<{
    description: z.ZodString;
    reasoningEffort: z.ZodEnum<{
        high: "high";
        low: "low";
        max: "max";
        medium: "medium";
        none: "none";
        ultra: "ultra";
        ultracode: "ultracode";
        xhigh: "xhigh";
    }>;
}, z.core.$strip>;
type ModelReasoningEffort = z.infer<typeof modelReasoningEffortSchema>;
declare const availableModelSchema: z.ZodObject<{
    defaultReasoningEffort: z.ZodEnum<{
        high: "high";
        low: "low";
        max: "max";
        medium: "medium";
        none: "none";
        ultra: "ultra";
        ultracode: "ultracode";
        xhigh: "xhigh";
    }>;
    description: z.ZodString;
    displayName: z.ZodString;
    id: z.ZodString;
    isDefault: z.ZodBoolean;
    model: z.ZodString;
    routeProviderId: z.ZodOptional<z.ZodString>;
    supportedReasoningEfforts: z.ZodArray<z.ZodObject<{
        description: z.ZodString;
        reasoningEffort: z.ZodEnum<{
            high: "high";
            low: "low";
            max: "max";
            medium: "medium";
            none: "none";
            ultra: "ultra";
            ultracode: "ultracode";
            xhigh: "xhigh";
        }>;
    }, z.core.$strip>>;
}, z.core.$strip>;
type AvailableModel = z.infer<typeof availableModelSchema>;
declare const providerRecoveryKindValues: readonly ["sessionArchived", "authRequired", "restartRecommended", "staleTurn", "rateLimited"];
declare const providerRecoveryKindSchema: z.ZodEnum<{
    authRequired: "authRequired";
    rateLimited: "rateLimited";
    restartRecommended: "restartRecommended";
    sessionArchived: "sessionArchived";
    staleTurn: "staleTurn";
}>;
type ProviderRecoveryKind = z.infer<typeof providerRecoveryKindSchema>;
declare const dynamicToolSchema: z.ZodObject<{
    description: z.ZodString;
    inputSchema: z.ZodUnknown;
    name: z.ZodString;
    presentation: z.ZodOptional<z.ZodObject<{
        badge: z.ZodOptional<z.ZodObject<{
            glyph: z.ZodString;
            hint: z.ZodString;
            label: z.ZodString;
            tone: z.ZodEnum<{
                destructive: "destructive";
                neutral: "neutral";
            }>;
        }, z.core.$strip>>;
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
}, z.core.$strip>;
type DynamicTool = z.infer<typeof dynamicToolSchema>;

declare const LOW_REASONING_EFFORT: ModelReasoningEffort;
declare const MEDIUM_REASONING_EFFORT: ModelReasoningEffort;
declare const HIGH_REASONING_EFFORT: ModelReasoningEffort;
declare const XHIGH_REASONING_EFFORT: ModelReasoningEffort;
declare const ULTRACODE_REASONING_EFFORT: ModelReasoningEffort;
declare const MAX_REASONING_EFFORT: ModelReasoningEffort;
declare function reasoningEffortsForLevels(levels: readonly ReasoningLevel[]): ModelReasoningEffort[];

declare function toOptionalString(value: unknown): string | undefined;
declare function toOptionalRecord(value: unknown): Record<string, unknown> | undefined;
declare function buildShellEnvOverrides(envVars?: Record<string, string>): Record<string, string>;
declare function toNonNegativeNumber(value: unknown): number;
declare function normalizeProviderCommandOutput(args: {
    emptyPlaceholders: readonly string[];
    text: string;
}): string | undefined;
declare function extractResultText(content: unknown): string;
declare const ZERO_TOKEN_USAGE: ThreadEventTokenUsageBreakdown;
declare function addTokenUsage(total: ThreadEventTokenUsageBreakdown, last: ThreadEventTokenUsageBreakdown): ThreadEventTokenUsageBreakdown;

interface BoundedLineReaderArgs {
    input: NodeJS.ReadableStream;
    onLine: (line: string) => void;
    onOverflow: (bytes: number) => void;
    onClose?: () => void;
    maxLineBytes?: number;
}
declare function readBoundedLines(args: BoundedLineReaderArgs): void;

declare const BRIDGE_JSON_RPC_ERRORS: {
    readonly INVALID_PARAMS: -32602;
    readonly METHOD_NOT_FOUND: -32601;
    readonly BRIDGE_ERROR: -32000;
    readonly NO_ACTIVE_TURN: -32001;
    readonly SESSION_NOT_RESTORABLE: -32002;
    readonly FORK_CHECKPOINT_UNSUPPORTED: -32003;
};
declare const providerRecoveryHintSchema: z.ZodObject<{
    kind: z.ZodEnum<{
        authRequired: "authRequired";
        rateLimited: "rateLimited";
        restartRecommended: "restartRecommended";
        sessionArchived: "sessionArchived";
        staleTurn: "staleTurn";
    }>;
    message: z.ZodString;
    retryable: z.ZodBoolean;
}, z.core.$strip>;
type ProviderRecoveryHint = z.infer<typeof providerRecoveryHintSchema>;
declare const bridgeErrorDataSchema: z.ZodObject<{
    recovery: z.ZodOptional<z.ZodObject<{
        kind: z.ZodEnum<{
            authRequired: "authRequired";
            rateLimited: "rateLimited";
            restartRecommended: "restartRecommended";
            sessionArchived: "sessionArchived";
            staleTurn: "staleTurn";
        }>;
        message: z.ZodString;
        retryable: z.ZodBoolean;
    }, z.core.$strip>>;
}, z.core.$loose>;
type BridgeErrorData = z.infer<typeof bridgeErrorDataSchema>;

type BridgeJsonRpcId = string | number;
type BridgeJsonRpcResponse$1 = {
    jsonrpc: "2.0";
    id: BridgeJsonRpcId;
    result: unknown;
} | {
    jsonrpc: "2.0";
    id: BridgeJsonRpcId;
    error: {
        code: number;
        message: string;
        data?: BridgeErrorData;
    };
};
type BridgeSendError = (id: BridgeJsonRpcId, code: number, message: string, data?: BridgeErrorData) => void;
declare class BridgeRecoveryError extends Error {
    readonly code: number;
    readonly recovery: ProviderRecoveryHint;
    constructor(args: {
        code: number;
        message: string;
        recovery: ProviderRecoveryHint;
        cause?: unknown;
    });
}
interface CreateBridgeIoArgs {
    write?: (line: string) => void;
}
declare function createBridgeIo<TMessage>({ write, }?: CreateBridgeIoArgs): {
    send: (message: TMessage | BridgeJsonRpcResponse$1) => void;
    sendError: BridgeSendError;
    sendResult: (id: BridgeJsonRpcId, result: unknown) => void;
};
declare function createBridgeLineHandler(args: {
    handleParsedMessage: (message: unknown) => void;
}): (line: string) => void;
declare function runBridgeRequest<TRequest extends {
    id: BridgeJsonRpcId;
}>(args: {
    handleRequest: (request: TRequest) => Promise<void>;
    request: TRequest;
    sendError: BridgeSendError;
}): void;

interface BridgeRecorderChildStreams {
    stdin?: Writable | null;
    stdout?: Readable | null;
}
declare function experimental_isProviderBridgeRecording(): boolean;
declare function experimental_recordProviderChildIo(child: BridgeRecorderChildStreams, scope: {
    threadId: string | null;
}): void;

declare function withoutBridgeRuntimeEnv(env: NodeJS.ProcessEnv): NodeJS.ProcessEnv;

interface BridgeToolCallRequest {
    jsonrpc: "2.0";
    id: string | number;
    method: "item/tool/call";
    params: {
        providerThreadId: string;
        threadId?: string;
        turnId: string | null;
        callId: string;
        tool: string;
        arguments: Record<string, unknown>;
    };
}
declare const bridgeRequestEnvelopeSchema: z.ZodObject<{
    id: z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>;
    jsonrpc: z.ZodLiteral<"2.0">;
    method: z.ZodString;
    params: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
}, z.core.$strip>;
declare const jsonRpcSuccessResponseSchema: z.ZodObject<{
    id: z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>;
    jsonrpc: z.ZodLiteral<"2.0">;
    result: z.ZodUnknown;
}, z.core.$strip>;
declare const jsonRpcErrorResponseSchema: z.ZodObject<{
    error: z.ZodObject<{
        code: z.ZodNumber;
        data: z.ZodOptional<z.ZodUnknown>;
        message: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    id: z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>;
    jsonrpc: z.ZodLiteral<"2.0">;
}, z.core.$strip>;
type BridgeJsonRpcResponse = z.infer<typeof jsonRpcSuccessResponseSchema> | z.infer<typeof jsonRpcErrorResponseSchema>;
declare function decodeBridgeJsonRpcResponse(input: unknown): BridgeJsonRpcResponse | null;
interface BridgeToolCallImage {
    data: string;
    mimeType: string;
}
type BridgeToolCallContent = {
    type: "text";
    text: string;
} | {
    type: "image";
    data: string;
    mimeType: string;
};
declare function decodeToolCallResponsePayload(result: unknown): {
    content: string;
    contentBlocks: BridgeToolCallContent[];
    images: BridgeToolCallImage[];
    isError: boolean;
};
declare function buildBridgeToolCallContent(result: {
    content: string;
    contentBlocks?: BridgeToolCallContent[];
    images?: BridgeToolCallImage[];
}): BridgeToolCallContent[];

interface ProviderRequestCommandPlan {
    kind: "request";
    method: string;
    params?: object;
}
interface ProviderPostInitializeRequest {
    plan: ProviderRequestCommandPlan;
    required: boolean;
    onResult(result: unknown): void;
}
interface DecodedInteractiveRequest {
    requestId: string | number;
    method: string;
    providerThreadId: string;
    turnId: string | null;
    payload: PendingInteractionPayload;
    threadId?: string;
}
interface PreparedProviderCommandDispatch {
    rollback(): void;
    claim(): boolean;
}
interface BuildInteractiveResponseArgs {
    request: DecodedInteractiveRequest;
    resolution: PendingInteractionResolution;
}

declare const jsonRpcEnvelopeSchema: z.ZodObject<{
    jsonrpc: z.ZodLiteral<"2.0">;
    method: z.ZodString;
    params: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
}, z.core.$loose>;
declare const sdkMessageEnvelopeSchema: z.ZodObject<{
    jsonrpc: z.ZodLiteral<"2.0">;
    method: z.ZodLiteral<"sdk/message">;
    params: z.ZodObject<{
        message: z.ZodUnknown;
        parent_tool_use_id: z.ZodOptional<z.ZodString>;
        threadId: z.ZodOptional<z.ZodString>;
    }, z.core.$loose>;
}, z.core.$loose>;
declare const threadIdentityEnvelopeSchema: z.ZodObject<{
    jsonrpc: z.ZodLiteral<"2.0">;
    method: z.ZodLiteral<"thread/identity">;
    params: z.ZodObject<{
        providerThreadId: z.ZodOptional<z.ZodString>;
        threadId: z.ZodOptional<z.ZodString>;
    }, z.core.$loose>;
}, z.core.$loose>;
declare const threadContextWindowUsageEnvelopeSchema: z.ZodObject<{
    jsonrpc: z.ZodLiteral<"2.0">;
    method: z.ZodLiteral<"thread/contextWindowUsage/updated">;
    params: z.ZodObject<{
        contextWindowUsage: z.ZodObject<{
            estimated: z.ZodBoolean;
            modelContextWindow: z.ZodNullable<z.ZodNumber>;
            usedTokens: z.ZodNullable<z.ZodNumber>;
        }, z.core.$strip>;
        threadId: z.ZodOptional<z.ZodString>;
    }, z.core.$loose>;
}, z.core.$loose>;
declare const errorEnvelopeSchema: z.ZodObject<{
    jsonrpc: z.ZodLiteral<"2.0">;
    method: z.ZodLiteral<"error">;
    params: z.ZodOptional<z.ZodObject<{
        message: z.ZodOptional<z.ZodString>;
    }, z.core.$loose>>;
}, z.core.$loose>;

declare function mimeTypeFromExtension(filePath: string): string;

interface BridgeToolCallResult {
    content: string;
    contentBlocks?: BridgeToolCallContent[];
    images?: BridgeToolCallImage[];
    isError?: boolean;
}
interface ForwardBridgeToolCallArgs {
    arguments: Record<string, unknown>;
    providerThreadId: string;
    scope: object;
    threadId: string;
    toolName: string;
}
interface PendingToolCallTracker {
    forwardToolCall: (args: ForwardBridgeToolCallArgs) => Promise<BridgeToolCallResult>;
    handleToolCallResponse: (response: BridgeJsonRpcResponse) => boolean;
    resolvePendingToolCalls: (scope: object, message: string) => void;
}
declare function createPendingToolCallTracker(options: {
    sendToolCall: (request: BridgeToolCallRequest) => void;
}): PendingToolCallTracker;

interface InteractiveRequestPolicyInput {
    permissionEscalation: PermissionEscalation | null;
}
declare function shouldAutoDenyInteractiveRequest(policy: InteractiveRequestPolicyInput): boolean;

declare const THREAD_DELTA_NOTIFICATION_METHOD = "thread/delta";
declare const deltaPresentationSchema: z.ZodObject<{
    badge: z.ZodOptional<z.ZodObject<{
        glyph: z.ZodString;
        hint: z.ZodString;
        label: z.ZodString;
        tone: z.ZodEnum<{
            destructive: "destructive";
            neutral: "neutral";
        }>;
    }, z.core.$strip>>;
    detail: z.ZodOptional<z.ZodString>;
    icon: z.ZodObject<{
        glyph: z.ZodString;
    }, z.core.$strip>;
    label: z.ZodObject<{
        completed: z.ZodString;
        pending: z.ZodString;
    }, z.core.$strip>;
    suppress: z.ZodOptional<z.ZodBoolean>;
    tint: z.ZodOptional<z.ZodObject<{
        dark: z.ZodString;
        light: z.ZodString;
    }, z.core.$strip>>;
    title: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
type DeltaPresentation = z.infer<typeof deltaPresentationSchema>;
declare const deltaItemKeySchema: z.ZodObject<{
    channel: z.ZodOptional<z.ZodString>;
    parentRef: z.ZodOptional<z.ZodString>;
    providerItemId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
type DeltaItemKey = z.infer<typeof deltaItemKeySchema>;
declare const deltaFileChangeSchema: z.ZodObject<{
    diff: z.ZodOptional<z.ZodString>;
    kind: z.ZodEnum<{
        add: "add";
        delete: "delete";
        update: "update";
    }>;
    movePath: z.ZodOptional<z.ZodString>;
    newText: z.ZodOptional<z.ZodString>;
    oldText: z.ZodOptional<z.ZodString>;
    path: z.ZodString;
}, z.core.$strip>;
type DeltaFileChange = z.infer<typeof deltaFileChangeSchema>;
declare const deltaBackgroundTaskShapeSchema: z.ZodObject<{
    description: z.ZodString;
    error: z.ZodOptional<z.ZodString>;
    familyId: z.ZodString;
    outputFile: z.ZodOptional<z.ZodString>;
    skipTranscript: z.ZodBoolean;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
        pending: "pending";
    }>;
    summary: z.ZodOptional<z.ZodString>;
    taskStatus: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        killed: "killed";
        paused: "paused";
        pending: "pending";
        running: "running";
        stopped: "stopped";
    }>;
    taskType: z.ZodString;
    type: z.ZodLiteral<"backgroundTask">;
    usage: z.ZodOptional<z.ZodObject<{
        durationMs: z.ZodNumber;
        toolUses: z.ZodNumber;
        totalTokens: z.ZodNumber;
    }, z.core.$strip>>;
    workflow: z.ZodOptional<z.ZodObject<{
        agents: z.ZodArray<z.ZodObject<{
            agentType: z.ZodOptional<z.ZodString>;
            attempt: z.ZodNumber;
            cached: z.ZodBoolean;
            durationMs: z.ZodOptional<z.ZodNumber>;
            error: z.ZodOptional<z.ZodString>;
            index: z.ZodNumber;
            isolation: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            lastProgressAt: z.ZodNumber;
            lastToolName: z.ZodOptional<z.ZodString>;
            lastToolSummary: z.ZodOptional<z.ZodString>;
            model: z.ZodString;
            phaseIndex: z.ZodOptional<z.ZodNumber>;
            phaseTitle: z.ZodOptional<z.ZodString>;
            promptPreview: z.ZodOptional<z.ZodString>;
            queuedAt: z.ZodOptional<z.ZodNumber>;
            resultPreview: z.ZodOptional<z.ZodString>;
            startedAt: z.ZodOptional<z.ZodNumber>;
            state: z.ZodEnum<{
                done: "done";
                failed: "failed";
                queued: "queued";
                running: "running";
                skipped: "skipped";
            }>;
            tokens: z.ZodOptional<z.ZodNumber>;
            toolCalls: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        phases: z.ZodArray<z.ZodObject<{
            index: z.ZodNumber;
            kind: z.ZodOptional<z.ZodString>;
            title: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    workflowName: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
type DeltaBackgroundTaskShape = z.infer<typeof deltaBackgroundTaskShapeSchema>;
declare const deltaFileReadShapeSchema: z.ZodObject<{
    cmd: z.ZodOptional<z.ZodString>;
    path: z.ZodString;
    type: z.ZodLiteral<"fileRead">;
}, z.core.$strip>;
type DeltaFileReadShape = z.infer<typeof deltaFileReadShapeSchema>;
declare const deltaSearchShapeSchema: z.ZodObject<{
    cmd: z.ZodOptional<z.ZodString>;
    mode: z.ZodEnum<{
        content: "content";
        list: "list";
        path: "path";
    }>;
    path: z.ZodOptional<z.ZodString>;
    query: z.ZodString;
    type: z.ZodLiteral<"search">;
}, z.core.$strip>;
type DeltaSearchShape = z.infer<typeof deltaSearchShapeSchema>;
declare const deltaDelegationShapeSchema: z.ZodObject<{
    background: z.ZodBoolean;
    childRef: z.ZodString;
    label: z.ZodString;
    summary: z.ZodOptional<z.ZodString>;
    type: z.ZodLiteral<"delegation">;
}, z.core.$strip>;
type DeltaDelegationShape = z.infer<typeof deltaDelegationShapeSchema>;
declare const deltaPlanStepsShapeSchema: z.ZodObject<{
    explanation: z.ZodOptional<z.ZodString>;
    steps: z.ZodArray<z.ZodObject<{
        status: z.ZodOptional<z.ZodEnum<{
            active: "active";
            completed: "completed";
            failed: "failed";
            pending: "pending";
        }>>;
        step: z.ZodString;
    }, z.core.$strip>>;
    type: z.ZodLiteral<"planSteps">;
}, z.core.$strip>;
type DeltaPlanStepsShape = z.infer<typeof deltaPlanStepsShapeSchema>;
declare const deltaExtensionShapeSchema: z.ZodObject<{
    kind: z.ZodString & z.ZodType<`${string}/${string}`, string, z.core.$ZodTypeInternals<`${string}/${string}`, string>>;
    payload: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
    type: z.ZodLiteral<"extension">;
}, z.core.$strip>;
type DeltaExtensionShape = z.infer<typeof deltaExtensionShapeSchema>;
declare const deltaItemShapeSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    aggregatedOutput: z.ZodOptional<z.ZodString>;
    command: z.ZodString;
    cwd: z.ZodString;
    durationMs: z.ZodOptional<z.ZodNumber>;
    exitCode: z.ZodOptional<z.ZodNumber>;
    type: z.ZodLiteral<"command">;
}, z.core.$strip>, z.ZodObject<{
    changes: z.ZodArray<z.ZodObject<{
        diff: z.ZodOptional<z.ZodString>;
        kind: z.ZodEnum<{
            add: "add";
            delete: "delete";
            update: "update";
        }>;
        movePath: z.ZodOptional<z.ZodString>;
        newText: z.ZodOptional<z.ZodString>;
        oldText: z.ZodOptional<z.ZodString>;
        path: z.ZodString;
    }, z.core.$strip>>;
    type: z.ZodLiteral<"fileChange">;
}, z.core.$strip>, z.ZodObject<{
    args: z.ZodOptional<z.ZodUnknown>;
    durationMs: z.ZodOptional<z.ZodNumber>;
    error: z.ZodOptional<z.ZodString>;
    result: z.ZodOptional<z.ZodUnknown>;
    server: z.ZodOptional<z.ZodString>;
    tool: z.ZodString;
    type: z.ZodLiteral<"tool">;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"compaction">;
}, z.core.$strip>, z.ZodObject<{
    text: z.ZodString;
    type: z.ZodLiteral<"agentMessage">;
}, z.core.$strip>, z.ZodObject<{
    content: z.ZodArray<z.ZodString>;
    summary: z.ZodArray<z.ZodString>;
    type: z.ZodLiteral<"reasoning">;
}, z.core.$strip>, z.ZodObject<{
    text: z.ZodString;
    type: z.ZodLiteral<"plan">;
}, z.core.$strip>, z.ZodObject<{
    queries: z.ZodArray<z.ZodString>;
    type: z.ZodLiteral<"webSearch">;
}, z.core.$strip>, z.ZodObject<{
    pattern: z.ZodNullable<z.ZodString>;
    prompt: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    type: z.ZodLiteral<"webFetch">;
    url: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    path: z.ZodString;
    type: z.ZodLiteral<"imageView">;
}, z.core.$strip>, z.ZodObject<{
    description: z.ZodString;
    error: z.ZodOptional<z.ZodString>;
    familyId: z.ZodString;
    outputFile: z.ZodOptional<z.ZodString>;
    skipTranscript: z.ZodBoolean;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
        pending: "pending";
    }>;
    summary: z.ZodOptional<z.ZodString>;
    taskStatus: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        killed: "killed";
        paused: "paused";
        pending: "pending";
        running: "running";
        stopped: "stopped";
    }>;
    taskType: z.ZodString;
    type: z.ZodLiteral<"backgroundTask">;
    usage: z.ZodOptional<z.ZodObject<{
        durationMs: z.ZodNumber;
        toolUses: z.ZodNumber;
        totalTokens: z.ZodNumber;
    }, z.core.$strip>>;
    workflow: z.ZodOptional<z.ZodObject<{
        agents: z.ZodArray<z.ZodObject<{
            agentType: z.ZodOptional<z.ZodString>;
            attempt: z.ZodNumber;
            cached: z.ZodBoolean;
            durationMs: z.ZodOptional<z.ZodNumber>;
            error: z.ZodOptional<z.ZodString>;
            index: z.ZodNumber;
            isolation: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            lastProgressAt: z.ZodNumber;
            lastToolName: z.ZodOptional<z.ZodString>;
            lastToolSummary: z.ZodOptional<z.ZodString>;
            model: z.ZodString;
            phaseIndex: z.ZodOptional<z.ZodNumber>;
            phaseTitle: z.ZodOptional<z.ZodString>;
            promptPreview: z.ZodOptional<z.ZodString>;
            queuedAt: z.ZodOptional<z.ZodNumber>;
            resultPreview: z.ZodOptional<z.ZodString>;
            startedAt: z.ZodOptional<z.ZodNumber>;
            state: z.ZodEnum<{
                done: "done";
                failed: "failed";
                queued: "queued";
                running: "running";
                skipped: "skipped";
            }>;
            tokens: z.ZodOptional<z.ZodNumber>;
            toolCalls: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        phases: z.ZodArray<z.ZodObject<{
            index: z.ZodNumber;
            kind: z.ZodOptional<z.ZodString>;
            title: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    workflowName: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    cmd: z.ZodOptional<z.ZodString>;
    path: z.ZodString;
    type: z.ZodLiteral<"fileRead">;
}, z.core.$strip>, z.ZodObject<{
    cmd: z.ZodOptional<z.ZodString>;
    mode: z.ZodEnum<{
        content: "content";
        list: "list";
        path: "path";
    }>;
    path: z.ZodOptional<z.ZodString>;
    query: z.ZodString;
    type: z.ZodLiteral<"search">;
}, z.core.$strip>, z.ZodObject<{
    background: z.ZodBoolean;
    childRef: z.ZodString;
    label: z.ZodString;
    summary: z.ZodOptional<z.ZodString>;
    type: z.ZodLiteral<"delegation">;
}, z.core.$strip>, z.ZodObject<{
    explanation: z.ZodOptional<z.ZodString>;
    steps: z.ZodArray<z.ZodObject<{
        status: z.ZodOptional<z.ZodEnum<{
            active: "active";
            completed: "completed";
            failed: "failed";
            pending: "pending";
        }>>;
        step: z.ZodString;
    }, z.core.$strip>>;
    type: z.ZodLiteral<"planSteps">;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodString & z.ZodType<`${string}/${string}`, string, z.core.$ZodTypeInternals<`${string}/${string}`, string>>;
    payload: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
    type: z.ZodLiteral<"extension">;
}, z.core.$strip>], "type">;
type DeltaItemShape = z.infer<typeof deltaItemShapeSchema>;
type DeltaItemShapeType = DeltaItemShape["type"];
declare const deltaProgressSnapshotSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    description: z.ZodString;
    error: z.ZodOptional<z.ZodString>;
    familyId: z.ZodString;
    outputFile: z.ZodOptional<z.ZodString>;
    skipTranscript: z.ZodBoolean;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
        pending: "pending";
    }>;
    summary: z.ZodOptional<z.ZodString>;
    taskStatus: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        killed: "killed";
        paused: "paused";
        pending: "pending";
        running: "running";
        stopped: "stopped";
    }>;
    taskType: z.ZodString;
    type: z.ZodLiteral<"backgroundTask">;
    usage: z.ZodOptional<z.ZodObject<{
        durationMs: z.ZodNumber;
        toolUses: z.ZodNumber;
        totalTokens: z.ZodNumber;
    }, z.core.$strip>>;
    workflow: z.ZodOptional<z.ZodObject<{
        agents: z.ZodArray<z.ZodObject<{
            agentType: z.ZodOptional<z.ZodString>;
            attempt: z.ZodNumber;
            cached: z.ZodBoolean;
            durationMs: z.ZodOptional<z.ZodNumber>;
            error: z.ZodOptional<z.ZodString>;
            index: z.ZodNumber;
            isolation: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            lastProgressAt: z.ZodNumber;
            lastToolName: z.ZodOptional<z.ZodString>;
            lastToolSummary: z.ZodOptional<z.ZodString>;
            model: z.ZodString;
            phaseIndex: z.ZodOptional<z.ZodNumber>;
            phaseTitle: z.ZodOptional<z.ZodString>;
            promptPreview: z.ZodOptional<z.ZodString>;
            queuedAt: z.ZodOptional<z.ZodNumber>;
            resultPreview: z.ZodOptional<z.ZodString>;
            startedAt: z.ZodOptional<z.ZodNumber>;
            state: z.ZodEnum<{
                done: "done";
                failed: "failed";
                queued: "queued";
                running: "running";
                skipped: "skipped";
            }>;
            tokens: z.ZodOptional<z.ZodNumber>;
            toolCalls: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        phases: z.ZodArray<z.ZodObject<{
            index: z.ZodNumber;
            kind: z.ZodOptional<z.ZodString>;
            title: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    workflowName: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    background: z.ZodBoolean;
    childRef: z.ZodString;
    label: z.ZodString;
    summary: z.ZodOptional<z.ZodString>;
    type: z.ZodLiteral<"delegation">;
}, z.core.$strip>], "type">;
type DeltaProgressSnapshot = z.infer<typeof deltaProgressSnapshotSchema>;
declare const deltaTextChannelSchema: z.ZodEnum<{
    agentMessage: "agentMessage";
    plan: "plan";
    reasoningSummary: "reasoningSummary";
    reasoningText: "reasoningText";
}>;
type DeltaTextChannel = z.infer<typeof deltaTextChannelSchema>;
declare const deltaOutputChannelSchema: z.ZodEnum<{
    command: "command";
    fileChange: "fileChange";
}>;
type DeltaOutputChannel = z.infer<typeof deltaOutputChannelSchema>;
declare const deltaNoTurnFallbackSchema: z.ZodObject<{
    raw: z.ZodObject<{
        id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
        jsonrpc: z.ZodLiteral<"2.0">;
        method: z.ZodString;
        params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
    }, z.core.$strip>;
    rawType: z.ZodString;
}, z.core.$strip>;
type DeltaNoTurnFallback = z.infer<typeof deltaNoTurnFallbackSchema>;
declare const threadDeltaSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    clientRequestId: z.ZodString;
    kind: z.ZodLiteral<"input.accepted">;
    providerTurnId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"input.provider">;
    parentRef: z.ZodOptional<z.ZodString>;
    text: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"turn.open">;
    parentRef: z.ZodOptional<z.ZodString>;
    providerTurnId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    claimIfIdle: z.ZodOptional<z.ZodBoolean>;
    error: z.ZodOptional<z.ZodObject<{
        message: z.ZodString;
    }, z.core.$strip>>;
    kind: z.ZodLiteral<"turn.boundary">;
    providerCheckpointId: z.ZodOptional<z.ZodString>;
    providerTurnId: z.ZodOptional<z.ZodString>;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
    }>;
}, z.core.$strip>, z.ZodObject<{
    attach: z.ZodOptional<z.ZodEnum<{
        currentOrLast: "currentOrLast";
        open: "open";
    }>>;
    item: z.ZodDiscriminatedUnion<[z.ZodObject<{
        aggregatedOutput: z.ZodOptional<z.ZodString>;
        command: z.ZodString;
        cwd: z.ZodString;
        durationMs: z.ZodOptional<z.ZodNumber>;
        exitCode: z.ZodOptional<z.ZodNumber>;
        type: z.ZodLiteral<"command">;
    }, z.core.$strip>, z.ZodObject<{
        changes: z.ZodArray<z.ZodObject<{
            diff: z.ZodOptional<z.ZodString>;
            kind: z.ZodEnum<{
                add: "add";
                delete: "delete";
                update: "update";
            }>;
            movePath: z.ZodOptional<z.ZodString>;
            newText: z.ZodOptional<z.ZodString>;
            oldText: z.ZodOptional<z.ZodString>;
            path: z.ZodString;
        }, z.core.$strip>>;
        type: z.ZodLiteral<"fileChange">;
    }, z.core.$strip>, z.ZodObject<{
        args: z.ZodOptional<z.ZodUnknown>;
        durationMs: z.ZodOptional<z.ZodNumber>;
        error: z.ZodOptional<z.ZodString>;
        result: z.ZodOptional<z.ZodUnknown>;
        server: z.ZodOptional<z.ZodString>;
        tool: z.ZodString;
        type: z.ZodLiteral<"tool">;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"compaction">;
    }, z.core.$strip>, z.ZodObject<{
        text: z.ZodString;
        type: z.ZodLiteral<"agentMessage">;
    }, z.core.$strip>, z.ZodObject<{
        content: z.ZodArray<z.ZodString>;
        summary: z.ZodArray<z.ZodString>;
        type: z.ZodLiteral<"reasoning">;
    }, z.core.$strip>, z.ZodObject<{
        text: z.ZodString;
        type: z.ZodLiteral<"plan">;
    }, z.core.$strip>, z.ZodObject<{
        queries: z.ZodArray<z.ZodString>;
        type: z.ZodLiteral<"webSearch">;
    }, z.core.$strip>, z.ZodObject<{
        pattern: z.ZodNullable<z.ZodString>;
        prompt: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        type: z.ZodLiteral<"webFetch">;
        url: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        path: z.ZodString;
        type: z.ZodLiteral<"imageView">;
    }, z.core.$strip>, z.ZodObject<{
        description: z.ZodString;
        error: z.ZodOptional<z.ZodString>;
        familyId: z.ZodString;
        outputFile: z.ZodOptional<z.ZodString>;
        skipTranscript: z.ZodBoolean;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        summary: z.ZodOptional<z.ZodString>;
        taskStatus: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            killed: "killed";
            paused: "paused";
            pending: "pending";
            running: "running";
            stopped: "stopped";
        }>;
        taskType: z.ZodString;
        type: z.ZodLiteral<"backgroundTask">;
        usage: z.ZodOptional<z.ZodObject<{
            durationMs: z.ZodNumber;
            toolUses: z.ZodNumber;
            totalTokens: z.ZodNumber;
        }, z.core.$strip>>;
        workflow: z.ZodOptional<z.ZodObject<{
            agents: z.ZodArray<z.ZodObject<{
                agentType: z.ZodOptional<z.ZodString>;
                attempt: z.ZodNumber;
                cached: z.ZodBoolean;
                durationMs: z.ZodOptional<z.ZodNumber>;
                error: z.ZodOptional<z.ZodString>;
                index: z.ZodNumber;
                isolation: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                lastProgressAt: z.ZodNumber;
                lastToolName: z.ZodOptional<z.ZodString>;
                lastToolSummary: z.ZodOptional<z.ZodString>;
                model: z.ZodString;
                phaseIndex: z.ZodOptional<z.ZodNumber>;
                phaseTitle: z.ZodOptional<z.ZodString>;
                promptPreview: z.ZodOptional<z.ZodString>;
                queuedAt: z.ZodOptional<z.ZodNumber>;
                resultPreview: z.ZodOptional<z.ZodString>;
                startedAt: z.ZodOptional<z.ZodNumber>;
                state: z.ZodEnum<{
                    done: "done";
                    failed: "failed";
                    queued: "queued";
                    running: "running";
                    skipped: "skipped";
                }>;
                tokens: z.ZodOptional<z.ZodNumber>;
                toolCalls: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            phases: z.ZodArray<z.ZodObject<{
                index: z.ZodNumber;
                kind: z.ZodOptional<z.ZodString>;
                title: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        workflowName: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        cmd: z.ZodOptional<z.ZodString>;
        path: z.ZodString;
        type: z.ZodLiteral<"fileRead">;
    }, z.core.$strip>, z.ZodObject<{
        cmd: z.ZodOptional<z.ZodString>;
        mode: z.ZodEnum<{
            content: "content";
            list: "list";
            path: "path";
        }>;
        path: z.ZodOptional<z.ZodString>;
        query: z.ZodString;
        type: z.ZodLiteral<"search">;
    }, z.core.$strip>, z.ZodObject<{
        background: z.ZodBoolean;
        childRef: z.ZodString;
        label: z.ZodString;
        summary: z.ZodOptional<z.ZodString>;
        type: z.ZodLiteral<"delegation">;
    }, z.core.$strip>, z.ZodObject<{
        explanation: z.ZodOptional<z.ZodString>;
        steps: z.ZodArray<z.ZodObject<{
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                completed: "completed";
                failed: "failed";
                pending: "pending";
            }>>;
            step: z.ZodString;
        }, z.core.$strip>>;
        type: z.ZodLiteral<"planSteps">;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodString & z.ZodType<`${string}/${string}`, string, z.core.$ZodTypeInternals<`${string}/${string}`, string>>;
        payload: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
        type: z.ZodLiteral<"extension">;
    }, z.core.$strip>], "type">;
    key: z.ZodObject<{
        channel: z.ZodOptional<z.ZodString>;
        parentRef: z.ZodOptional<z.ZodString>;
        providerItemId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    kind: z.ZodLiteral<"item.open">;
    noTurnFallback: z.ZodOptional<z.ZodObject<{
        raw: z.ZodObject<{
            id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            jsonrpc: z.ZodLiteral<"2.0">;
            method: z.ZodString;
            params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
        }, z.core.$strip>;
        rawType: z.ZodString;
    }, z.core.$strip>>;
    presentation: z.ZodOptional<z.ZodObject<{
        badge: z.ZodOptional<z.ZodObject<{
            glyph: z.ZodString;
            hint: z.ZodString;
            label: z.ZodString;
            tone: z.ZodEnum<{
                destructive: "destructive";
                neutral: "neutral";
            }>;
        }, z.core.$strip>>;
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    providerTurnId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    aggregatedOutput: z.ZodOptional<z.ZodString>;
    approvalStatus: z.ZodOptional<z.ZodLiteral<"denied">>;
    exitCode: z.ZodOptional<z.ZodNumber>;
    item: z.ZodDiscriminatedUnion<[z.ZodObject<{
        aggregatedOutput: z.ZodOptional<z.ZodString>;
        command: z.ZodString;
        cwd: z.ZodString;
        durationMs: z.ZodOptional<z.ZodNumber>;
        exitCode: z.ZodOptional<z.ZodNumber>;
        type: z.ZodLiteral<"command">;
    }, z.core.$strip>, z.ZodObject<{
        changes: z.ZodArray<z.ZodObject<{
            diff: z.ZodOptional<z.ZodString>;
            kind: z.ZodEnum<{
                add: "add";
                delete: "delete";
                update: "update";
            }>;
            movePath: z.ZodOptional<z.ZodString>;
            newText: z.ZodOptional<z.ZodString>;
            oldText: z.ZodOptional<z.ZodString>;
            path: z.ZodString;
        }, z.core.$strip>>;
        type: z.ZodLiteral<"fileChange">;
    }, z.core.$strip>, z.ZodObject<{
        args: z.ZodOptional<z.ZodUnknown>;
        durationMs: z.ZodOptional<z.ZodNumber>;
        error: z.ZodOptional<z.ZodString>;
        result: z.ZodOptional<z.ZodUnknown>;
        server: z.ZodOptional<z.ZodString>;
        tool: z.ZodString;
        type: z.ZodLiteral<"tool">;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"compaction">;
    }, z.core.$strip>, z.ZodObject<{
        text: z.ZodString;
        type: z.ZodLiteral<"agentMessage">;
    }, z.core.$strip>, z.ZodObject<{
        content: z.ZodArray<z.ZodString>;
        summary: z.ZodArray<z.ZodString>;
        type: z.ZodLiteral<"reasoning">;
    }, z.core.$strip>, z.ZodObject<{
        text: z.ZodString;
        type: z.ZodLiteral<"plan">;
    }, z.core.$strip>, z.ZodObject<{
        queries: z.ZodArray<z.ZodString>;
        type: z.ZodLiteral<"webSearch">;
    }, z.core.$strip>, z.ZodObject<{
        pattern: z.ZodNullable<z.ZodString>;
        prompt: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        type: z.ZodLiteral<"webFetch">;
        url: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        path: z.ZodString;
        type: z.ZodLiteral<"imageView">;
    }, z.core.$strip>, z.ZodObject<{
        description: z.ZodString;
        error: z.ZodOptional<z.ZodString>;
        familyId: z.ZodString;
        outputFile: z.ZodOptional<z.ZodString>;
        skipTranscript: z.ZodBoolean;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        summary: z.ZodOptional<z.ZodString>;
        taskStatus: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            killed: "killed";
            paused: "paused";
            pending: "pending";
            running: "running";
            stopped: "stopped";
        }>;
        taskType: z.ZodString;
        type: z.ZodLiteral<"backgroundTask">;
        usage: z.ZodOptional<z.ZodObject<{
            durationMs: z.ZodNumber;
            toolUses: z.ZodNumber;
            totalTokens: z.ZodNumber;
        }, z.core.$strip>>;
        workflow: z.ZodOptional<z.ZodObject<{
            agents: z.ZodArray<z.ZodObject<{
                agentType: z.ZodOptional<z.ZodString>;
                attempt: z.ZodNumber;
                cached: z.ZodBoolean;
                durationMs: z.ZodOptional<z.ZodNumber>;
                error: z.ZodOptional<z.ZodString>;
                index: z.ZodNumber;
                isolation: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                lastProgressAt: z.ZodNumber;
                lastToolName: z.ZodOptional<z.ZodString>;
                lastToolSummary: z.ZodOptional<z.ZodString>;
                model: z.ZodString;
                phaseIndex: z.ZodOptional<z.ZodNumber>;
                phaseTitle: z.ZodOptional<z.ZodString>;
                promptPreview: z.ZodOptional<z.ZodString>;
                queuedAt: z.ZodOptional<z.ZodNumber>;
                resultPreview: z.ZodOptional<z.ZodString>;
                startedAt: z.ZodOptional<z.ZodNumber>;
                state: z.ZodEnum<{
                    done: "done";
                    failed: "failed";
                    queued: "queued";
                    running: "running";
                    skipped: "skipped";
                }>;
                tokens: z.ZodOptional<z.ZodNumber>;
                toolCalls: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            phases: z.ZodArray<z.ZodObject<{
                index: z.ZodNumber;
                kind: z.ZodOptional<z.ZodString>;
                title: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        workflowName: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        cmd: z.ZodOptional<z.ZodString>;
        path: z.ZodString;
        type: z.ZodLiteral<"fileRead">;
    }, z.core.$strip>, z.ZodObject<{
        cmd: z.ZodOptional<z.ZodString>;
        mode: z.ZodEnum<{
            content: "content";
            list: "list";
            path: "path";
        }>;
        path: z.ZodOptional<z.ZodString>;
        query: z.ZodString;
        type: z.ZodLiteral<"search">;
    }, z.core.$strip>, z.ZodObject<{
        background: z.ZodBoolean;
        childRef: z.ZodString;
        label: z.ZodString;
        summary: z.ZodOptional<z.ZodString>;
        type: z.ZodLiteral<"delegation">;
    }, z.core.$strip>, z.ZodObject<{
        explanation: z.ZodOptional<z.ZodString>;
        steps: z.ZodArray<z.ZodObject<{
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                completed: "completed";
                failed: "failed";
                pending: "pending";
            }>>;
            step: z.ZodString;
        }, z.core.$strip>>;
        type: z.ZodLiteral<"planSteps">;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodString & z.ZodType<`${string}/${string}`, string, z.core.$ZodTypeInternals<`${string}/${string}`, string>>;
        payload: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
        type: z.ZodLiteral<"extension">;
    }, z.core.$strip>], "type">;
    key: z.ZodObject<{
        channel: z.ZodOptional<z.ZodString>;
        parentRef: z.ZodOptional<z.ZodString>;
        providerItemId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    kind: z.ZodLiteral<"item.close">;
    noTurnFallback: z.ZodOptional<z.ZodObject<{
        raw: z.ZodObject<{
            id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            jsonrpc: z.ZodLiteral<"2.0">;
            method: z.ZodString;
            params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
        }, z.core.$strip>;
        rawType: z.ZodString;
    }, z.core.$strip>>;
    presentation: z.ZodOptional<z.ZodObject<{
        badge: z.ZodOptional<z.ZodObject<{
            glyph: z.ZodString;
            hint: z.ZodString;
            label: z.ZodString;
            tone: z.ZodEnum<{
                destructive: "destructive";
                neutral: "neutral";
            }>;
        }, z.core.$strip>>;
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    providerTurnId: z.ZodOptional<z.ZodString>;
    resultText: z.ZodOptional<z.ZodString>;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
        pending: "pending";
    }>;
}, z.core.$strip>, z.ZodObject<{
    flush: z.ZodOptional<z.ZodBoolean>;
    key: z.ZodObject<{
        channel: z.ZodOptional<z.ZodString>;
        parentRef: z.ZodOptional<z.ZodString>;
        providerItemId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    kind: z.ZodLiteral<"item.progress">;
    message: z.ZodOptional<z.ZodString>;
    noTurnFallback: z.ZodOptional<z.ZodObject<{
        raw: z.ZodObject<{
            id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            jsonrpc: z.ZodLiteral<"2.0">;
            method: z.ZodString;
            params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
        }, z.core.$strip>;
        rawType: z.ZodString;
    }, z.core.$strip>>;
    providerTurnId: z.ZodOptional<z.ZodString>;
    snapshot: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        description: z.ZodString;
        error: z.ZodOptional<z.ZodString>;
        familyId: z.ZodString;
        outputFile: z.ZodOptional<z.ZodString>;
        skipTranscript: z.ZodBoolean;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        summary: z.ZodOptional<z.ZodString>;
        taskStatus: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            killed: "killed";
            paused: "paused";
            pending: "pending";
            running: "running";
            stopped: "stopped";
        }>;
        taskType: z.ZodString;
        type: z.ZodLiteral<"backgroundTask">;
        usage: z.ZodOptional<z.ZodObject<{
            durationMs: z.ZodNumber;
            toolUses: z.ZodNumber;
            totalTokens: z.ZodNumber;
        }, z.core.$strip>>;
        workflow: z.ZodOptional<z.ZodObject<{
            agents: z.ZodArray<z.ZodObject<{
                agentType: z.ZodOptional<z.ZodString>;
                attempt: z.ZodNumber;
                cached: z.ZodBoolean;
                durationMs: z.ZodOptional<z.ZodNumber>;
                error: z.ZodOptional<z.ZodString>;
                index: z.ZodNumber;
                isolation: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                lastProgressAt: z.ZodNumber;
                lastToolName: z.ZodOptional<z.ZodString>;
                lastToolSummary: z.ZodOptional<z.ZodString>;
                model: z.ZodString;
                phaseIndex: z.ZodOptional<z.ZodNumber>;
                phaseTitle: z.ZodOptional<z.ZodString>;
                promptPreview: z.ZodOptional<z.ZodString>;
                queuedAt: z.ZodOptional<z.ZodNumber>;
                resultPreview: z.ZodOptional<z.ZodString>;
                startedAt: z.ZodOptional<z.ZodNumber>;
                state: z.ZodEnum<{
                    done: "done";
                    failed: "failed";
                    queued: "queued";
                    running: "running";
                    skipped: "skipped";
                }>;
                tokens: z.ZodOptional<z.ZodNumber>;
                toolCalls: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            phases: z.ZodArray<z.ZodObject<{
                index: z.ZodNumber;
                kind: z.ZodOptional<z.ZodString>;
                title: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        workflowName: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        background: z.ZodBoolean;
        childRef: z.ZodString;
        label: z.ZodString;
        summary: z.ZodOptional<z.ZodString>;
        type: z.ZodLiteral<"delegation">;
    }, z.core.$strip>], "type">>;
}, z.core.$strip>, z.ZodObject<{
    channel: z.ZodEnum<{
        agentMessage: "agentMessage";
        plan: "plan";
        reasoningSummary: "reasoningSummary";
        reasoningText: "reasoningText";
    }>;
    key: z.ZodObject<{
        channel: z.ZodOptional<z.ZodString>;
        parentRef: z.ZodOptional<z.ZodString>;
        providerItemId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    kind: z.ZodLiteral<"item.textDelta">;
    noTurnFallback: z.ZodOptional<z.ZodObject<{
        raw: z.ZodObject<{
            id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            jsonrpc: z.ZodLiteral<"2.0">;
            method: z.ZodString;
            params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
        }, z.core.$strip>;
        rawType: z.ZodString;
    }, z.core.$strip>>;
    providerTurnId: z.ZodOptional<z.ZodString>;
    text: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    channel: z.ZodEnum<{
        agentMessage: "agentMessage";
        plan: "plan";
        reasoningSummary: "reasoningSummary";
        reasoningText: "reasoningText";
    }>;
    key: z.ZodObject<{
        channel: z.ZodOptional<z.ZodString>;
        parentRef: z.ZodOptional<z.ZodString>;
        providerItemId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    kind: z.ZodLiteral<"item.textClose">;
    noTurnFallback: z.ZodOptional<z.ZodObject<{
        raw: z.ZodObject<{
            id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            jsonrpc: z.ZodLiteral<"2.0">;
            method: z.ZodString;
            params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
        }, z.core.$strip>;
        rawType: z.ZodString;
    }, z.core.$strip>>;
    providerTurnId: z.ZodOptional<z.ZodString>;
    text: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    channel: z.ZodEnum<{
        command: "command";
        fileChange: "fileChange";
    }>;
    key: z.ZodObject<{
        channel: z.ZodOptional<z.ZodString>;
        parentRef: z.ZodOptional<z.ZodString>;
        providerItemId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    kind: z.ZodLiteral<"item.outputDelta">;
    noTurnFallback: z.ZodOptional<z.ZodObject<{
        raw: z.ZodObject<{
            id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            jsonrpc: z.ZodLiteral<"2.0">;
            method: z.ZodString;
            params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
        }, z.core.$strip>;
        rawType: z.ZodString;
    }, z.core.$strip>>;
    providerTurnId: z.ZodOptional<z.ZodString>;
    text: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    key: z.ZodObject<{
        channel: z.ZodOptional<z.ZodString>;
        parentRef: z.ZodOptional<z.ZodString>;
        providerItemId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    kind: z.ZodLiteral<"command.outputSnapshot">;
    noTurnFallback: z.ZodOptional<z.ZodObject<{
        raw: z.ZodObject<{
            id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            jsonrpc: z.ZodLiteral<"2.0">;
            method: z.ZodString;
            params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
        }, z.core.$strip>;
        rawType: z.ZodString;
    }, z.core.$strip>>;
    text: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"usage">;
    last: z.ZodObject<{
        cachedInputTokens: z.ZodNumber;
        inputTokens: z.ZodNumber;
        outputTokens: z.ZodNumber;
        reasoningOutputTokens: z.ZodNumber;
        totalTokens: z.ZodNumber;
    }, z.core.$strip>;
    modelContextWindow: z.ZodNullable<z.ZodNumber>;
    providerTurnId: z.ZodOptional<z.ZodString>;
    total: z.ZodObject<{
        cachedInputTokens: z.ZodNumber;
        inputTokens: z.ZodNumber;
        outputTokens: z.ZodNumber;
        reasoningOutputTokens: z.ZodNumber;
        totalTokens: z.ZodNumber;
    }, z.core.$strip>;
}, z.core.$strip>, z.ZodObject<{
    attach: z.ZodEnum<{
        currentOrLast: "currentOrLast";
        open: "open";
    }>;
    estimated: z.ZodBoolean;
    kind: z.ZodLiteral<"contextWindow">;
    providerTurnId: z.ZodOptional<z.ZodString>;
    size: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    used: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"context.compacted">;
    noTurnFallback: z.ZodOptional<z.ZodObject<{
        raw: z.ZodObject<{
            id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            jsonrpc: z.ZodLiteral<"2.0">;
            method: z.ZodString;
            params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
        }, z.core.$strip>;
        rawType: z.ZodString;
    }, z.core.$strip>>;
    providerTurnId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"context.cleared">;
}, z.core.$strip>, z.ZodObject<{
    diff: z.ZodString;
    kind: z.ZodLiteral<"turn.diff">;
    providerTurnId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"thread.started">;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"thread.identity">;
    providerThreadId: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"thread.name">;
    name: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    extensionKind: z.ZodString & z.ZodType<`${string}/${string}`, string, z.core.$ZodTypeInternals<`${string}/${string}`, string>>;
    kind: z.ZodLiteral<"extension.state">;
    payload: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"provider.rateLimits">;
    rateLimits: z.ZodObject<{
        kind: z.ZodEnum<{
            "spend-control": "spend-control";
            "subscription-window": "subscription-window";
            credits: "credits";
            unknown: "unknown";
        }>;
        overageReason: z.ZodNullable<z.ZodString>;
        overageStatus: z.ZodNullable<z.ZodEnum<{
            allowed: "allowed";
            rejected: "rejected";
            unavailable: "unavailable";
            warning: "warning";
        }>>;
        providerId: z.ZodString;
        reachedReason: z.ZodNullable<z.ZodString>;
        status: z.ZodEnum<{
            allowed: "allowed";
            blocked: "blocked";
            unknown: "unknown";
            warning: "warning";
        }>;
        windows: z.ZodArray<z.ZodObject<{
            label: z.ZodNullable<z.ZodString>;
            providerKey: z.ZodNullable<z.ZodString>;
            resetsAtMs: z.ZodNullable<z.ZodNumber>;
            status: z.ZodEnum<{
                allowed: "allowed";
                blocked: "blocked";
                unknown: "unknown";
                warning: "warning";
            }>;
        }, z.core.$strip>>;
    }, z.core.$strip>;
}, z.core.$strip>, z.ZodObject<{
    category: z.ZodOptional<z.ZodEnum<{
        "active-turn-not-steerable": "active-turn-not-steerable";
        "bad-request": "bad-request";
        "budget-exceeded": "budget-exceeded";
        "connection-failed": "connection-failed";
        "context-window-exceeded": "context-window-exceeded";
        "max-output-tokens": "max-output-tokens";
        "max-turns": "max-turns";
        "rate-limit": "rate-limit";
        "stream-disconnected": "stream-disconnected";
        "structured-output-retries": "structured-output-retries";
        "thread-rollback-failed": "thread-rollback-failed";
        "too-many-failed-attempts": "too-many-failed-attempts";
        billing: "billing";
        internal: "internal";
        overloaded: "overloaded";
        policy: "policy";
        sandbox: "sandbox";
        unauthorized: "unauthorized";
        unknown: "unknown";
    }>>;
    detail: z.ZodOptional<z.ZodString>;
    errorInfo: z.ZodOptional<z.ZodObject<{
        category: z.ZodEnum<{
            "active-turn-not-steerable": "active-turn-not-steerable";
            "bad-request": "bad-request";
            "budget-exceeded": "budget-exceeded";
            "connection-failed": "connection-failed";
            "context-window-exceeded": "context-window-exceeded";
            "max-output-tokens": "max-output-tokens";
            "max-turns": "max-turns";
            "rate-limit": "rate-limit";
            "stream-disconnected": "stream-disconnected";
            "structured-output-retries": "structured-output-retries";
            "thread-rollback-failed": "thread-rollback-failed";
            "too-many-failed-attempts": "too-many-failed-attempts";
            billing: "billing";
            internal: "internal";
            overloaded: "overloaded";
            policy: "policy";
            sandbox: "sandbox";
            unauthorized: "unauthorized";
            unknown: "unknown";
        }>;
        httpStatusCode: z.ZodNullable<z.ZodNumber>;
        providerCode: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>;
    kind: z.ZodLiteral<"provider.error">;
    message: z.ZodString;
    providerTurnId: z.ZodOptional<z.ZodString>;
    settlesTurn: z.ZodOptional<z.ZodBoolean>;
    threadScoped: z.ZodOptional<z.ZodBoolean>;
    willRetry: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>, z.ZodObject<{
    fallbackModel: z.ZodString;
    kind: z.ZodLiteral<"provider.modelFallback">;
    message: z.ZodString;
    originalModel: z.ZodString;
    reason: z.ZodEnum<{
        provider: "provider";
        refusal: "refusal";
    }>;
}, z.core.$strip>, z.ZodObject<{
    category: z.ZodOptional<z.ZodEnum<{
        "compaction-skipped": "compaction-skipped";
        config: "config";
        deprecation: "deprecation";
        general: "general";
    }>>;
    details: z.ZodOptional<z.ZodString>;
    kind: z.ZodLiteral<"provider.warning">;
    summary: z.ZodOptional<z.ZodString>;
    vouchedTurn: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"unhandled">;
    onlyIfNoTurn: z.ZodOptional<z.ZodBoolean>;
    parentRef: z.ZodOptional<z.ZodString>;
    providerTurnId: z.ZodOptional<z.ZodString>;
    raw: z.ZodObject<{
        id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
        jsonrpc: z.ZodLiteral<"2.0">;
        method: z.ZodString;
        params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
    }, z.core.$strip>;
    rawType: z.ZodString;
    vouchedTurn: z.ZodBoolean;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"session.ended">;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"session.reset">;
}, z.core.$strip>], "kind">;
type ThreadDelta = z.infer<typeof threadDeltaSchema>;
type ThreadDeltaKind = ThreadDelta["kind"];
declare const threadDeltaNotificationParamsSchema: z.ZodObject<{
    deltas: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        clientRequestId: z.ZodString;
        kind: z.ZodLiteral<"input.accepted">;
        providerTurnId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"input.provider">;
        parentRef: z.ZodOptional<z.ZodString>;
        text: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"turn.open">;
        parentRef: z.ZodOptional<z.ZodString>;
        providerTurnId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        claimIfIdle: z.ZodOptional<z.ZodBoolean>;
        error: z.ZodOptional<z.ZodObject<{
            message: z.ZodString;
        }, z.core.$strip>>;
        kind: z.ZodLiteral<"turn.boundary">;
        providerCheckpointId: z.ZodOptional<z.ZodString>;
        providerTurnId: z.ZodOptional<z.ZodString>;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
        }>;
    }, z.core.$strip>, z.ZodObject<{
        attach: z.ZodOptional<z.ZodEnum<{
            currentOrLast: "currentOrLast";
            open: "open";
        }>>;
        item: z.ZodDiscriminatedUnion<[z.ZodObject<{
            aggregatedOutput: z.ZodOptional<z.ZodString>;
            command: z.ZodString;
            cwd: z.ZodString;
            durationMs: z.ZodOptional<z.ZodNumber>;
            exitCode: z.ZodOptional<z.ZodNumber>;
            type: z.ZodLiteral<"command">;
        }, z.core.$strip>, z.ZodObject<{
            changes: z.ZodArray<z.ZodObject<{
                diff: z.ZodOptional<z.ZodString>;
                kind: z.ZodEnum<{
                    add: "add";
                    delete: "delete";
                    update: "update";
                }>;
                movePath: z.ZodOptional<z.ZodString>;
                newText: z.ZodOptional<z.ZodString>;
                oldText: z.ZodOptional<z.ZodString>;
                path: z.ZodString;
            }, z.core.$strip>>;
            type: z.ZodLiteral<"fileChange">;
        }, z.core.$strip>, z.ZodObject<{
            args: z.ZodOptional<z.ZodUnknown>;
            durationMs: z.ZodOptional<z.ZodNumber>;
            error: z.ZodOptional<z.ZodString>;
            result: z.ZodOptional<z.ZodUnknown>;
            server: z.ZodOptional<z.ZodString>;
            tool: z.ZodString;
            type: z.ZodLiteral<"tool">;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"compaction">;
        }, z.core.$strip>, z.ZodObject<{
            text: z.ZodString;
            type: z.ZodLiteral<"agentMessage">;
        }, z.core.$strip>, z.ZodObject<{
            content: z.ZodArray<z.ZodString>;
            summary: z.ZodArray<z.ZodString>;
            type: z.ZodLiteral<"reasoning">;
        }, z.core.$strip>, z.ZodObject<{
            text: z.ZodString;
            type: z.ZodLiteral<"plan">;
        }, z.core.$strip>, z.ZodObject<{
            queries: z.ZodArray<z.ZodString>;
            type: z.ZodLiteral<"webSearch">;
        }, z.core.$strip>, z.ZodObject<{
            pattern: z.ZodNullable<z.ZodString>;
            prompt: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            type: z.ZodLiteral<"webFetch">;
            url: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            path: z.ZodString;
            type: z.ZodLiteral<"imageView">;
        }, z.core.$strip>, z.ZodObject<{
            description: z.ZodString;
            error: z.ZodOptional<z.ZodString>;
            familyId: z.ZodString;
            outputFile: z.ZodOptional<z.ZodString>;
            skipTranscript: z.ZodBoolean;
            status: z.ZodEnum<{
                completed: "completed";
                failed: "failed";
                interrupted: "interrupted";
                pending: "pending";
            }>;
            summary: z.ZodOptional<z.ZodString>;
            taskStatus: z.ZodEnum<{
                completed: "completed";
                failed: "failed";
                killed: "killed";
                paused: "paused";
                pending: "pending";
                running: "running";
                stopped: "stopped";
            }>;
            taskType: z.ZodString;
            type: z.ZodLiteral<"backgroundTask">;
            usage: z.ZodOptional<z.ZodObject<{
                durationMs: z.ZodNumber;
                toolUses: z.ZodNumber;
                totalTokens: z.ZodNumber;
            }, z.core.$strip>>;
            workflow: z.ZodOptional<z.ZodObject<{
                agents: z.ZodArray<z.ZodObject<{
                    agentType: z.ZodOptional<z.ZodString>;
                    attempt: z.ZodNumber;
                    cached: z.ZodBoolean;
                    durationMs: z.ZodOptional<z.ZodNumber>;
                    error: z.ZodOptional<z.ZodString>;
                    index: z.ZodNumber;
                    isolation: z.ZodOptional<z.ZodString>;
                    label: z.ZodString;
                    lastProgressAt: z.ZodNumber;
                    lastToolName: z.ZodOptional<z.ZodString>;
                    lastToolSummary: z.ZodOptional<z.ZodString>;
                    model: z.ZodString;
                    phaseIndex: z.ZodOptional<z.ZodNumber>;
                    phaseTitle: z.ZodOptional<z.ZodString>;
                    promptPreview: z.ZodOptional<z.ZodString>;
                    queuedAt: z.ZodOptional<z.ZodNumber>;
                    resultPreview: z.ZodOptional<z.ZodString>;
                    startedAt: z.ZodOptional<z.ZodNumber>;
                    state: z.ZodEnum<{
                        done: "done";
                        failed: "failed";
                        queued: "queued";
                        running: "running";
                        skipped: "skipped";
                    }>;
                    tokens: z.ZodOptional<z.ZodNumber>;
                    toolCalls: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strip>>;
                phases: z.ZodArray<z.ZodObject<{
                    index: z.ZodNumber;
                    kind: z.ZodOptional<z.ZodString>;
                    title: z.ZodString;
                }, z.core.$strip>>;
            }, z.core.$strip>>;
            workflowName: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            cmd: z.ZodOptional<z.ZodString>;
            path: z.ZodString;
            type: z.ZodLiteral<"fileRead">;
        }, z.core.$strip>, z.ZodObject<{
            cmd: z.ZodOptional<z.ZodString>;
            mode: z.ZodEnum<{
                content: "content";
                list: "list";
                path: "path";
            }>;
            path: z.ZodOptional<z.ZodString>;
            query: z.ZodString;
            type: z.ZodLiteral<"search">;
        }, z.core.$strip>, z.ZodObject<{
            background: z.ZodBoolean;
            childRef: z.ZodString;
            label: z.ZodString;
            summary: z.ZodOptional<z.ZodString>;
            type: z.ZodLiteral<"delegation">;
        }, z.core.$strip>, z.ZodObject<{
            explanation: z.ZodOptional<z.ZodString>;
            steps: z.ZodArray<z.ZodObject<{
                status: z.ZodOptional<z.ZodEnum<{
                    active: "active";
                    completed: "completed";
                    failed: "failed";
                    pending: "pending";
                }>>;
                step: z.ZodString;
            }, z.core.$strip>>;
            type: z.ZodLiteral<"planSteps">;
        }, z.core.$strip>, z.ZodObject<{
            kind: z.ZodString & z.ZodType<`${string}/${string}`, string, z.core.$ZodTypeInternals<`${string}/${string}`, string>>;
            payload: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
            type: z.ZodLiteral<"extension">;
        }, z.core.$strip>], "type">;
        key: z.ZodObject<{
            channel: z.ZodOptional<z.ZodString>;
            parentRef: z.ZodOptional<z.ZodString>;
            providerItemId: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        kind: z.ZodLiteral<"item.open">;
        noTurnFallback: z.ZodOptional<z.ZodObject<{
            raw: z.ZodObject<{
                id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
                jsonrpc: z.ZodLiteral<"2.0">;
                method: z.ZodString;
                params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
            }, z.core.$strip>;
            rawType: z.ZodString;
        }, z.core.$strip>>;
        presentation: z.ZodOptional<z.ZodObject<{
            badge: z.ZodOptional<z.ZodObject<{
                glyph: z.ZodString;
                hint: z.ZodString;
                label: z.ZodString;
                tone: z.ZodEnum<{
                    destructive: "destructive";
                    neutral: "neutral";
                }>;
            }, z.core.$strip>>;
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        providerTurnId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        aggregatedOutput: z.ZodOptional<z.ZodString>;
        approvalStatus: z.ZodOptional<z.ZodLiteral<"denied">>;
        exitCode: z.ZodOptional<z.ZodNumber>;
        item: z.ZodDiscriminatedUnion<[z.ZodObject<{
            aggregatedOutput: z.ZodOptional<z.ZodString>;
            command: z.ZodString;
            cwd: z.ZodString;
            durationMs: z.ZodOptional<z.ZodNumber>;
            exitCode: z.ZodOptional<z.ZodNumber>;
            type: z.ZodLiteral<"command">;
        }, z.core.$strip>, z.ZodObject<{
            changes: z.ZodArray<z.ZodObject<{
                diff: z.ZodOptional<z.ZodString>;
                kind: z.ZodEnum<{
                    add: "add";
                    delete: "delete";
                    update: "update";
                }>;
                movePath: z.ZodOptional<z.ZodString>;
                newText: z.ZodOptional<z.ZodString>;
                oldText: z.ZodOptional<z.ZodString>;
                path: z.ZodString;
            }, z.core.$strip>>;
            type: z.ZodLiteral<"fileChange">;
        }, z.core.$strip>, z.ZodObject<{
            args: z.ZodOptional<z.ZodUnknown>;
            durationMs: z.ZodOptional<z.ZodNumber>;
            error: z.ZodOptional<z.ZodString>;
            result: z.ZodOptional<z.ZodUnknown>;
            server: z.ZodOptional<z.ZodString>;
            tool: z.ZodString;
            type: z.ZodLiteral<"tool">;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"compaction">;
        }, z.core.$strip>, z.ZodObject<{
            text: z.ZodString;
            type: z.ZodLiteral<"agentMessage">;
        }, z.core.$strip>, z.ZodObject<{
            content: z.ZodArray<z.ZodString>;
            summary: z.ZodArray<z.ZodString>;
            type: z.ZodLiteral<"reasoning">;
        }, z.core.$strip>, z.ZodObject<{
            text: z.ZodString;
            type: z.ZodLiteral<"plan">;
        }, z.core.$strip>, z.ZodObject<{
            queries: z.ZodArray<z.ZodString>;
            type: z.ZodLiteral<"webSearch">;
        }, z.core.$strip>, z.ZodObject<{
            pattern: z.ZodNullable<z.ZodString>;
            prompt: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            type: z.ZodLiteral<"webFetch">;
            url: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            path: z.ZodString;
            type: z.ZodLiteral<"imageView">;
        }, z.core.$strip>, z.ZodObject<{
            description: z.ZodString;
            error: z.ZodOptional<z.ZodString>;
            familyId: z.ZodString;
            outputFile: z.ZodOptional<z.ZodString>;
            skipTranscript: z.ZodBoolean;
            status: z.ZodEnum<{
                completed: "completed";
                failed: "failed";
                interrupted: "interrupted";
                pending: "pending";
            }>;
            summary: z.ZodOptional<z.ZodString>;
            taskStatus: z.ZodEnum<{
                completed: "completed";
                failed: "failed";
                killed: "killed";
                paused: "paused";
                pending: "pending";
                running: "running";
                stopped: "stopped";
            }>;
            taskType: z.ZodString;
            type: z.ZodLiteral<"backgroundTask">;
            usage: z.ZodOptional<z.ZodObject<{
                durationMs: z.ZodNumber;
                toolUses: z.ZodNumber;
                totalTokens: z.ZodNumber;
            }, z.core.$strip>>;
            workflow: z.ZodOptional<z.ZodObject<{
                agents: z.ZodArray<z.ZodObject<{
                    agentType: z.ZodOptional<z.ZodString>;
                    attempt: z.ZodNumber;
                    cached: z.ZodBoolean;
                    durationMs: z.ZodOptional<z.ZodNumber>;
                    error: z.ZodOptional<z.ZodString>;
                    index: z.ZodNumber;
                    isolation: z.ZodOptional<z.ZodString>;
                    label: z.ZodString;
                    lastProgressAt: z.ZodNumber;
                    lastToolName: z.ZodOptional<z.ZodString>;
                    lastToolSummary: z.ZodOptional<z.ZodString>;
                    model: z.ZodString;
                    phaseIndex: z.ZodOptional<z.ZodNumber>;
                    phaseTitle: z.ZodOptional<z.ZodString>;
                    promptPreview: z.ZodOptional<z.ZodString>;
                    queuedAt: z.ZodOptional<z.ZodNumber>;
                    resultPreview: z.ZodOptional<z.ZodString>;
                    startedAt: z.ZodOptional<z.ZodNumber>;
                    state: z.ZodEnum<{
                        done: "done";
                        failed: "failed";
                        queued: "queued";
                        running: "running";
                        skipped: "skipped";
                    }>;
                    tokens: z.ZodOptional<z.ZodNumber>;
                    toolCalls: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strip>>;
                phases: z.ZodArray<z.ZodObject<{
                    index: z.ZodNumber;
                    kind: z.ZodOptional<z.ZodString>;
                    title: z.ZodString;
                }, z.core.$strip>>;
            }, z.core.$strip>>;
            workflowName: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            cmd: z.ZodOptional<z.ZodString>;
            path: z.ZodString;
            type: z.ZodLiteral<"fileRead">;
        }, z.core.$strip>, z.ZodObject<{
            cmd: z.ZodOptional<z.ZodString>;
            mode: z.ZodEnum<{
                content: "content";
                list: "list";
                path: "path";
            }>;
            path: z.ZodOptional<z.ZodString>;
            query: z.ZodString;
            type: z.ZodLiteral<"search">;
        }, z.core.$strip>, z.ZodObject<{
            background: z.ZodBoolean;
            childRef: z.ZodString;
            label: z.ZodString;
            summary: z.ZodOptional<z.ZodString>;
            type: z.ZodLiteral<"delegation">;
        }, z.core.$strip>, z.ZodObject<{
            explanation: z.ZodOptional<z.ZodString>;
            steps: z.ZodArray<z.ZodObject<{
                status: z.ZodOptional<z.ZodEnum<{
                    active: "active";
                    completed: "completed";
                    failed: "failed";
                    pending: "pending";
                }>>;
                step: z.ZodString;
            }, z.core.$strip>>;
            type: z.ZodLiteral<"planSteps">;
        }, z.core.$strip>, z.ZodObject<{
            kind: z.ZodString & z.ZodType<`${string}/${string}`, string, z.core.$ZodTypeInternals<`${string}/${string}`, string>>;
            payload: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
            type: z.ZodLiteral<"extension">;
        }, z.core.$strip>], "type">;
        key: z.ZodObject<{
            channel: z.ZodOptional<z.ZodString>;
            parentRef: z.ZodOptional<z.ZodString>;
            providerItemId: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        kind: z.ZodLiteral<"item.close">;
        noTurnFallback: z.ZodOptional<z.ZodObject<{
            raw: z.ZodObject<{
                id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
                jsonrpc: z.ZodLiteral<"2.0">;
                method: z.ZodString;
                params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
            }, z.core.$strip>;
            rawType: z.ZodString;
        }, z.core.$strip>>;
        presentation: z.ZodOptional<z.ZodObject<{
            badge: z.ZodOptional<z.ZodObject<{
                glyph: z.ZodString;
                hint: z.ZodString;
                label: z.ZodString;
                tone: z.ZodEnum<{
                    destructive: "destructive";
                    neutral: "neutral";
                }>;
            }, z.core.$strip>>;
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        providerTurnId: z.ZodOptional<z.ZodString>;
        resultText: z.ZodOptional<z.ZodString>;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
    }, z.core.$strip>, z.ZodObject<{
        flush: z.ZodOptional<z.ZodBoolean>;
        key: z.ZodObject<{
            channel: z.ZodOptional<z.ZodString>;
            parentRef: z.ZodOptional<z.ZodString>;
            providerItemId: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        kind: z.ZodLiteral<"item.progress">;
        message: z.ZodOptional<z.ZodString>;
        noTurnFallback: z.ZodOptional<z.ZodObject<{
            raw: z.ZodObject<{
                id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
                jsonrpc: z.ZodLiteral<"2.0">;
                method: z.ZodString;
                params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
            }, z.core.$strip>;
            rawType: z.ZodString;
        }, z.core.$strip>>;
        providerTurnId: z.ZodOptional<z.ZodString>;
        snapshot: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
            description: z.ZodString;
            error: z.ZodOptional<z.ZodString>;
            familyId: z.ZodString;
            outputFile: z.ZodOptional<z.ZodString>;
            skipTranscript: z.ZodBoolean;
            status: z.ZodEnum<{
                completed: "completed";
                failed: "failed";
                interrupted: "interrupted";
                pending: "pending";
            }>;
            summary: z.ZodOptional<z.ZodString>;
            taskStatus: z.ZodEnum<{
                completed: "completed";
                failed: "failed";
                killed: "killed";
                paused: "paused";
                pending: "pending";
                running: "running";
                stopped: "stopped";
            }>;
            taskType: z.ZodString;
            type: z.ZodLiteral<"backgroundTask">;
            usage: z.ZodOptional<z.ZodObject<{
                durationMs: z.ZodNumber;
                toolUses: z.ZodNumber;
                totalTokens: z.ZodNumber;
            }, z.core.$strip>>;
            workflow: z.ZodOptional<z.ZodObject<{
                agents: z.ZodArray<z.ZodObject<{
                    agentType: z.ZodOptional<z.ZodString>;
                    attempt: z.ZodNumber;
                    cached: z.ZodBoolean;
                    durationMs: z.ZodOptional<z.ZodNumber>;
                    error: z.ZodOptional<z.ZodString>;
                    index: z.ZodNumber;
                    isolation: z.ZodOptional<z.ZodString>;
                    label: z.ZodString;
                    lastProgressAt: z.ZodNumber;
                    lastToolName: z.ZodOptional<z.ZodString>;
                    lastToolSummary: z.ZodOptional<z.ZodString>;
                    model: z.ZodString;
                    phaseIndex: z.ZodOptional<z.ZodNumber>;
                    phaseTitle: z.ZodOptional<z.ZodString>;
                    promptPreview: z.ZodOptional<z.ZodString>;
                    queuedAt: z.ZodOptional<z.ZodNumber>;
                    resultPreview: z.ZodOptional<z.ZodString>;
                    startedAt: z.ZodOptional<z.ZodNumber>;
                    state: z.ZodEnum<{
                        done: "done";
                        failed: "failed";
                        queued: "queued";
                        running: "running";
                        skipped: "skipped";
                    }>;
                    tokens: z.ZodOptional<z.ZodNumber>;
                    toolCalls: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strip>>;
                phases: z.ZodArray<z.ZodObject<{
                    index: z.ZodNumber;
                    kind: z.ZodOptional<z.ZodString>;
                    title: z.ZodString;
                }, z.core.$strip>>;
            }, z.core.$strip>>;
            workflowName: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            background: z.ZodBoolean;
            childRef: z.ZodString;
            label: z.ZodString;
            summary: z.ZodOptional<z.ZodString>;
            type: z.ZodLiteral<"delegation">;
        }, z.core.$strip>], "type">>;
    }, z.core.$strip>, z.ZodObject<{
        channel: z.ZodEnum<{
            agentMessage: "agentMessage";
            plan: "plan";
            reasoningSummary: "reasoningSummary";
            reasoningText: "reasoningText";
        }>;
        key: z.ZodObject<{
            channel: z.ZodOptional<z.ZodString>;
            parentRef: z.ZodOptional<z.ZodString>;
            providerItemId: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        kind: z.ZodLiteral<"item.textDelta">;
        noTurnFallback: z.ZodOptional<z.ZodObject<{
            raw: z.ZodObject<{
                id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
                jsonrpc: z.ZodLiteral<"2.0">;
                method: z.ZodString;
                params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
            }, z.core.$strip>;
            rawType: z.ZodString;
        }, z.core.$strip>>;
        providerTurnId: z.ZodOptional<z.ZodString>;
        text: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        channel: z.ZodEnum<{
            agentMessage: "agentMessage";
            plan: "plan";
            reasoningSummary: "reasoningSummary";
            reasoningText: "reasoningText";
        }>;
        key: z.ZodObject<{
            channel: z.ZodOptional<z.ZodString>;
            parentRef: z.ZodOptional<z.ZodString>;
            providerItemId: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        kind: z.ZodLiteral<"item.textClose">;
        noTurnFallback: z.ZodOptional<z.ZodObject<{
            raw: z.ZodObject<{
                id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
                jsonrpc: z.ZodLiteral<"2.0">;
                method: z.ZodString;
                params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
            }, z.core.$strip>;
            rawType: z.ZodString;
        }, z.core.$strip>>;
        providerTurnId: z.ZodOptional<z.ZodString>;
        text: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        channel: z.ZodEnum<{
            command: "command";
            fileChange: "fileChange";
        }>;
        key: z.ZodObject<{
            channel: z.ZodOptional<z.ZodString>;
            parentRef: z.ZodOptional<z.ZodString>;
            providerItemId: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        kind: z.ZodLiteral<"item.outputDelta">;
        noTurnFallback: z.ZodOptional<z.ZodObject<{
            raw: z.ZodObject<{
                id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
                jsonrpc: z.ZodLiteral<"2.0">;
                method: z.ZodString;
                params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
            }, z.core.$strip>;
            rawType: z.ZodString;
        }, z.core.$strip>>;
        providerTurnId: z.ZodOptional<z.ZodString>;
        text: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        key: z.ZodObject<{
            channel: z.ZodOptional<z.ZodString>;
            parentRef: z.ZodOptional<z.ZodString>;
            providerItemId: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        kind: z.ZodLiteral<"command.outputSnapshot">;
        noTurnFallback: z.ZodOptional<z.ZodObject<{
            raw: z.ZodObject<{
                id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
                jsonrpc: z.ZodLiteral<"2.0">;
                method: z.ZodString;
                params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
            }, z.core.$strip>;
            rawType: z.ZodString;
        }, z.core.$strip>>;
        text: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"usage">;
        last: z.ZodObject<{
            cachedInputTokens: z.ZodNumber;
            inputTokens: z.ZodNumber;
            outputTokens: z.ZodNumber;
            reasoningOutputTokens: z.ZodNumber;
            totalTokens: z.ZodNumber;
        }, z.core.$strip>;
        modelContextWindow: z.ZodNullable<z.ZodNumber>;
        providerTurnId: z.ZodOptional<z.ZodString>;
        total: z.ZodObject<{
            cachedInputTokens: z.ZodNumber;
            inputTokens: z.ZodNumber;
            outputTokens: z.ZodNumber;
            reasoningOutputTokens: z.ZodNumber;
            totalTokens: z.ZodNumber;
        }, z.core.$strip>;
    }, z.core.$strip>, z.ZodObject<{
        attach: z.ZodEnum<{
            currentOrLast: "currentOrLast";
            open: "open";
        }>;
        estimated: z.ZodBoolean;
        kind: z.ZodLiteral<"contextWindow">;
        providerTurnId: z.ZodOptional<z.ZodString>;
        size: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        used: z.ZodNullable<z.ZodNumber>;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"context.compacted">;
        noTurnFallback: z.ZodOptional<z.ZodObject<{
            raw: z.ZodObject<{
                id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
                jsonrpc: z.ZodLiteral<"2.0">;
                method: z.ZodString;
                params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
            }, z.core.$strip>;
            rawType: z.ZodString;
        }, z.core.$strip>>;
        providerTurnId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"context.cleared">;
    }, z.core.$strip>, z.ZodObject<{
        diff: z.ZodString;
        kind: z.ZodLiteral<"turn.diff">;
        providerTurnId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"thread.started">;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"thread.identity">;
        providerThreadId: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"thread.name">;
        name: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        extensionKind: z.ZodString & z.ZodType<`${string}/${string}`, string, z.core.$ZodTypeInternals<`${string}/${string}`, string>>;
        kind: z.ZodLiteral<"extension.state">;
        payload: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"provider.rateLimits">;
        rateLimits: z.ZodObject<{
            kind: z.ZodEnum<{
                "spend-control": "spend-control";
                "subscription-window": "subscription-window";
                credits: "credits";
                unknown: "unknown";
            }>;
            overageReason: z.ZodNullable<z.ZodString>;
            overageStatus: z.ZodNullable<z.ZodEnum<{
                allowed: "allowed";
                rejected: "rejected";
                unavailable: "unavailable";
                warning: "warning";
            }>>;
            providerId: z.ZodString;
            reachedReason: z.ZodNullable<z.ZodString>;
            status: z.ZodEnum<{
                allowed: "allowed";
                blocked: "blocked";
                unknown: "unknown";
                warning: "warning";
            }>;
            windows: z.ZodArray<z.ZodObject<{
                label: z.ZodNullable<z.ZodString>;
                providerKey: z.ZodNullable<z.ZodString>;
                resetsAtMs: z.ZodNullable<z.ZodNumber>;
                status: z.ZodEnum<{
                    allowed: "allowed";
                    blocked: "blocked";
                    unknown: "unknown";
                    warning: "warning";
                }>;
            }, z.core.$strip>>;
        }, z.core.$strip>;
    }, z.core.$strip>, z.ZodObject<{
        category: z.ZodOptional<z.ZodEnum<{
            "active-turn-not-steerable": "active-turn-not-steerable";
            "bad-request": "bad-request";
            "budget-exceeded": "budget-exceeded";
            "connection-failed": "connection-failed";
            "context-window-exceeded": "context-window-exceeded";
            "max-output-tokens": "max-output-tokens";
            "max-turns": "max-turns";
            "rate-limit": "rate-limit";
            "stream-disconnected": "stream-disconnected";
            "structured-output-retries": "structured-output-retries";
            "thread-rollback-failed": "thread-rollback-failed";
            "too-many-failed-attempts": "too-many-failed-attempts";
            billing: "billing";
            internal: "internal";
            overloaded: "overloaded";
            policy: "policy";
            sandbox: "sandbox";
            unauthorized: "unauthorized";
            unknown: "unknown";
        }>>;
        detail: z.ZodOptional<z.ZodString>;
        errorInfo: z.ZodOptional<z.ZodObject<{
            category: z.ZodEnum<{
                "active-turn-not-steerable": "active-turn-not-steerable";
                "bad-request": "bad-request";
                "budget-exceeded": "budget-exceeded";
                "connection-failed": "connection-failed";
                "context-window-exceeded": "context-window-exceeded";
                "max-output-tokens": "max-output-tokens";
                "max-turns": "max-turns";
                "rate-limit": "rate-limit";
                "stream-disconnected": "stream-disconnected";
                "structured-output-retries": "structured-output-retries";
                "thread-rollback-failed": "thread-rollback-failed";
                "too-many-failed-attempts": "too-many-failed-attempts";
                billing: "billing";
                internal: "internal";
                overloaded: "overloaded";
                policy: "policy";
                sandbox: "sandbox";
                unauthorized: "unauthorized";
                unknown: "unknown";
            }>;
            httpStatusCode: z.ZodNullable<z.ZodNumber>;
            providerCode: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>>;
        kind: z.ZodLiteral<"provider.error">;
        message: z.ZodString;
        providerTurnId: z.ZodOptional<z.ZodString>;
        settlesTurn: z.ZodOptional<z.ZodBoolean>;
        threadScoped: z.ZodOptional<z.ZodBoolean>;
        willRetry: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strip>, z.ZodObject<{
        fallbackModel: z.ZodString;
        kind: z.ZodLiteral<"provider.modelFallback">;
        message: z.ZodString;
        originalModel: z.ZodString;
        reason: z.ZodEnum<{
            provider: "provider";
            refusal: "refusal";
        }>;
    }, z.core.$strip>, z.ZodObject<{
        category: z.ZodOptional<z.ZodEnum<{
            "compaction-skipped": "compaction-skipped";
            config: "config";
            deprecation: "deprecation";
            general: "general";
        }>>;
        details: z.ZodOptional<z.ZodString>;
        kind: z.ZodLiteral<"provider.warning">;
        summary: z.ZodOptional<z.ZodString>;
        vouchedTurn: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"unhandled">;
        onlyIfNoTurn: z.ZodOptional<z.ZodBoolean>;
        parentRef: z.ZodOptional<z.ZodString>;
        providerTurnId: z.ZodOptional<z.ZodString>;
        raw: z.ZodObject<{
            id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            jsonrpc: z.ZodLiteral<"2.0">;
            method: z.ZodString;
            params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
        }, z.core.$strip>;
        rawType: z.ZodString;
        vouchedTurn: z.ZodBoolean;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"session.ended">;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"session.reset">;
    }, z.core.$strip>], "kind">>;
    threadId: z.ZodString;
}, z.core.$loose>;
type ThreadDeltaNotificationParams = z.infer<typeof threadDeltaNotificationParamsSchema>;

declare function presentationTitle(text: string): string | undefined;
declare function presentationDetail(text: string): string;
declare function withTitle(presentation: DeltaPresentation, title: string | undefined): DeltaPresentation;
declare function presentationFileName(path: string): string;
declare const COMPACTION_PRESENTATION: DeltaPresentation;
declare const REASONING_PRESENTATION: DeltaPresentation;
declare function fileReadPresentation(path: string): DeltaPresentation;
declare function searchPresentation(args: {
    mode: "content" | "path";
    query: string;
}): DeltaPresentation;
declare function webSearchPresentation(query: string | undefined): DeltaPresentation;
declare function webFetchPresentation(url: string): DeltaPresentation;
declare function planStepsPresentation(steps: readonly {
    step: string;
    status?: string;
}[]): DeltaPresentation;
declare function toolPresentation(tool: string): DeltaPresentation;

declare const PROVIDER_BRIDGE_EXPORT_NAME = "experimental_providerBridge";
interface ProviderBridgeContext {
    pluginId: string;
    dataDir: string;
    tempDir: string;
}
interface ProviderBridgeDefinition {
    handleLine: (line: string) => void;
    start?: (context: ProviderBridgeContext) => void;
    onClose?: () => void;
    onSigterm?: () => void;
    onSigint?: () => void;
}
interface ProviderBridgeEntry extends ProviderBridgeDefinition {
    experimental_apiVersion: 1;
}
declare function experimental_defineProviderBridge(definition: ProviderBridgeDefinition): ProviderBridgeEntry;

declare const providerMaintenanceParamsSchema: z.ZodObject<{
    cwd: z.ZodOptional<z.ZodString>;
    providerId: z.ZodString;
    providerOptions: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
}, z.core.$loose>;
type ProviderMaintenanceParams = z.infer<typeof providerMaintenanceParamsSchema>;
declare const providerInstallationRequirementSchema: z.ZodEnum<{
    thread_rewind: "thread_rewind";
}>;
type ProviderInstallationRequirement = z.infer<typeof providerInstallationRequirementSchema>;
declare const providerInstallationStatusParamsSchema: z.ZodObject<{
    cwd: z.ZodOptional<z.ZodString>;
    providerId: z.ZodString;
    providerOptions: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    requirement: z.ZodOptional<z.ZodEnum<{
        thread_rewind: "thread_rewind";
    }>>;
}, z.core.$loose>;
type ProviderInstallationStatusParams = z.infer<typeof providerInstallationStatusParamsSchema>;
declare const providerHealthSchema: z.ZodObject<{
    accountEmail: z.ZodNullable<z.ZodString>;
    canInstall: z.ZodBoolean;
    canUpdate: z.ZodBoolean;
    installedVersion: z.ZodNullable<z.ZodString>;
    loginCommand: z.ZodNullable<z.ZodString>;
    minimumSupportedVersion: z.ZodNullable<z.ZodString>;
    planLabel: z.ZodNullable<z.ZodString>;
    status: z.ZodEnum<{
        expired: "expired";
        not_installed: "not_installed";
        ready: "ready";
        unauthenticated: "unauthenticated";
        unknown: "unknown";
        unsupported_version: "unsupported_version";
    }>;
    statusMessage: z.ZodNullable<z.ZodString>;
}, z.core.$loose>;
type ProviderHealth = z.infer<typeof providerHealthSchema>;
declare const providerUsageWindowSchema: z.ZodObject<{
    cost: z.ZodOptional<z.ZodObject<{
        limitUsdCents: z.ZodNumber;
        usedUsdCents: z.ZodNumber;
    }, z.core.$strip>>;
    label: z.ZodString;
    resetsAt: z.ZodNullable<z.ZodString>;
    usedPercent: z.ZodNumber;
}, z.core.$loose>;
type ProviderUsageWindow = z.infer<typeof providerUsageWindowSchema>;
declare const providerUsageSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    accountEmail: z.ZodNullable<z.ZodString>;
    planLabel: z.ZodNullable<z.ZodString>;
    status: z.ZodLiteral<"ok">;
    windows: z.ZodArray<z.ZodObject<{
        cost: z.ZodOptional<z.ZodObject<{
            limitUsdCents: z.ZodNumber;
            usedUsdCents: z.ZodNumber;
        }, z.core.$strip>>;
        label: z.ZodString;
        resetsAt: z.ZodNullable<z.ZodString>;
        usedPercent: z.ZodNumber;
    }, z.core.$loose>>;
}, z.core.$loose>, z.ZodObject<{
    status: z.ZodLiteral<"not_installed">;
}, z.core.$loose>, z.ZodObject<{
    status: z.ZodLiteral<"unauthenticated">;
}, z.core.$loose>, z.ZodObject<{
    status: z.ZodLiteral<"expired">;
}, z.core.$loose>, z.ZodObject<{
    accountEmail: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    message: z.ZodString;
    planLabel: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    status: z.ZodLiteral<"error">;
}, z.core.$loose>], "status">;
type ProviderUsage = z.infer<typeof providerUsageSchema>;
declare const providerHealthResultSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    supported: z.ZodLiteral<false>;
}, z.core.$loose>, z.ZodObject<{
    health: z.ZodObject<{
        accountEmail: z.ZodNullable<z.ZodString>;
        canInstall: z.ZodBoolean;
        canUpdate: z.ZodBoolean;
        installedVersion: z.ZodNullable<z.ZodString>;
        loginCommand: z.ZodNullable<z.ZodString>;
        minimumSupportedVersion: z.ZodNullable<z.ZodString>;
        planLabel: z.ZodNullable<z.ZodString>;
        status: z.ZodEnum<{
            expired: "expired";
            not_installed: "not_installed";
            ready: "ready";
            unauthenticated: "unauthenticated";
            unknown: "unknown";
            unsupported_version: "unsupported_version";
        }>;
        statusMessage: z.ZodNullable<z.ZodString>;
    }, z.core.$loose>;
    supported: z.ZodLiteral<true>;
}, z.core.$loose>], "supported">;
type ProviderHealthResult = z.infer<typeof providerHealthResultSchema>;
declare const providerUsageResultSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    supported: z.ZodLiteral<false>;
}, z.core.$loose>, z.ZodObject<{
    supported: z.ZodLiteral<true>;
    usage: z.ZodDiscriminatedUnion<[z.ZodObject<{
        accountEmail: z.ZodNullable<z.ZodString>;
        planLabel: z.ZodNullable<z.ZodString>;
        status: z.ZodLiteral<"ok">;
        windows: z.ZodArray<z.ZodObject<{
            cost: z.ZodOptional<z.ZodObject<{
                limitUsdCents: z.ZodNumber;
                usedUsdCents: z.ZodNumber;
            }, z.core.$strip>>;
            label: z.ZodString;
            resetsAt: z.ZodNullable<z.ZodString>;
            usedPercent: z.ZodNumber;
        }, z.core.$loose>>;
    }, z.core.$loose>, z.ZodObject<{
        status: z.ZodLiteral<"not_installed">;
    }, z.core.$loose>, z.ZodObject<{
        status: z.ZodLiteral<"unauthenticated">;
    }, z.core.$loose>, z.ZodObject<{
        status: z.ZodLiteral<"expired">;
    }, z.core.$loose>, z.ZodObject<{
        accountEmail: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        message: z.ZodString;
        planLabel: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        status: z.ZodLiteral<"error">;
    }, z.core.$loose>], "status">;
}, z.core.$loose>], "supported">;
type ProviderUsageResult = z.infer<typeof providerUsageResultSchema>;
declare const providerInstallationActionKindSchema: z.ZodEnum<{
    install: "install";
    update: "update";
}>;
type ProviderInstallationActionKind = z.infer<typeof providerInstallationActionKindSchema>;
declare const providerInstallationActionSchema: z.ZodObject<{
    command: z.ZodString;
    kind: z.ZodEnum<{
        install: "install";
        update: "update";
    }>;
    label: z.ZodEnum<{
        Install: "Install";
        Update: "Update";
    }>;
}, z.core.$loose>;
type ProviderInstallationAction = z.infer<typeof providerInstallationActionSchema>;
declare const providerInstallationSourceSchema: z.ZodEnum<{
    external: "external";
    notInstalled: "notInstalled";
    npmGlobal: "npmGlobal";
}>;
type ProviderInstallationSource = z.infer<typeof providerInstallationSourceSchema>;
declare const providerInstallationStatusSchema: z.ZodObject<{
    currentVersion: z.ZodNullable<z.ZodString>;
    executableName: z.ZodString;
    executablePath: z.ZodNullable<z.ZodString>;
    installAction: z.ZodNullable<z.ZodObject<{
        command: z.ZodString;
        kind: z.ZodEnum<{
            install: "install";
            update: "update";
        }>;
        label: z.ZodEnum<{
            Install: "Install";
            Update: "Update";
        }>;
    }, z.core.$loose>>;
    installSource: z.ZodEnum<{
        external: "external";
        notInstalled: "notInstalled";
        npmGlobal: "npmGlobal";
    }>;
    installed: z.ZodBoolean;
    latestVersion: z.ZodNullable<z.ZodString>;
    minimumSupportedVersion: z.ZodNullable<z.ZodString>;
    needsUpdate: z.ZodBoolean;
    npmGlobalPackageVersion: z.ZodNullable<z.ZodString>;
    npmPackageName: z.ZodNullable<z.ZodString>;
    versionUnsupported: z.ZodBoolean;
}, z.core.$loose>;
type ProviderInstallationStatus = z.infer<typeof providerInstallationStatusSchema>;
declare const providerInstallationRunParamsSchema: z.ZodObject<{
    action: z.ZodEnum<{
        install: "install";
        update: "update";
    }>;
    cwd: z.ZodOptional<z.ZodString>;
    providerId: z.ZodString;
    providerOptions: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
}, z.core.$loose>;
type ProviderInstallationRunParams = z.infer<typeof providerInstallationRunParamsSchema>;
declare const providerInstallationCommandSchema: z.ZodObject<{
    args: z.ZodArray<z.ZodString>;
    command: z.ZodString;
    displayCommand: z.ZodString;
}, z.core.$loose>;
type ProviderInstallationCommand = z.infer<typeof providerInstallationCommandSchema>;
declare const providerInstallationVerificationSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"installed">;
}, z.core.$loose>, z.ZodObject<{
    kind: z.ZodLiteral<"version_changed">;
    previousVersion: z.ZodString;
}, z.core.$loose>, z.ZodObject<{
    kind: z.ZodLiteral<"version_at_least">;
    version: z.ZodString;
}, z.core.$loose>], "kind">;
type ProviderInstallationVerification = z.infer<typeof providerInstallationVerificationSchema>;
declare const providerInstallationRunResultSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    available: z.ZodLiteral<false>;
    message: z.ZodString;
}, z.core.$loose>, z.ZodObject<{
    available: z.ZodLiteral<true>;
    command: z.ZodObject<{
        args: z.ZodArray<z.ZodString>;
        command: z.ZodString;
        displayCommand: z.ZodString;
    }, z.core.$loose>;
    verification: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"installed">;
    }, z.core.$loose>, z.ZodObject<{
        kind: z.ZodLiteral<"version_changed">;
        previousVersion: z.ZodString;
    }, z.core.$loose>, z.ZodObject<{
        kind: z.ZodLiteral<"version_at_least">;
        version: z.ZodString;
    }, z.core.$loose>], "kind">;
}, z.core.$loose>], "available">;
type ProviderInstallationRunResult = z.infer<typeof providerInstallationRunResultSchema>;

declare function resolveExecutablePath(command: string): Promise<string | null>;
declare function commandOutput(command: string, args: readonly string[]): Promise<string | null>;
declare function versionFrom(value: string | null): string | null;
declare function readCliVersion(command: string): Promise<string | null>;
declare function compareVersions(left: string, right: string): number;
declare function npmCommand(): string;
declare function formatCommand(command: string, args: readonly string[]): string;
declare function npmGlobalInstallCommand(npmPackage: string): ProviderInstallationCommand;
declare function npmLatestVersion(npmPackage: string): Promise<string | null>;
interface NpmGlobalPackageProbe {
    npmBin: string | null;
    npmGlobalPackageVersion: string | null;
}
declare function probeNpmGlobalPackage(npmPackage: string): Promise<NpmGlobalPackageProbe>;
declare function npmGlobalInstallSource(args: {
    installed: boolean;
    executablePath: string | null;
    npmBin: string | null;
}): ProviderInstallationSource;
declare function installationVerification(status: Pick<ProviderInstallationStatus, "currentVersion" | "latestVersion">, action: "install" | "update"): ProviderInstallationVerification;
declare function downloadedInstallerCommand(url: string): ProviderInstallationCommand;
declare function clampPercent(value: number): number;

type JsonRpcObject = Record<string, unknown>;
interface JsonRpcMessage extends JsonRpcObject {
    jsonrpc: "2.0";
    id?: string | number;
    method: string;
    params?: unknown;
}
interface ProviderInboundRequest {
    id?: string | number;
    method: string;
    params?: unknown;
}
type ProviderRuntimeEvent = JsonRpcObject;
declare class ProviderRequestDecodeError extends Error {
    readonly code = -32602;
    constructor(message: string);
}
declare class ProviderResponseEncodeError extends Error {
    readonly code = -32602;
    constructor(message: string);
}

type ProviderRawEventCoverage = "noise" | "normalized" | "unknown";
interface ProviderRawEventDescription {
    kind: string;
    coverage: ProviderRawEventCoverage;
}
interface ProviderParsedRawEvent {
    kind: string;
}
interface ProviderVisibilityMetadata<TRawEvent extends ProviderParsedRawEvent = ProviderParsedRawEvent> {
    parseRawEvent(event: JsonRpcMessage): TRawEvent;
    describeParsedRawEvent(event: TRawEvent): ProviderRawEventDescription;
    describeRawEvent(event: JsonRpcMessage): ProviderRawEventDescription;
}
interface CreateProviderVisibilityMetadataArgs<TRawEvent extends ProviderParsedRawEvent> {
    parseRawEvent(event: JsonRpcMessage): TRawEvent;
    describeParsedRawEvent(event: TRawEvent): ProviderRawEventDescription;
}
declare function createProviderVisibilityMetadata<TRawEvent extends ProviderParsedRawEvent>(args: CreateProviderVisibilityMetadataArgs<TRawEvent>): ProviderVisibilityMetadata<TRawEvent>;

interface StringRecord {
    [key: string]: unknown;
}
declare function isRecord(value: unknown): value is StringRecord;
declare function getRecordProperty(value: StringRecord, key: string): StringRecord | null;
declare function getStringProperty(value: StringRecord, key: string): string | undefined;
declare function getRawSdkMessage(event: JsonRpcMessage): StringRecord | null;

declare const bashArgsSchema: z.ZodObject<{
    command: z.ZodOptional<z.ZodString>;
    cwd: z.ZodOptional<z.ZodString>;
}, z.core.$loose>;
declare const textBlockSchema: z.ZodObject<{
    text: z.ZodString;
    type: z.ZodLiteral<"text">;
}, z.core.$strip>;

declare const PROVIDER_BRIDGE_PROTOCOL_VERSION: 2;
declare const THREAD_DELTA_GRAMMAR_V2: 2;
declare const THREAD_DELTA_GRAMMAR_V3: 3;

declare const bridgeGrammarVersionsSchema: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
type BridgeGrammarVersions = z.infer<typeof bridgeGrammarVersionsSchema>;
declare const bridgeSteerModeSchema: z.ZodEnum<{
    inject: "inject";
    queue: "queue";
}>;
type BridgeSteerMode = z.infer<typeof bridgeSteerModeSchema>;
declare const bridgeCapabilitiesSchema: z.ZodObject<{
    approvalEnforcedBy: z.ZodDefault<z.ZodEnum<{
        provider: "provider";
        runtime: "runtime";
    }>>;
    fork: z.ZodDefault<z.ZodEnum<{
        checkpoint: "checkpoint";
        none: "none";
        tip: "tip";
    }>>;
    grammarVersions: z.ZodDefault<z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>>;
    sessionRestore: z.ZodDefault<z.ZodBoolean>;
    skills: z.ZodDefault<z.ZodObject<{
        configure: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strip>>;
    steerMode: z.ZodDefault<z.ZodEnum<{
        inject: "inject";
        queue: "queue";
    }>>;
    threadArchive: z.ZodDefault<z.ZodBoolean>;
    threadGoalClear: z.ZodDefault<z.ZodBoolean>;
    threadRename: z.ZodDefault<z.ZodBoolean>;
}, z.core.$loose>;
type BridgeCapabilities = z.infer<typeof bridgeCapabilitiesSchema>;
declare const initializeParamsSchema: z.ZodObject<{
    client: z.ZodObject<{
        name: z.ZodString;
        version: z.ZodString;
    }, z.core.$strip>;
    grammarVersions: z.ZodDefault<z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>>;
    protocolVersion: z.ZodNumber;
}, z.core.$loose>;
declare const initializeResultSchema: z.ZodObject<{
    capabilities: z.ZodPipe<z.ZodTransform<{}, unknown>, z.ZodObject<{
        approvalEnforcedBy: z.ZodDefault<z.ZodEnum<{
            provider: "provider";
            runtime: "runtime";
        }>>;
        fork: z.ZodDefault<z.ZodEnum<{
            checkpoint: "checkpoint";
            none: "none";
            tip: "tip";
        }>>;
        grammarVersions: z.ZodDefault<z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>>;
        sessionRestore: z.ZodDefault<z.ZodBoolean>;
        skills: z.ZodDefault<z.ZodObject<{
            configure: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>>;
        steerMode: z.ZodDefault<z.ZodEnum<{
            inject: "inject";
            queue: "queue";
        }>>;
        threadArchive: z.ZodDefault<z.ZodBoolean>;
        threadGoalClear: z.ZodDefault<z.ZodBoolean>;
        threadRename: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$loose>>;
    protocolVersion: z.ZodNumber;
}, z.core.$loose>;
type InitializeResult = z.infer<typeof initializeResultSchema>;

declare const bridgeExecutionOptionsSchema: z.ZodIntersection<z.ZodObject<{
    envVars: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    instructions: z.ZodOptional<z.ZodString>;
    model: z.ZodOptional<z.ZodString>;
    promptMode: z.ZodOptional<z.ZodLiteral<"plan">>;
    providerOptions: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    reasoningLevel: z.ZodOptional<z.ZodEnum<{
        high: "high";
        low: "low";
        max: "max";
        medium: "medium";
        none: "none";
        ultra: "ultra";
        ultracode: "ultracode";
        xhigh: "xhigh";
    }>>;
    serviceTier: z.ZodOptional<z.ZodEnum<{
        default: "default";
        fast: "fast";
    }>>;
}, z.core.$strip>, z.ZodDiscriminatedUnion<[z.ZodObject<{
    approvalReviewer: z.ZodLiteral<"user">;
    permissionEscalation: z.ZodEnum<{
        ask: "ask";
        deny: "deny";
    }>;
    permissionMode: z.ZodLiteral<"accept-edits">;
    permissionScope: z.ZodLiteral<"workspace">;
}, z.core.$strip>, z.ZodObject<{
    approvalReviewer: z.ZodLiteral<"automatic">;
    permissionEscalation: z.ZodEnum<{
        ask: "ask";
        deny: "deny";
    }>;
    permissionMode: z.ZodLiteral<"auto">;
    permissionScope: z.ZodLiteral<"workspace">;
}, z.core.$strip>, z.ZodObject<{
    approvalReviewer: z.ZodNull;
    permissionEscalation: z.ZodNull;
    permissionMode: z.ZodLiteral<"full">;
    permissionScope: z.ZodLiteral<"full">;
}, z.core.$strip>], "permissionMode">>;
type BridgeExecutionOptions = z.infer<typeof bridgeExecutionOptionsSchema>;

declare const BRIDGE_REQUEST_METHODS: {
    readonly initialize: "initialize";
    readonly modelList: "model/list";
    readonly providerHealth: "provider/health";
    readonly providerUsage: "provider/usage";
    readonly providerInstallationStatus: "provider/installation/status";
    readonly providerInstallationRun: "provider/installation/run";
    readonly threadStart: "thread/start";
    readonly threadResume: "thread/resume";
    readonly threadFork: "thread/fork";
    readonly threadStop: "thread/stop";
    readonly threadDiscard: "thread/discard";
    readonly threadNameSet: "thread/name/set";
    readonly threadArchive: "thread/archive";
    readonly threadUnarchive: "thread/unarchive";
    readonly threadGoalClear: "thread/goal/clear";
    readonly turnStart: "turn/start";
    readonly turnSteer: "turn/steer";
    readonly skillsConfigure: "skills/configure";
};
declare const modelListParamsSchema: z.ZodObject<{
    cwd: z.ZodOptional<z.ZodString>;
}, z.core.$loose>;
declare const threadStartParamsSchema: z.ZodObject<{
    cwd: z.ZodString;
    disallowedTools: z.ZodOptional<z.ZodArray<z.ZodString>>;
    dynamicTools: z.ZodOptional<z.ZodArray<z.ZodObject<{
        description: z.ZodString;
        inputSchema: z.ZodUnknown;
        name: z.ZodString;
        presentation: z.ZodOptional<z.ZodObject<{
            badge: z.ZodOptional<z.ZodObject<{
                glyph: z.ZodString;
                hint: z.ZodString;
                label: z.ZodString;
                tone: z.ZodEnum<{
                    destructive: "destructive";
                    neutral: "neutral";
                }>;
            }, z.core.$strip>>;
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
    }, z.core.$strip>>>;
    input: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        mentions: z.ZodDefault<z.ZodArray<z.ZodObject<{
            end: z.ZodNumber;
            resource: z.ZodPipe<z.ZodTransform<unknown, unknown>, z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"thread">;
                label: z.ZodString;
                projectId: z.ZodOptional<z.ZodString>;
                threadId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                kind: z.ZodLiteral<"project">;
                label: z.ZodString;
                projectId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                kind: z.ZodLiteral<"section">;
                label: z.ZodString;
                sectionId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                entryKind: z.ZodEnum<{
                    directory: "directory";
                    file: "file";
                }>;
                kind: z.ZodLiteral<"path">;
                label: z.ZodString;
                path: z.ZodString;
                source: z.ZodEnum<{
                    "thread-storage": "thread-storage";
                    workspace: "workspace";
                }>;
            }, z.core.$strip>, z.ZodObject<{
                argumentHint: z.ZodNullable<z.ZodString>;
                kind: z.ZodLiteral<"command">;
                label: z.ZodString;
                name: z.ZodString;
                origin: z.ZodEnum<{
                    builtin: "builtin";
                    project: "project";
                    user: "user";
                }>;
                source: z.ZodEnum<{
                    command: "command";
                    skill: "skill";
                }>;
                trigger: z.ZodEnum<{
                    "/": "/";
                }>;
            }, z.core.$strip>, z.ZodObject<{
                icon: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                itemId: z.ZodString;
                kind: z.ZodLiteral<"plugin">;
                label: z.ZodString;
                pluginId: z.ZodString;
            }, z.core.$strip>], "kind">>;
            start: z.ZodNumber;
        }, z.core.$strip>>>;
        text: z.ZodString;
        type: z.ZodLiteral<"text">;
        visibility: z.ZodOptional<z.ZodEnum<{
            "agent-only": "agent-only";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"image">;
        url: z.ZodString;
        visibility: z.ZodOptional<z.ZodEnum<{
            "agent-only": "agent-only";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        path: z.ZodString;
        type: z.ZodLiteral<"localImage">;
        visibility: z.ZodOptional<z.ZodEnum<{
            "agent-only": "agent-only";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        mimeType: z.ZodOptional<z.ZodString>;
        name: z.ZodOptional<z.ZodString>;
        path: z.ZodString;
        sizeBytes: z.ZodOptional<z.ZodNumber>;
        type: z.ZodLiteral<"localFile">;
        visibility: z.ZodOptional<z.ZodEnum<{
            "agent-only": "agent-only";
        }>>;
    }, z.core.$strip>], "type">>>;
    instructionMode: z.ZodEnum<{
        append: "append";
        replace: "replace";
    }>;
    options: z.ZodIntersection<z.ZodObject<{
        envVars: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        instructions: z.ZodOptional<z.ZodString>;
        model: z.ZodOptional<z.ZodString>;
        promptMode: z.ZodOptional<z.ZodLiteral<"plan">>;
        providerOptions: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        reasoningLevel: z.ZodOptional<z.ZodEnum<{
            high: "high";
            low: "low";
            max: "max";
            medium: "medium";
            none: "none";
            ultra: "ultra";
            ultracode: "ultracode";
            xhigh: "xhigh";
        }>>;
        serviceTier: z.ZodOptional<z.ZodEnum<{
            default: "default";
            fast: "fast";
        }>>;
    }, z.core.$strip>, z.ZodDiscriminatedUnion<[z.ZodObject<{
        approvalReviewer: z.ZodLiteral<"user">;
        permissionEscalation: z.ZodEnum<{
            ask: "ask";
            deny: "deny";
        }>;
        permissionMode: z.ZodLiteral<"accept-edits">;
        permissionScope: z.ZodLiteral<"workspace">;
    }, z.core.$strip>, z.ZodObject<{
        approvalReviewer: z.ZodLiteral<"automatic">;
        permissionEscalation: z.ZodEnum<{
            ask: "ask";
            deny: "deny";
        }>;
        permissionMode: z.ZodLiteral<"auto">;
        permissionScope: z.ZodLiteral<"workspace">;
    }, z.core.$strip>, z.ZodObject<{
        approvalReviewer: z.ZodNull;
        permissionEscalation: z.ZodNull;
        permissionMode: z.ZodLiteral<"full">;
        permissionScope: z.ZodLiteral<"full">;
    }, z.core.$strip>], "permissionMode">>;
    threadId: z.ZodString;
}, z.core.$loose>;
declare const threadResumeParamsSchema: z.ZodObject<{
    cwd: z.ZodString;
    disallowedTools: z.ZodOptional<z.ZodArray<z.ZodString>>;
    dynamicTools: z.ZodOptional<z.ZodArray<z.ZodObject<{
        description: z.ZodString;
        inputSchema: z.ZodUnknown;
        name: z.ZodString;
        presentation: z.ZodOptional<z.ZodObject<{
            badge: z.ZodOptional<z.ZodObject<{
                glyph: z.ZodString;
                hint: z.ZodString;
                label: z.ZodString;
                tone: z.ZodEnum<{
                    destructive: "destructive";
                    neutral: "neutral";
                }>;
            }, z.core.$strip>>;
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
    }, z.core.$strip>>>;
    instructionMode: z.ZodEnum<{
        append: "append";
        replace: "replace";
    }>;
    options: z.ZodIntersection<z.ZodObject<{
        envVars: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        instructions: z.ZodOptional<z.ZodString>;
        model: z.ZodOptional<z.ZodString>;
        promptMode: z.ZodOptional<z.ZodLiteral<"plan">>;
        providerOptions: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        reasoningLevel: z.ZodOptional<z.ZodEnum<{
            high: "high";
            low: "low";
            max: "max";
            medium: "medium";
            none: "none";
            ultra: "ultra";
            ultracode: "ultracode";
            xhigh: "xhigh";
        }>>;
        serviceTier: z.ZodOptional<z.ZodEnum<{
            default: "default";
            fast: "fast";
        }>>;
    }, z.core.$strip>, z.ZodDiscriminatedUnion<[z.ZodObject<{
        approvalReviewer: z.ZodLiteral<"user">;
        permissionEscalation: z.ZodEnum<{
            ask: "ask";
            deny: "deny";
        }>;
        permissionMode: z.ZodLiteral<"accept-edits">;
        permissionScope: z.ZodLiteral<"workspace">;
    }, z.core.$strip>, z.ZodObject<{
        approvalReviewer: z.ZodLiteral<"automatic">;
        permissionEscalation: z.ZodEnum<{
            ask: "ask";
            deny: "deny";
        }>;
        permissionMode: z.ZodLiteral<"auto">;
        permissionScope: z.ZodLiteral<"workspace">;
    }, z.core.$strip>, z.ZodObject<{
        approvalReviewer: z.ZodNull;
        permissionEscalation: z.ZodNull;
        permissionMode: z.ZodLiteral<"full">;
        permissionScope: z.ZodLiteral<"full">;
    }, z.core.$strip>], "permissionMode">>;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
}, z.core.$loose>;
declare const threadForkParamsSchema: z.ZodObject<{
    cwd: z.ZodString;
    disallowedTools: z.ZodOptional<z.ZodArray<z.ZodString>>;
    dynamicTools: z.ZodOptional<z.ZodArray<z.ZodObject<{
        description: z.ZodString;
        inputSchema: z.ZodUnknown;
        name: z.ZodString;
        presentation: z.ZodOptional<z.ZodObject<{
            badge: z.ZodOptional<z.ZodObject<{
                glyph: z.ZodString;
                hint: z.ZodString;
                label: z.ZodString;
                tone: z.ZodEnum<{
                    destructive: "destructive";
                    neutral: "neutral";
                }>;
            }, z.core.$strip>>;
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
    }, z.core.$strip>>>;
    instructionMode: z.ZodEnum<{
        append: "append";
        replace: "replace";
    }>;
    options: z.ZodIntersection<z.ZodObject<{
        envVars: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        instructions: z.ZodOptional<z.ZodString>;
        model: z.ZodOptional<z.ZodString>;
        promptMode: z.ZodOptional<z.ZodLiteral<"plan">>;
        providerOptions: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        reasoningLevel: z.ZodOptional<z.ZodEnum<{
            high: "high";
            low: "low";
            max: "max";
            medium: "medium";
            none: "none";
            ultra: "ultra";
            ultracode: "ultracode";
            xhigh: "xhigh";
        }>>;
        serviceTier: z.ZodOptional<z.ZodEnum<{
            default: "default";
            fast: "fast";
        }>>;
    }, z.core.$strip>, z.ZodDiscriminatedUnion<[z.ZodObject<{
        approvalReviewer: z.ZodLiteral<"user">;
        permissionEscalation: z.ZodEnum<{
            ask: "ask";
            deny: "deny";
        }>;
        permissionMode: z.ZodLiteral<"accept-edits">;
        permissionScope: z.ZodLiteral<"workspace">;
    }, z.core.$strip>, z.ZodObject<{
        approvalReviewer: z.ZodLiteral<"automatic">;
        permissionEscalation: z.ZodEnum<{
            ask: "ask";
            deny: "deny";
        }>;
        permissionMode: z.ZodLiteral<"auto">;
        permissionScope: z.ZodLiteral<"workspace">;
    }, z.core.$strip>, z.ZodObject<{
        approvalReviewer: z.ZodNull;
        permissionEscalation: z.ZodNull;
        permissionMode: z.ZodLiteral<"full">;
        permissionScope: z.ZodLiteral<"full">;
    }, z.core.$strip>], "permissionMode">>;
    sourceProviderCheckpointId: z.ZodOptional<z.ZodString>;
    sourceProviderThreadId: z.ZodString;
    threadId: z.ZodString;
}, z.core.$loose>;
declare const threadStopParamsSchema: z.ZodObject<{
    activeTurnId: z.ZodNullable<z.ZodString>;
    intent: z.ZodEnum<{
        interrupt: "interrupt";
        release: "release";
    }>;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
}, z.core.$loose>;
declare const threadDiscardParamsSchema: z.ZodObject<{
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
}, z.core.$loose>;
declare const threadArchiveParamsSchema: z.ZodObject<{
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
}, z.core.$loose>;
declare const threadUnarchiveParamsSchema: z.ZodObject<{
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
}, z.core.$loose>;
declare const threadGoalClearParamsSchema: z.ZodObject<{
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
}, z.core.$loose>;
declare const threadNameSetParamsSchema: z.ZodObject<{
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    title: z.ZodString;
}, z.core.$loose>;
declare const turnStartParamsSchema: z.ZodObject<{
    clientRequestId: z.ZodString;
    input: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        mentions: z.ZodDefault<z.ZodArray<z.ZodObject<{
            end: z.ZodNumber;
            resource: z.ZodPipe<z.ZodTransform<unknown, unknown>, z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"thread">;
                label: z.ZodString;
                projectId: z.ZodOptional<z.ZodString>;
                threadId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                kind: z.ZodLiteral<"project">;
                label: z.ZodString;
                projectId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                kind: z.ZodLiteral<"section">;
                label: z.ZodString;
                sectionId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                entryKind: z.ZodEnum<{
                    directory: "directory";
                    file: "file";
                }>;
                kind: z.ZodLiteral<"path">;
                label: z.ZodString;
                path: z.ZodString;
                source: z.ZodEnum<{
                    "thread-storage": "thread-storage";
                    workspace: "workspace";
                }>;
            }, z.core.$strip>, z.ZodObject<{
                argumentHint: z.ZodNullable<z.ZodString>;
                kind: z.ZodLiteral<"command">;
                label: z.ZodString;
                name: z.ZodString;
                origin: z.ZodEnum<{
                    builtin: "builtin";
                    project: "project";
                    user: "user";
                }>;
                source: z.ZodEnum<{
                    command: "command";
                    skill: "skill";
                }>;
                trigger: z.ZodEnum<{
                    "/": "/";
                }>;
            }, z.core.$strip>, z.ZodObject<{
                icon: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                itemId: z.ZodString;
                kind: z.ZodLiteral<"plugin">;
                label: z.ZodString;
                pluginId: z.ZodString;
            }, z.core.$strip>], "kind">>;
            start: z.ZodNumber;
        }, z.core.$strip>>>;
        text: z.ZodString;
        type: z.ZodLiteral<"text">;
        visibility: z.ZodOptional<z.ZodEnum<{
            "agent-only": "agent-only";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"image">;
        url: z.ZodString;
        visibility: z.ZodOptional<z.ZodEnum<{
            "agent-only": "agent-only";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        path: z.ZodString;
        type: z.ZodLiteral<"localImage">;
        visibility: z.ZodOptional<z.ZodEnum<{
            "agent-only": "agent-only";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        mimeType: z.ZodOptional<z.ZodString>;
        name: z.ZodOptional<z.ZodString>;
        path: z.ZodString;
        sizeBytes: z.ZodOptional<z.ZodNumber>;
        type: z.ZodLiteral<"localFile">;
        visibility: z.ZodOptional<z.ZodEnum<{
            "agent-only": "agent-only";
        }>>;
    }, z.core.$strip>], "type">>;
    options: z.ZodIntersection<z.ZodObject<{
        envVars: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        instructions: z.ZodOptional<z.ZodString>;
        model: z.ZodOptional<z.ZodString>;
        promptMode: z.ZodOptional<z.ZodLiteral<"plan">>;
        providerOptions: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        reasoningLevel: z.ZodOptional<z.ZodEnum<{
            high: "high";
            low: "low";
            max: "max";
            medium: "medium";
            none: "none";
            ultra: "ultra";
            ultracode: "ultracode";
            xhigh: "xhigh";
        }>>;
        serviceTier: z.ZodOptional<z.ZodEnum<{
            default: "default";
            fast: "fast";
        }>>;
    }, z.core.$strip>, z.ZodDiscriminatedUnion<[z.ZodObject<{
        approvalReviewer: z.ZodLiteral<"user">;
        permissionEscalation: z.ZodEnum<{
            ask: "ask";
            deny: "deny";
        }>;
        permissionMode: z.ZodLiteral<"accept-edits">;
        permissionScope: z.ZodLiteral<"workspace">;
    }, z.core.$strip>, z.ZodObject<{
        approvalReviewer: z.ZodLiteral<"automatic">;
        permissionEscalation: z.ZodEnum<{
            ask: "ask";
            deny: "deny";
        }>;
        permissionMode: z.ZodLiteral<"auto">;
        permissionScope: z.ZodLiteral<"workspace">;
    }, z.core.$strip>, z.ZodObject<{
        approvalReviewer: z.ZodNull;
        permissionEscalation: z.ZodNull;
        permissionMode: z.ZodLiteral<"full">;
        permissionScope: z.ZodLiteral<"full">;
    }, z.core.$strip>], "permissionMode">>;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
}, z.core.$loose>;
declare const turnSteerParamsSchema: z.ZodObject<{
    clientRequestId: z.ZodString;
    expectedTurnId: z.ZodString;
    input: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        mentions: z.ZodDefault<z.ZodArray<z.ZodObject<{
            end: z.ZodNumber;
            resource: z.ZodPipe<z.ZodTransform<unknown, unknown>, z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"thread">;
                label: z.ZodString;
                projectId: z.ZodOptional<z.ZodString>;
                threadId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                kind: z.ZodLiteral<"project">;
                label: z.ZodString;
                projectId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                kind: z.ZodLiteral<"section">;
                label: z.ZodString;
                sectionId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                entryKind: z.ZodEnum<{
                    directory: "directory";
                    file: "file";
                }>;
                kind: z.ZodLiteral<"path">;
                label: z.ZodString;
                path: z.ZodString;
                source: z.ZodEnum<{
                    "thread-storage": "thread-storage";
                    workspace: "workspace";
                }>;
            }, z.core.$strip>, z.ZodObject<{
                argumentHint: z.ZodNullable<z.ZodString>;
                kind: z.ZodLiteral<"command">;
                label: z.ZodString;
                name: z.ZodString;
                origin: z.ZodEnum<{
                    builtin: "builtin";
                    project: "project";
                    user: "user";
                }>;
                source: z.ZodEnum<{
                    command: "command";
                    skill: "skill";
                }>;
                trigger: z.ZodEnum<{
                    "/": "/";
                }>;
            }, z.core.$strip>, z.ZodObject<{
                icon: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                itemId: z.ZodString;
                kind: z.ZodLiteral<"plugin">;
                label: z.ZodString;
                pluginId: z.ZodString;
            }, z.core.$strip>], "kind">>;
            start: z.ZodNumber;
        }, z.core.$strip>>>;
        text: z.ZodString;
        type: z.ZodLiteral<"text">;
        visibility: z.ZodOptional<z.ZodEnum<{
            "agent-only": "agent-only";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"image">;
        url: z.ZodString;
        visibility: z.ZodOptional<z.ZodEnum<{
            "agent-only": "agent-only";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        path: z.ZodString;
        type: z.ZodLiteral<"localImage">;
        visibility: z.ZodOptional<z.ZodEnum<{
            "agent-only": "agent-only";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        mimeType: z.ZodOptional<z.ZodString>;
        name: z.ZodOptional<z.ZodString>;
        path: z.ZodString;
        sizeBytes: z.ZodOptional<z.ZodNumber>;
        type: z.ZodLiteral<"localFile">;
        visibility: z.ZodOptional<z.ZodEnum<{
            "agent-only": "agent-only";
        }>>;
    }, z.core.$strip>], "type">>;
    options: z.ZodIntersection<z.ZodObject<{
        envVars: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        instructions: z.ZodOptional<z.ZodString>;
        model: z.ZodOptional<z.ZodString>;
        promptMode: z.ZodOptional<z.ZodLiteral<"plan">>;
        providerOptions: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        reasoningLevel: z.ZodOptional<z.ZodEnum<{
            high: "high";
            low: "low";
            max: "max";
            medium: "medium";
            none: "none";
            ultra: "ultra";
            ultracode: "ultracode";
            xhigh: "xhigh";
        }>>;
        serviceTier: z.ZodOptional<z.ZodEnum<{
            default: "default";
            fast: "fast";
        }>>;
    }, z.core.$strip>, z.ZodDiscriminatedUnion<[z.ZodObject<{
        approvalReviewer: z.ZodLiteral<"user">;
        permissionEscalation: z.ZodEnum<{
            ask: "ask";
            deny: "deny";
        }>;
        permissionMode: z.ZodLiteral<"accept-edits">;
        permissionScope: z.ZodLiteral<"workspace">;
    }, z.core.$strip>, z.ZodObject<{
        approvalReviewer: z.ZodLiteral<"automatic">;
        permissionEscalation: z.ZodEnum<{
            ask: "ask";
            deny: "deny";
        }>;
        permissionMode: z.ZodLiteral<"auto">;
        permissionScope: z.ZodLiteral<"workspace">;
    }, z.core.$strip>, z.ZodObject<{
        approvalReviewer: z.ZodNull;
        permissionEscalation: z.ZodNull;
        permissionMode: z.ZodLiteral<"full">;
        permissionScope: z.ZodLiteral<"full">;
    }, z.core.$strip>], "permissionMode">>;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
}, z.core.$loose>;
declare const skillsConfigureParamsSchema: z.ZodObject<{
    roots: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        path: z.ZodString;
        skills: z.ZodArray<z.ZodObject<{
            description: z.ZodString;
            name: z.ZodString;
        }, z.core.$loose>>;
    }, z.core.$loose>>;
}, z.core.$loose>;

declare const BRIDGE_NOTIFICATION_METHODS: {
    readonly threadIdentity: "thread/identity";
    readonly sessionReplaced: "session/replaced";
    readonly providerRaw: "provider/raw";
    readonly providerRecovery: "provider/recovery";
    readonly error: "error";
};
declare const providerRecoveryNotificationSchema: z.ZodObject<{
    kind: z.ZodEnum<{
        authRequired: "authRequired";
        rateLimited: "rateLimited";
        restartRecommended: "restartRecommended";
        sessionArchived: "sessionArchived";
        staleTurn: "staleTurn";
    }>;
    message: z.ZodString;
    retryable: z.ZodBoolean;
    threadId: z.ZodOptional<z.ZodString>;
}, z.core.$loose>;
type ProviderRecoveryNotification = z.infer<typeof providerRecoveryNotificationSchema>;

declare const BRIDGE_INBOUND_REQUEST_METHODS: {
    readonly toolCall: "item/tool/call";
    readonly interactionRequest: "interaction/request";
};

interface SanitizeInheritedChildProcessEnvArgs {
    env: NodeJS.ProcessEnv;
    shellPath?: string;
}
declare function sanitizeInheritedChildProcessEnv(args: SanitizeInheritedChildProcessEnvArgs): NodeJS.ProcessEnv;

declare const acpLaunchSpecSchema: z.ZodObject<{
    args: z.ZodArray<z.ZodString>;
    command: z.ZodString;
    cwd: z.ZodOptional<z.ZodString>;
    displayName: z.ZodString;
    env: z.ZodRecord<z.ZodString, z.ZodString>;
    modelCli: z.ZodOptional<z.ZodPipe<z.ZodObject<{
        listArgs: z.ZodArray<z.ZodString>;
        primaryModels: z.ZodArray<z.ZodString>;
        selectFlag: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodTransform<{
        listArgs: string[];
        primaryModels: string[];
        selectFlag?: string | undefined;
    } | undefined, {
        listArgs: string[];
        primaryModels: string[];
        selectFlag?: string | undefined;
    }>>>;
    nativeReasoning: z.ZodOptional<z.ZodObject<{
        configId: z.ZodString;
        defaultLevel: z.ZodOptional<z.ZodEnum<{
            high: "high";
            low: "low";
            max: "max";
            medium: "medium";
            none: "none";
            ultra: "ultra";
            ultracode: "ultracode";
            xhigh: "xhigh";
        }>>;
        levelValues: z.ZodOptional<z.ZodRecord<z.ZodEnum<{
            high: "high";
            low: "low";
            max: "max";
            medium: "medium";
            none: "none";
            ultra: "ultra";
            ultracode: "ultracode";
            xhigh: "xhigh";
        }> & z.core.$partial, z.ZodString>>;
        supportedLevels: z.ZodArray<z.ZodEnum<{
            high: "high";
            low: "low";
            max: "max";
            medium: "medium";
            none: "none";
            ultra: "ultra";
            ultracode: "ultracode";
            xhigh: "xhigh";
        }>>;
    }, z.core.$strict>>;
    nativeSkillRoots: z.ZodOptional<z.ZodObject<{
        project: z.ZodDefault<z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
            ancestors: z.ZodOptional<z.ZodBoolean>;
            namePrefix: z.ZodOptional<z.ZodString>;
            path: z.ZodString;
            recursive: z.ZodOptional<z.ZodBoolean>;
            skipIfManifest: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>]>>>;
        user: z.ZodDefault<z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
            ancestors: z.ZodOptional<z.ZodBoolean>;
            namePrefix: z.ZodOptional<z.ZodString>;
            path: z.ZodString;
            recursive: z.ZodOptional<z.ZodBoolean>;
            skipIfManifest: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>]>>>;
    }, z.core.$strict>>;
    permissionCli: z.ZodOptional<z.ZodObject<{
        full: z.ZodOptional<z.ZodArray<z.ZodString>>;
        insertAfterArgs: z.ZodOptional<z.ZodNumber>;
        readonly: z.ZodOptional<z.ZodArray<z.ZodString>>;
        workspaceWrite: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    reasoningCli: z.ZodOptional<z.ZodObject<{
        defaultLevel: z.ZodOptional<z.ZodEnum<{
            high: "high";
            low: "low";
            max: "max";
            medium: "medium";
            none: "none";
            ultra: "ultra";
            ultracode: "ultracode";
            xhigh: "xhigh";
        }>>;
        flag: z.ZodString;
        levelValues: z.ZodOptional<z.ZodRecord<z.ZodEnum<{
            high: "high";
            low: "low";
            max: "max";
            medium: "medium";
            none: "none";
            ultra: "ultra";
            ultracode: "ultracode";
            xhigh: "xhigh";
        }> & z.core.$partial, z.ZodString>>;
        supportedLevels: z.ZodArray<z.ZodEnum<{
            high: "high";
            low: "low";
            max: "max";
            medium: "medium";
            none: "none";
            ultra: "ultra";
            ultracode: "ultracode";
            xhigh: "xhigh";
        }>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
type AcpLaunchSpec = z.infer<typeof acpLaunchSpecSchema>;
declare function normalizeAcpLaunchSpec(spec: AcpLaunchSpec): AcpLaunchSpec;

/**
 * The Claude Code task-tool vocabulary as `@get-bb/plugin-sdk/provider-bridge`
 * published it through 0.4.15: the four tool names and the union of their
 * outputs. Core shared these with the claude-code runtime when that runtime
 * lived in bb; the claude-code plugin now owns its own task vocabulary and
 * nothing in this repository reads these. They stay exactly as shipped so a
 * bridge compiled against an earlier SDK still resolves them, and go with
 * the next major version (docs/api_to_audit.md, "Scheduled removals").
 */

declare const claudeTaskToolNameSchema: z.ZodEnum<{
    TaskCreate: "TaskCreate";
    TaskGet: "TaskGet";
    TaskList: "TaskList";
    TaskUpdate: "TaskUpdate";
}>;
declare const claudeTaskToolOutputSchema: z.ZodUnion<readonly [z.ZodObject<{
    task: z.ZodObject<{
        id: z.ZodString;
        subject: z.ZodString;
    }, z.core.$loose>;
}, z.core.$loose>, z.ZodObject<{
    task: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        status: z.ZodEnum<{
            completed: "completed";
            in_progress: "in_progress";
            pending: "pending";
        }>;
        subject: z.ZodString;
    }, z.core.$loose>>;
}, z.core.$loose>, z.ZodObject<{
    tasks: z.ZodArray<z.ZodUnknown>;
}, z.core.$loose>, z.ZodObject<{
    success: z.ZodBoolean;
    taskId: z.ZodString;
}, z.core.$loose>]>;
type ClaudeTaskToolOutput = z.infer<typeof claudeTaskToolOutputSchema>;

export { BRIDGE_INBOUND_REQUEST_METHODS, BRIDGE_JSON_RPC_ERRORS, BRIDGE_NOTIFICATION_METHODS, BRIDGE_REQUEST_METHODS, HIGH_REASONING_EFFORT, LOCAL_BASH_TASK_TYPE, LOCAL_WORKFLOW_TASK_TYPE, LOW_REASONING_EFFORT, MAX_REASONING_EFFORT, MEDIUM_REASONING_EFFORT, PROVIDER_BRIDGE_EXPORT_NAME, PROVIDER_BRIDGE_PROTOCOL_VERSION, ProviderRequestDecodeError, ProviderResponseEncodeError, THREAD_DELTA_GRAMMAR_V2, THREAD_DELTA_GRAMMAR_V3, THREAD_DELTA_NOTIFICATION_METHOD, ULTRACODE_REASONING_EFFORT, USER_QUESTION_MAX_OPTIONS, USER_QUESTION_MAX_QUESTIONS, XHIGH_REASONING_EFFORT, ZERO_TOKEN_USAGE, acpNativeReasoningSchema, acpPermissionCliSchema, acpReasoningCliSchema, addTokenUsage, approvalInteractionOutcomeSchema, backgroundTaskItemStatus, bashArgsSchema, bridgeCapabilitiesSchema, bridgeErrorDataSchema, bridgeGrammarVersionsSchema, bridgeRequestEnvelopeSchema, bridgeSteerModeSchema, buildShellEnvOverrides, claudeTaskToolNameSchema, claudeTaskToolOutputSchema, createBridgeIo, createBridgeLineHandler, createPendingToolCallTracker, createProviderVisibilityMetadata, decodeBridgeJsonRpcResponse, decodeToolCallResponsePayload, deltaBackgroundTaskShapeSchema, deltaDelegationShapeSchema, deltaExtensionShapeSchema, deltaFileChangeSchema, deltaFileReadShapeSchema, deltaItemKeySchema, deltaItemShapeSchema, deltaNoTurnFallbackSchema, deltaOutputChannelSchema, deltaPlanStepsShapeSchema, deltaPresentationSchema, deltaProgressSnapshotSchema, deltaSearchShapeSchema, deltaTextChannelSchema, dynamicToolSchema, errorEnvelopeSchema, BridgeRecoveryError as experimental_BridgeRecoveryError, COMPACTION_PRESENTATION as experimental_COMPACTION_PRESENTATION, REASONING_PRESENTATION as experimental_REASONING_PRESENTATION, buildBridgeToolCallContent as experimental_buildBridgeToolCallContent, clampPercent as experimental_clampPercent, commandOutput as experimental_commandOutput, compareVersions as experimental_compareVersions, experimental_defineProviderBridge, downloadedInstallerCommand as experimental_downloadedInstallerCommand, fileReadPresentation as experimental_fileReadPresentation, formatCommand as experimental_formatCommand, installationVerification as experimental_installationVerification, experimental_isProviderBridgeRecording, npmCommand as experimental_npmCommand, npmGlobalInstallCommand as experimental_npmGlobalInstallCommand, npmGlobalInstallSource as experimental_npmGlobalInstallSource, npmLatestVersion as experimental_npmLatestVersion, planStepsPresentation as experimental_planStepsPresentation, presentationDetail as experimental_presentationDetail, presentationFileName as experimental_presentationFileName, presentationTitle as experimental_presentationTitle, probeNpmGlobalPackage as experimental_probeNpmGlobalPackage, readBoundedLines as experimental_readBoundedLines, readCliVersion as experimental_readCliVersion, experimental_recordProviderChildIo, resolveExecutablePath as experimental_resolveExecutablePath, searchPresentation as experimental_searchPresentation, toolPresentation as experimental_toolPresentation, versionFrom as experimental_versionFrom, webFetchPresentation as experimental_webFetchPresentation, webSearchPresentation as experimental_webSearchPresentation, withTitle as experimental_withTitle, extensionKindSchema, extractResultText, getRawSdkMessage, getRecordProperty, getStringProperty, acpLaunchSpecSchema as hostDaemonAcpLaunchSpecSchema, initializeParamsSchema, instructionModeValues, interactionRequestPayloadSchema, isApprovalInteractionOutcome, isApprovalPendingInteractionPayload, isApprovalPendingInteractionResolution, isBackgroundAgentTaskType, isExtensionKind, isRecord, isSettledBackgroundTaskStatus, isStandaloneBuiltinCompactCommand, isUserQuestionPendingInteractionPayload, isUserQuestionPendingInteractionResolution, jsonRpcEnvelopeSchema, jsonValueSchema, mimeTypeFromExtension, modelListParamsSchema, normalizeAcpLaunchSpec as normalizeHostDaemonAcpLaunchSpec, normalizeProviderCommandOutput, pendingInteractionCommandActionSchema, pendingInteractionFileSystemPermissionsSchema, pendingInteractionMacOsPermissionsSchema, pendingInteractionNetworkPermissionsSchema, pendingInteractionRequestedPermissionProfileSchema, pendingInteractionResolutionSchema, permissionEscalationValues, providerHealthResultSchema, providerHealthSchema, providerInstallationActionKindSchema, providerInstallationActionSchema, providerInstallationCommandSchema, providerInstallationRequirementSchema, providerInstallationRunParamsSchema, providerInstallationRunResultSchema, providerInstallationSourceSchema, providerInstallationStatusParamsSchema, providerInstallationStatusSchema, providerInstallationVerificationSchema, providerInteractionOutcomeSchema, providerMaintenanceParamsSchema, providerRawEventSchema, providerRecoveryHintSchema, providerRecoveryKindSchema, providerRecoveryKindValues, providerRecoveryNotificationSchema, providerUsageResultSchema, providerUsageSchema, providerUsageWindowSchema, reasoningEffortsForLevels, reasoningLevelSchema, reasoningLevelValues, removeCommandMentionsFromPromptInput, runBridgeRequest, runtimePermissionScopeValues, sanitizeInheritedChildProcessEnv, sdkMessageEnvelopeSchema, shouldAutoDenyInteractiveRequest, skillsConfigureParamsSchema, textBlockSchema, threadArchiveParamsSchema, threadContextWindowUsageEnvelopeSchema, threadDeltaNotificationParamsSchema, threadDeltaSchema, threadDiscardParamsSchema, threadEventItemPresentationSchema, threadEventSearchModeSchema, threadForkParamsSchema, threadGoalClearParamsSchema, threadIdentityEnvelopeSchema, threadNameSetParamsSchema, threadResumeParamsSchema, threadStartParamsSchema, threadStopParamsSchema, threadUnarchiveParamsSchema, toNonNegativeNumber, toOptionalRecord, toOptionalString, toPositiveNumber, turnStartParamsSchema, turnSteerParamsSchema, userQuestionInteractionOutcomeSchema, withoutBridgeRuntimeEnv };
export type { ApprovalInteractionOutcome, ApprovalPendingInteractionPayload, AvailableModel, BackgroundTaskStatus, BackgroundTaskUsage, BoundedLineReaderArgs, BridgeCapabilities, BridgeErrorData, BridgeExecutionOptions, BridgeGrammarVersions, BridgeJsonRpcResponse, BridgeSendError, BridgeSteerMode, BridgeToolCallRequest, BuildInteractiveResponseArgs, ClaudeTaskToolOutput, ClientTurnRequestId, DecodedInteractiveRequest, DeltaBackgroundTaskShape, DeltaDelegationShape, DeltaExtensionShape, DeltaFileChange, DeltaFileReadShape, DeltaItemKey, DeltaItemShape, DeltaItemShapeType, DeltaNoTurnFallback, DeltaOutputChannel, DeltaPlanStepsShape, DeltaPresentation, DeltaProgressSnapshot, DeltaSearchShape, DeltaTextChannel, DynamicTool, ExtensionKind, AcpLaunchSpec as HostDaemonAcpLaunchSpec, InitializeResult, InstructionMode, InteractionRequestPayload, JsonObject, JsonRpcMessage, JsonValue, ModelReasoningEffort, NpmGlobalPackageProbe, PendingInteractionApprovalDecision, PendingInteractionApprovalSubject, PendingInteractionCommandAction, PendingInteractionGrantablePermissionProfile, PendingInteractionGrantedPermissionProfile, PendingInteractionPayload, PendingInteractionRequestedPermissionProfile, PendingInteractionResolution, PendingInteractionUserQuestionQuestion, PermissionEscalation, PermissionMode, PreparedProviderCommandDispatch, PromptInput, ProviderBridgeContext, ProviderBridgeDefinition, ProviderBridgeEntry, ProviderErrorCategory, ProviderErrorInfo, ProviderHealth, ProviderHealthResult, ProviderInboundRequest, ProviderInstallationAction, ProviderInstallationActionKind, ProviderInstallationCommand, ProviderInstallationRequirement, ProviderInstallationRunParams, ProviderInstallationRunResult, ProviderInstallationSource, ProviderInstallationStatus, ProviderInstallationStatusParams, ProviderInstallationVerification, ProviderInteractionOutcome, ProviderMaintenanceParams, ProviderPostInitializeRequest, ProviderRateLimitState, ProviderRateLimitStatus, ProviderRateLimitWindow, ProviderRawEvent, ProviderRawEventCoverage, ProviderRawEventDescription, ProviderRecoveryHint, ProviderRecoveryKind, ProviderRecoveryNotification, ProviderRuntimeEvent, ProviderUsage, ProviderUsageResult, ProviderUsageWindow, ProviderVisibilityMetadata, ReasoningLevel, RuntimePermissionPolicy, RuntimePermissionScope, ServiceTier, ThreadDelta, ThreadDeltaKind, ThreadDeltaNotificationParams, ThreadEventContextWindowUsage, ThreadEventItemPresentation, ThreadEventItemStatus, ThreadEventPlanStep, ThreadEventSearchMode, ThreadEventTokenUsageBreakdown, ThreadEventTurnStatus, ThreadEventUserContent, UserQuestionInteractionOutcome, UserQuestionPendingInteractionPayload, UserQuestionPendingInteractionResolution, WorkflowAgentSnapshot, WorkflowAgentState, WorkflowPhaseSnapshot, WorkflowProgressSnapshot };
